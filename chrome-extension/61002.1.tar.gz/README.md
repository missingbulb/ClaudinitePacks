# chrome-extension pack

Suggested when a `manifest.json` at the repo root or one directory down declares `"manifest_version": 3` - the MV3 build/runtime gotchas that apply while you're *coding* an extension. Mostly prose (`RULES.md`); the gotchas with a static signature in the source are checks.

Releasing and Chrome-Web-Store publication live here too, in the [**chrome-store-releases**](skills/chrome-store-releases/SKILL.md) skill (the standard: the pipeline's contract, the setup steps, the manual store actions), the **vendored release set** ([`stubs/workflows/`](stubs/workflows/) + [`stubs/actions/`](stubs/actions/), materialized into each consumer's own `.github/` by the `chrome-release-vendoring` migration), the `cer/` conformance checks, and the `store-release` task that fires the daily release.

**The release half applies once the repo ships the pipeline**, the orchestrator workflow or a `.github/release.config` being present, and nothing is declared for it. A repo that only codes an extension is asked for no release config, no privacy page and no README release section; a repo that publishes gets all of it.

## What the pack carries

The gotchas themselves live in [`RULES.md`](RULES.md), grouped by the surface each concerns —
service worker, content scripts, permissions and host access, sign-in and tokens, extension UI
surfaces, and introspecting a service worker over CDP.

## Rules (`RULES.md`)

| Rule | Severity | Reason | Enforcement |
|---|---|---|---|
| Passing a path from a service worker | high | correctness | prose: <100 words |
| Wanting import/export in extension code | medium | correctness | prose: <100 words |
| Assembling a shared global across files | high | correctness | prose: <100 words |
| Accumulating state in a re-injected file | high | correctness | prose: <50 words |
| Loading module code into a content script | high | correctness | prose: <200 words + check (`content-script-module-syntax`) |
| Adding an import to a content-script module | high | correctness | prose: <50 words |
| Keeping that webaccessibleresources list correct | high | correctness | prose: <50 words |
| Matching a host with chrome.events.UrlFilter | high | correctness | prose: <100 words |
| A listed host's fetch failing in-browser | medium | correctness | prose: <50 words |
| Reaching your own backend | medium | correctness | prose: <50 words |
| Authenticating an extension to a JWT-validating backend | critical | correctness | prose: <100 words |
| Refreshing a token silently | medium | correctness | prose: <50 words |
| Refreshing silently with two accounts | medium | correctness | prose: <50 words |
| Storing a token | critical | correctness | prose: <50 words |
| Keeping a token across a restart | medium | correctness | prose: <50 words |
| Knowing whether your side panel is open | low | correctness | prose: <50 words |
| Opening the side panel programmatically | medium | correctness | prose: <20 words |
| Putting a menu on the toolbar icon | low | correctness | prose: <50 words |
| Recreating menu items on startup | medium | correctness | prose: <50 words |
| Awaiting a chrome. callback API inside Runtime.evaluate | low | correctness | prose: <50 words |
| Reading a worker value over CDP | low | correctness | prose: <50 words |
| Attaching to a dormant worker | low | correctness | prose: <50 words |

Runtime host access — the two rules that concern `host_permissions` — is the
[`extension-host-permissions`](skills/extension-host-permissions/SKILL.md) skill, forced for any
`manifest.json` edit.

## Checks

| Check | Severity | Reason | Enforcement |
|---|---|---|---|
| `content-script-module-syntax` | high | correctness | check: blocking |
| `declarative-content-set-icon` | medium | correctness | check: blocking |
| `cer/release-workflows` | high | correctness | check: blocking |
| `cer/template-tokens` | high | correctness | check: blocking |
| `cer/release-config` | high | correctness | check: blocking |
| `cer/version-sync` | high | correctness | check: blocking |
| `cer/version-bumped` | high | correctness | check: blocking |
| `cer/release-layout` | medium | correctness | check: blocking |
| `cer/readme-sections` | low | complexity | check: blocking |
| `cer/privacy-permission-alignment` | critical | legal | check: blocking |
| `cer/permission-added-store-issue` | high | legal | check: advisory |

Every `cer/` rule is about a release that would otherwise fail — or publish the wrong thing — only once it reached the store, and every one of them is inert until this repo ships the pipeline. `cer/version-bumped` judges the diff, so it fires in a change that ships files without moving the version.

## Skills

[**chrome-store-releases**](skills/chrome-store-releases/SKILL.md) is the release standard itself — the vendored workflows and composite actions, `.github/release.config`, versioning and the packaged artifact, the store secrets, the README install sections, and the manual Chrome Web Store steps. It is the contract the `cer/` checks judge against, reached when a pipeline is being set up or debugged rather than carried by every session in the repo.

## Task

`tasks/store-release/` fires the repo's daily release: agentless, `code_work` only, dispatching the vendored daily workflow. Its precondition declines on a repo that does not publish.
