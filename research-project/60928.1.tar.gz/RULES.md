# research-project — running an algorithm against ground truth

## 1. The core loop — iterate on the algorithm, and *show* every step

For every substantive algorithmic change, in this order:

1. **Reproduce & diagnose — visually, first.** Start from the actual inputs.
   Render the current behaviour and *look* at it before theorising. If a
   decision hinges on a measurable fact (a colour/intensity split, a threshold,
   an over-reach, a distribution), write a **throwaway diagnostic and measure
   it** — do not guess.
2. **Prototype in the scratchpad.** Build the change as a standalone script
   first. Do **not** touch tracked code yet.
3. **Show a comparison in the chat.** Surface a rendered **[ original | result ]**
   side-by-side — and **[ … | ground truth ]** wherever scoring applies —
   directly in the conversation (render it inline, don't just link a path). The
   **picture leads**; numbers (accuracy metrics, the target quantity) come
   *after* it as confirmation, **never instead of it**.
4. **Get a read, then commit to the approach.** Only once the visual result is
   right do you wire it into the tracked code. If a call is genuinely ambiguous
   or is the owner's to make, ask **one** targeted question; otherwise proceed on
   a sensible default and state what you chose.
5. **Wire it in fully** — see *Definition of done* (§5).
6. **Record it** as a numbered iteration note — what was wrong, what changed, the
   metric delta, and **what you tried and rejected** (§5).

### Show, don't just tell

- Every algorithmic change is presented as a rendered comparison against the
  original, and against ground truth when scoring is involved. Prefer a clean,
  purpose-built **results figure** over a wall of metrics.

- The presentation render is usually **not** the debug overlay. Favour a thin,
  semi-transparent style that keeps the underlying data readable (thin lines,
  mostly-transparent fills), and give a matched object the **same colour in the
  result and the ground-truth panels** so over-/under-reach is obvious at a
  glance. Tag objects with small ids that key into the metrics table.

- **Never draw an annotation in a colour the underlying signal itself carries.**
  A mark in the signal's own colour disappears exactly on the objects it exists
  to mark, so the figure looks cleanest where the method is least verified. Pick
  the overlay palette against the data's own colours (and keep the choice
  guarded, if the render is scripted), not by aesthetic preference. (draw-annotation-colour)

- **Show where the method breaks, not only where it works.** The overlay is a QA
  tool before it is a result: point at the misses, the fragmentation, the cases
  handled badly, and make each claim explicit and checkable ("this outline is
  what I'm counting as an object; that one has no outline — it was missed") so
  the owner can disagree with a specific claim rather than a general impression.
  (show-method-breaks)

- **Say which of the numbers you just reported are trustworthy, where you report
  them.** Every quantity a project reports sits somewhere on a spectrum from
  "measured and validated" to "indicative at best" — a quantity derived from a
  low-resolution crop, one still inflated by a known failure mode, a split that
  rests on a single threshold. State that boundary *inline, beside the number*,
  not in a separate caveats section a reader meets after they have already
  written the number down. A number quoted without its caveat is read as
  trustworthy. (say-numbers-just)

- Throwaway renders and diagnostics live in the scratchpad; only the **final
  artifact and the code that regenerates it** get committed.

### Interaction cadence

- **Keep the owner in the loop with pictures**, proactively, and ask a question only when a
  decision is genuinely theirs or the request is ambiguous — never to confirm work you can
  verify yourself. (keep-owner-loop)

- **Finishing a unit of work** — leave it committed and pushed, so it can be reviewed or
  resumed from a fresh session. (finishing-unit-work)

---

## 2. Ground truth — user-provided, annotated, **never invented**

- **The owner's annotations are the ground truth.** Every change is validated by
  agreement against them, not against your own expectation of the answer — and never
  against the pipeline's own prior output, which validates nothing. (owners-annotations-ground)

- **Ground truth is annotated, never fabricated.** Do not invent labels to make a
  dataset scorable. If a dataset lacks the annotation a given harness needs, it
  does not go into that harness (see §9 on validation tiers). (ground-truth-annotated)

- **Separate source-of-truth from generated artifacts.** The hand-annotation is
  the source; the machine-usable ground-truth (registered masks, parsed labels,
  normalized tables) is **generated from it and regenerated on demand** — never
  hand-edited, because the generator overwrites it. To fix ground truth, **fix
  the source annotation (or the extraction code) and regenerate**, then re-score.
  (separate-source-truth)

- **Make extraction deterministic and self-checking.** Same annotation → same
  derived ground truth. Pin the things a human counted (number of objects,
  number of regions) as assertions/tests so a silent extraction regression fails
  loudly. (make-extraction-deterministic)

- **Auto-detect annotation conventions from the data**, don't hard-code a
  per-input flag. When the owner uses more than one annotation scheme over time,
  detect which scheme an input uses from the ink/markup itself. Record the
  **conventions** (what each colour / mark / region means) in a durable doc; they
  are requirements, not incidental. (auto-detect-annotation)

- **Verify the annotation actually parses before trusting a score.** Inspect two
  things: did the markup parse into the labels you expected, and did the derived
  ground truth land correctly on the raw input (registration / alignment)? Keep
  the review overlays. (verify-annotation-actually)

---

## 3. Inputs — a small, similarly-formatted learning set

- Projects like this begin with a **small learning set of similarly-formatted
  inputs** (same modality, same acquisition regime, same annotation convention).
  That is a hazard as well as a feature: it is small enough to overfit (§4).

- **State the input format explicitly** (dimensions, modality, contrast
  convention, expected content per input) so a mismatched new input is diagnosed
  fast. Keep a one-line-per-input table. (state-input-format)

- **Name the primary target regime and what is out of scope.** A different
  regime (inverted contrast, far denser or sparser content, a different scale)
  is a *transfer* problem, not the main path — treat it as such until explicitly
  in scope. (name-primary-target)

- **Scale-awareness is a first-class concern.** An algorithm tuned for one
  input scale (e.g. a zoomed view of a few objects) often fails on another
  (a wide field of many). Know which regime you are tuned for, and measure the
  gap on the other rather than pretending it's covered. (scale-awareness-first)

- **Choosing test images for a new detection/invariance harness** - default to real images
  already at hand (the uploaded corpus, literature figures) over a synthetic field; synthesize
  only once real options are exhausted. A synthetic image is built from the same assumptions the
  algorithm makes, so it tends to confirm the algorithm rather than test it. (choosing-test-images)

---

## 4. Do not overfit the learning set

These are **hard constraints** — a change that violates one gets reverted even
if it improves a metric.

- **No single-input special-casing.** Every rule must generalise across the set.
  If a fix only helps one input, say so and either generalise it or drop it.
  Never key logic on a specific input's identity/filename. (single-input-special)

- **Keep decision rules free of the very prior you are trying to measure.** If
  the project measures quantity *X*, no rule may bake in an assumed value of *X*
  (that turns the measurement into an assumption). Prefer rules expressed in
  terms the input **measures for itself** over fixed constants. (keep-decision-rules)

- **Prefer scale-free rules over pixel/absolute constants.** Where a constant is
  unavoidably tied to the current data's scale/resolution, **isolate and label
  it** as scale-dependent so it is the first thing revisited on new-scale data. (prefer-scale-free)

- **Name the hard constraint the task cannot trade away**, and tune to it first —
  some projects have a metric whose cost dominates all others; hold it at its
  required level before optimising the softer metrics underneath it. Make it
  explicit so a later tuning pass doesn't quietly trade it away. (name-hard-constraint)

- **Keep a registry of domain assumptions, each with a failure mode.** Choices
  that encode a prior about the *subject or the instrument* (not pure
  processing) are named, located in the code with an inline tag, and given an
  explicit "how it fails on mismatched data" note. When a new input looks wrong,
  the first diagnostic is *"which assumption did this input break?"*. Flag the
  thinly-supported ones (e.g. calibrated on a single example) honestly. (keep-registry-domain)

- **Guard the wins with regression tests.** An input the owner has blessed as
  "very good" must not silently regress when you tune for another. Pin its score.
  (guard-wins-regression)

---

## 5. Repeatable improvement iterations — the numbered notes, and *definition of done*

Each accepted change is recorded as a **numbered iteration note** (pick a short
tag and stick to it, e.g. `R1, R2, …`) in a running method-narrative doc, so
**the next session does not re-derive what this one already learned.**

An iteration note captures:

- **What was wrong** (the observed failure, ideally with the diagnostic that
  showed it). (was-wrong)

- **What changed** (the rule/parameter and why, in scale-free terms where
  possible). (changed-what)

- **The metric delta** — before/after, per input, on the real scoring harness. (metric-delta)

- **What you tried and rejected, and why** — this is what stops the next session
  (or the next model) from walking back into the same dead end. (tried-rejected)

### A metric's definition is part of its identity

Write down what each reported metric actually counts, and treat **re-defining
one as the owner's call, never a tuning step**. A definition change is uniquely
silent: the column keeps its name and its units, so every number ever recorded
under it *looks* comparable while the quantity underneath has moved. When a
definition does change, the history is **re-measured, never re-labelled** — rerun
the old inputs under the new definition, or mark the old numbers as belonging to
the old one. Carrying both definitions' numbers in one series under one name is
the failure this rule exists to prevent.

### A raw measurement is comparable only inside one calibration

When each input carries its own scale (a per-image conversion factor, a per-run
sampling rate, a per-source unit), a raw absolute quantity means something
different in every input. **Aggregate and compare only normalized quantities** —
a density, a ratio, a per-unit rate — never the raw number, and never a mean
spanning two sources that differ in more than scale (a different instrument,
subject or protocol changes *what* is measured, not just how much of it fits in
frame). Group the rollup by source and say what the grouping is for.

The conversion factor is a **measurement of that input**, not a constant: read it
off the input itself, never infer it from a stated setting or borrow it from a
neighbour. It lives in exactly one place in the code — a second copy is a second
calibration, and whichever copy a given script happens to read wins silently. An
input offering nothing to measure the factor from is **not** quietly dropped:
mark it uncalibrated *with the reason*, report only its scale-free quantities,
and leave it visible as a known gap.

### Definition of done for an accepted change

- **Source updated — never the generated artifacts.** (Regenerate them.)
  (source-updated-generated)

- **Artifacts regenerated** with the committed generators. (artifacts-regenerated)

- **Tests green**, and the **scoring deltas reported** (per input, per metric). (tests-green)

- **Committed with a clear message and pushed**, so the work is reviewable and
  resumable from a fresh session / another machine. (committed-clear-message)

- **Learnings cached**: the iteration note above, plus a pointer/update in the
  session warm-up doc or the relevant reference doc **if the map or procedure
  changed**. (learnings-cached)

---

## 6. Research phases, and spikes vs the main path

- **Separate work into explicit phases**, each with a bounded deliverable, and
  say which phase a piece of work belongs to. Defer the hard/advanced piece
  explicitly rather than half-building it — e.g. get an intermediate output
  trusted before building the final quantity that depends on it. (separate-work-explicit)

- **Distinguish research spikes from the maintained pipeline.** Exploratory
  scripts are worth keeping for reference, but the repo map must make clear what
  "the pipeline" actually is versus what was an older spike, so a new session
  doesn't mistake a dead branch for the main path. (distinguish-research-spikes)

- **Keep a "known open items" / deferred list** so the boundary between "done",
  "deferred by choice", and "not yet attempted" is never ambiguous. (keep-known-open)

---

## 7. Reading & summarizing source articles

When a paper, tool, or reference method matters to the project:

- **Write a self-contained notes file so the source never has to be re-read.**
  Capture everything algorithmically relevant: the exact method/pipeline and its
  parameters, the definitions and formulae, calibration details, and **sanity-check
  values** you can validate your own outputs against. (write-self-contained)

- **Capture the method that exists only inside a figure.** Part of a source's
  actual procedure is often drawn rather than written — a panel's inset, an
  annotated overlay, a legend. Extract and describe it in the notes; a summary
  built from the prose alone silently omits it, and the omission is invisible
  until someone re-opens the source. (capture-method-exists)

- **Write down what the source *fails* to say**, as an explicit gap list — the
  parameters, thresholds and units it never states. Recording an absence is what
  stops the next reader re-opening the source to hunt for something that was
  never in it. The intake is done when the notes make the original redundant, and
  a stated gap is part of that. (write-down-source)

- **Explicitly record where your approach diverges from the reference and why.**
  (explicitly-record-approach)

- **State what you deliberately omitted** (material not relevant to the
  algorithm — e.g. procedural/experimental setup detail, incidental statistics,
  acknowledgements) and that you cross-checked against the full text — so a later
  reader trusts the summary is complete for its purpose. (state-deliberately-omitted)

- Note that upload paths for source PDFs are **session-specific and won't
  persist**; the notes file is the durable artifact, not the upload.

---

## 8. Extracting images — samples vs illustrations

- **Samples** are inputs you will run the algorithm on; **illustrations** are
  figures that explain a method or a definition. Keep the two roles distinct and
  store extracted figures alongside the notes that reference them. (samples-rule)

- **Render documents with a library, not an assumed system binary.** The
  environment often lacks common tools (e.g. a PDF rasterizer such as poppler /
  `pdftoppm`); use an in-process library instead. Locate embedded raster images
  and render just the region you need, at a zoom high enough to read fine
  annotation, with a little padding to catch ink drawn outside the frame. (render-documents-library)

- **Verify identity when an extracted image should match an existing input**
  (e.g. an annotated crop over an original) by an exact pixel diff — so you know
  an annotation set is a labelling of the *same* data, not a new input. (verify-identity-extracted)

---

## 9. Fetching more sample data from the outside

- **Grow the corpus from public sources that match the input regime.** Curate and
  **rank candidates by fit** = modality match × ground-truth availability × ease
  of access, and record licence and provenance for each. (grow-corpus-public)

- **Make ingestion a committed, repeatable fetch script**, not a manual download,
  so anyone can reproduce the corpus. (make-ingestion-committed)

- **Respect the two validation tiers — and don't mix them:** (respect-validation-tiers)
  - **Full ground truth** (per-item annotations) → scores the *algorithm's
    detailed output* (overlap / detection) on the real harness.
  - **Aggregate label only** (a published summary number, no per-item
    annotation) → validates the *summary quantity* the project reports, and
    nothing finer.
  Wiring an aggregate-only dataset into the detailed-overlap harness would force
  you to **fabricate annotations**, which violates §2. Keep a separate,
  mask-free validation path for those sets.

- **External data is rarely drop-in.** Expect a scale/regime gap (§3) and
  *measure* it with the appropriate tier rather than assuming the corpus is
  covered. (external-data-rarely)

---

## 10. Environment limitations — stay lightweight

- **A fresh container has nothing installed.** Assume dependencies must be
  installed each session, and keep the dependency set **small and lightweight** —
  favour a compact set of core libraries over heavy frameworks (e.g. large ML
  stacks) that are slow to install and awkward to run anywhere. (fresh-container-has)

- **When a heavy or learned approach is genuinely the right tool, treat it as a
  gated, isolated route** (documented, opt-in, scoped to the cases that need it)
  rather than a new baseline dependency — and prove the lightweight route is
  exhausted first. (heavy-learned-approach)

- **Route around missing system binaries with libraries** (see §8). Document the
  exact install lines and any "install ad hoc, not in requirements" tools in the
  warm-up doc. (route-around-missing)

---

## 11. Getting — and evaluating — algorithm ideas from the owner

The owner will suggest algorithms and directions to try next. Treat these as
first-class experiments:

- **Take the suggestion seriously even when the project has declared a direction
  "exhausted."** A suggestion may belong to a *different family* than everything
  tried so far, which is exactly when it can break a wall the previous family
  couldn't. (take-suggestion-seriously)

- **Evaluate it the same way as any change**: diagnose the wall it targets, build
  the evidence that the wall is real (or isn't), prototype, and show a comparison.
  (evaluate-same-way)

- **Beat the naive baseline, or drop it.** A more sophisticated or signal-driven
  method is only worth adopting if it *measurably* out-scores the simple/uniform
  baseline — sophistication is not accuracy when the guiding signal is noisy or
  penetrates the structure unevenly. Keep the roles of a signal distinct, too: a
  feature that is excellent for *visualising or validating* a structure can be
  wrong for *defining* it — gating the output directly on such a signal can erode
  the very structure you are measuring. (beat-naive-baseline)

- **Document the outcome fully**, including the routes that hit a wall and *why*
  (name the specific trade-off or signal that defeated them). If the idea needs
  capabilities the environment won't allow (§10), record the concrete route to
  try when that changes, so the thread is resumable rather than lost. (document-outcome-fully)

- **Complementary routes are not competitors.** Two methods can attack the same
  problem from different angles; keep both documented and say how they relate.
  (complementary-routes-competitors)

---

## 12. Record cross-domain applicability **out-of-band**

When a sub-step of the algorithm plausibly applies to **another problem** beyond
the current task, record it as a **short pointer in a dedicated side document** —
a direction worth attention, not a validated claim. **Keep this speculation out
of the algorithm itself**: code and inline comments stay strictly about the task
at hand and its stated assumptions. Add an entry whenever you build or
substantially change a sub-step.

---

## 13. Continuity across sessions

The owner works across many sessions and machines. Every session should end in a
**resumable** state.

- **Commit and push** finished units of work; leave the project runnable from a
  clean checkout. (commit-push)

- **Maintain a session warm-up doc** (the "read this first" map): what the project
  is, how to run it, where the tuned parameters and the deep rationale live, and
  the current numbers. It should let a new session skip re-reading the whole
  codebase. (maintain-session-warm)

- **Maintain a continuation guide**: where things stand, exact run commands, the
  tuned parameters and *why they exist*, and the open items. Keep the headline
  metrics current in it. (maintain-continuation-guide)

- **When the owner asks for a different way to do something, capture the new way
  durably — don't just do it this once.** A correction to *how* work is done (how
  results are shown, what command to run, a naming/format convention, a step to
  always take or skip) is a standing preference, not a one-off. Fold it into the
  warm-up doc — or a reference doc linked from it. Prefer editing the doc that
  already owns that topic over adding a stray note; if the change contradicts
  what's written, replace it and say what changed. The test: *could a fresh
  session, with only the warm-up doc, reproduce this new behaviour?* If not, it
  isn't captured yet. (owner-asks-different)

- Follow the repo's **branch/commit/PR conventions**: develop on the named
  branch, commit with clear messages, push; don't open a PR unless asked.

---

## 14. Reviving a prior session to **enhance this document** (not to continue the research)

Some of the owner's process preferences live only in the **dialogue of earlier
Claude Code (web) sessions**, not in any committed file. If the owner revives
such a session and points it at this playbook, here is the instruction for that
revived session:

> **Your job in this revived session is to mine our conversation for *process and
> working-style preferences*, and fold them into this playbook — NOT to continue
> the research task itself.**
> Re-read the whole dialogue and extract only the durable, project-agnostic
> signal about *how the owner wants research run*: how they want results shown;
> what they praised or rejected about the workflow (not just the algorithm);
> ground-truth and annotation conventions; anti-overfitting rules they insisted
> on; how they want articles summarized, images extracted, and external data
> fetched; environment constraints they flagged; and how they hand off algorithm
> ideas. For each item, strip out anything specific to this project's subject
> matter and generalise it to the class of "run a CV/analysis algorithm over
> similarly-formatted inputs, scored against user ground truth, improved in
> reviewable iterations." Then propose additions/edits to the relevant numbered
> section above (merge, don't duplicate; keep the principle-first phrasing). Show
> the owner a diff of what you'd add and confirm the wording before committing.
> **Do not run or modify the research pipeline.** If a preference contradicts what
> is already written here, surface the conflict for the owner rather than silently
> overwriting.

To make revival productive, when the owner asks for it they should say **which
session(s)** to revive (a link or a description) and, if possible, what topic the
process discussion centred on — so the revived session knows where in the
transcript to look.
