# hello 1.4

- **The hello pack loaded** — this rule came from the hello pack's vendored tree; nothing to act on.
- **The hello rule changed** — this bullet arrived with hello 1.1.
- **The hello guard arrived** — this bullet arrived with hello 1.2, with the hello-guide skill, the hello-guard declaration and the hello-judge check.
- **The hello SDK probes arrived** — this bullet arrived with hello 1.3, with the hello-change and hello-config checks.
- **The hello tasks arrived** — this bullet arrived with hello 1.4, with the hello-fold and hello-agent tasks and the hello-generated merge rule.
