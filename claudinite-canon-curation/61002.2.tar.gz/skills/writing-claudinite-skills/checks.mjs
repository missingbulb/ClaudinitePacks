import noEnforcementNarration from './no-enforcement-narration.mjs';
import usageDeclared from './usage-declared.mjs';

// The check-the-work rules validating this skill's action — authoring a skill
// in the Claudinite corpus. Discovered by engine/pack_loader/pack-registry.mjs, run at every
// Stop and in CI; inert outside the canon home repo.
export default [noEnforcementNarration, usageDeclared];
