# claudinite-fleet-sheepdog — the fleet enforcer marker

## Acting on what a sweep reports

- **Acting on an `add-packs` work-list issue** — the work is a declaration and a reviewed PR **in
  the named member**, never here. A session in this repo is scoped to this repo, so if every item
  names another repo there is nothing here to do: say the scope is the blocker rather than writing
  to the issues, which are the only thing within reach and are not the work. (acting-add-packs)

- **Acting on a scanned pack suggestion** — it is a recommendation, never a verdict.
  A fingerprint is a way to *suspect* a pack is wanted; whether to declare it is the member's call,
  and closing the issue `not planned` is a standing answer the scan honours rather than re-opening.
  A **forced** addition is the other thing entirely — a decision already made — so adopt what
  its issue says instead of re-judging whether it was wanted. (acting-scanned-pack)

- **Reading `unknown` in a report** — it means the sweep could not look, not that it looked and
  found nothing. Never convert one into a verdict: a repo whose declaration could not be read is
  neither covered nor uncovered, an undecided fingerprint is not a non-match, and a member the
  pack-seed sweep could not reach is not converged. Fix the access and re-run.
  (reading-unknown-report)

- **Judging whether a member is behind** — ask what its own update would move it to: its engine
  pin against the published engine versions, each held pack against the published pack versions
  (`cn fleet judge <owner/name>` answers it, and `.claudinite/fleet/roster.GENERATED.json` holds the
  last sweep's answer for every member), never a commit, a canon repository or the age of any stamp.
  A member's own update acts on exactly that, so any other measure reports a gap the member will
  never close, or misses one it will. (judging-whether-member)

- **Answering why the fleet did not move** — read the member's own artifacts first: its
  declaration, its stamp, the runs on its head sha. This repo dispatches; each member updates
  itself, with its own token and its own delivery policy. Propose a settings change as a conclusion,
  never as the diagnosis. (answering-fleet-did)

## Running the manual levers

- **Pushing canon to the whole fleet now** — create the work item, from a checkout of this repo:
  (pushing-canon-whole)

  ```
  .claudinite/bin/cn work create \
    claudinite-fleet-sheepdog/fleet-update
  ```

  Add `--context "REPOS=owner/a owner/b"` to narrow it (space-separated: a Context line splits on
  commas), `--context "DRY_RUN=true"` to see the list without dispatching, or
  `--context "INCLUDE_DORMANT=true"` to reach members that stopped their own scheduler on purpose.
  Both knobs are read from the item's Context and nowhere else — an item created without them runs
  unscoped and live. It queues one run per member and then FOLLOWS each to the published engine
  and pack versions, reporting per member whether it updated, was already current, or never got
  there — never a count of accepted dispatches. A member with nothing to do reads
  `already-current`, which is a success, so over-using it is wasteful rather than unsafe.

- **Adding a pack across the fleet** — create a `fleet-add-missing-packs` item with
  `--context "ADD_PACKS=…"` rather than editing anything. No pack is named anywhere in this pack's
  code: every id comes from config or from the item's own Context, which is what keeps the
  enforcer from becoming a second place packs are known. (adding-pack-across)

## Credentials

- **Granting or repairing `FLEET_GITHUB_TOKEN`** — a fine-grained PAT spanning the owner's
  repositories, granted exactly what `cn fleet token` prints — the only
  place the permissions are written, because a per-sweep subset is always a defensible answer and
  never the right one. Grant it whole: the token is granted once, for the pack.
  (granting-repairing-fleetgithubtoken)

- **A sweep reporting `403` or `no-permission`** — the grant is short a permission, which the
  error names. It is a grant to fix once, so widen the token rather than re-running: no sweep
  retries, because a work list nobody will act on is not a green outcome. (sweep-reporting-403)
