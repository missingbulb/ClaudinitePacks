// The usage FOLD's counting and folding core. Every function here is pure and
// individually tested; the worker is the I/O shell that reads the logs branch,
// calls these, and delivers the result.
//
// The questions this answers, one tested function each:
//   - which skills did a captured session LOAD, and how often;
//   - what workload was that against (captures, merges, sessions, user messages,
//     user commands) — the denominators without which a raw load count cannot
//     distinguish healthy-rare from broken;
//   - what each scheduled occurrence came to. That family comes from the queue's
//     own closed work items rather than from a captured session, which is why it is
//     a census of scheduled work where everything else here is a sample of captured
//     sessions.
//
// Zeros are implicit throughout: a mounted skill with no loads simply has no key.
// The zero set is derived by the consumer, diffing against the repo's mounted
// skills — which is exactly what makes "this skill never loads" visible at all.

// "Which skills does this repo mount" is read off the declared packs' own trees, the
// list the engine hands the task; the task-exec status vocabulary is the queue's
// wire, beside the record parse, so the counter keys here cannot drift from the
// words the runs actually emit.
import { existsSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import { TASK_EXEC_STATUSES, parseTaskExecs } from './queue-wire.mjs';
// The file's on-disk shape is the format module's. Everything below
// works in the NAMED counter shape and meets the tuples only at the two boundary
// functions at the foot of this file.
import { isUserMessage, commandName, skillToolLoads, entryText } from './capture-entries.mjs';
import { countCorpusUse, countMoments, countCheckTiming } from './corpus-use.mjs';
import { readCheckBuild, foldCheckBuild } from './check-build.mjs';
import {
  USAGE_FIELDS, USAGE_VERSION, CAPTURE_DAY_FIELDS, WEEK_FROM_DAY, QUEUE_OUTCOMES,
  COUNTER_GROUPS, BARE_MAPS, MAX_FIELDS, USAGE_CAPS, hourKey, encodeUsageFile, decodeUsageFile,
} from './usage-format.mjs';

// --- entry classification -----------------------------------------------------
// The per-entry readers live beside the second counting pass that asks the same
// questions of the same shapes. Re-exported here because a member's own code may
// import them by this path.
export { isUserMessage, commandName, skillToolLoads, entryText };

// --- check activations ---------------------------------------------------------
// The conformance checks are the other half of the picture, and the more valuable
// half: a check that FAILS is a win — the finding lands back in the session and the
// agent corrects before the work leaves. So the questions here are "how often did
// each scope actually run" and "how often did it catch something", and the second
// one is the one that matters.
//
// Neither runner writes a metrics file, so both are read off the marks they already
// leave in the transcript. There are exactly three, and each was verified against
// real captured logs:
//
//   1. The Stop hook's `hooklog` line — `<iso> run=<id> Stop: done exit=<n> <reason>`
//      — reaches the transcript because hooklog mirrors to stderr and the harness
//      records hook stderr. This is the ONLY mark that survives a PASSING run, which
//      is what makes work-scope run counts (not just failure counts) possible at all.
//   2. `report-findings`' summary line — `N blocking, M advisory (<scope> scope: …)`
//      — names its own scope and survives the `| tail` an agent usually pipes
//      through. It is printed ONLY when there were findings, so it counts failures
//      and finding volume, never runs.
//   3. The runner's own invocation in a Bash command (`node …/check_the_world.mjs`),
//      which is how the world scope runs — its Stop-hook sibling does not exist,
//      because the world sweep is wired into the test/CI flow, not the hook.
//
// CI COUNTS WHEN THE AGENT WAS IN THE LOOP ON IT. The write-commit-watch-CI-fix-it
// cycle is the same correction loop as the Stop hook's, one turn wider, so a CI
// check failure the session acted on is as much a win as a hook one. It is counted
// exactly when the session PULLED THE JOB LOG IN — which is what "the agent was in
// the loop" means operationally. A nightly or post-merge run nobody looked at stays
// uncounted, correctly: nothing was corrected. Those logs come through a CI-log tool
// rather than Bash, and their lines carry the Actions timestamp prefix, so both are
// read below.
//
// STATED BOUNDARY: this counts what the SESSION saw. A sweep whose CI log nobody
// fetched is invisible here, and so is a hook killed before it logged. A CI run is
// also only visible when it PRINTED something — a green sweep prints nothing at all
// — so `ciRuns`/`ciFailures` record the CI share separately, and a consumer wanting
// a clean session-only rate subtracts them. Every number below is a floor on
// activations, never an over-count, which is the direction that keeps "the checks
// caught N things" honest.

// The Stop hook's completion line. `reason` distinguishes the three outcomes the
// hook itself declares: `checks-passed`, `blocking-findings`, `loop-guard-relent`
// (blocking findings that survived two fix attempts — a failure that prints no
// findings block, so it must be read from here), and `runner-error` (the checks did
// not run at all, which is an anti-win masquerading as a quiet day).
const HOOK_DONE_RE = /(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z) run=(\S+) Stop: done exit=(\d+) ?([a-z-]*)/g;
export function hookCheckRuns(text) {
  return [...String(text ?? '').matchAll(HOOK_DONE_RE)]
    .map((m) => ({ stamp: `${m[1]} ${m[2]}`, exit: Number(m[3]), reason: m[4] || null }));
}

// A GitHub Actions log line stamps its own timestamp in front of the command's
// output, so every mark below has to tolerate that prefix or a fetched CI log reads
// as having printed nothing at all. Optional, and still anchored to the line start.
const ACTIONS_STAMP = String.raw`(?:\d{4}-\d{2}-\d{2}T[\d:.]+Z )?`;

// `report-findings`' summary line, which names the scope it ran. Anchored to the
// line start so a doc or a fixture quoting the shape mid-sentence never counts.
const SUMMARY_RE = new RegExp(`^${ACTIONS_STAMP}(\\d+) blocking, (\\d+) advisory \\((work|world) scope: `, 'gm');
export function checkSummaries(text) {
  return [...String(text ?? '').matchAll(SUMMARY_RE)]
    .map((m) => ({ scope: m[3], blocking: Number(m[1]), advisory: Number(m[2]) }));
}

// The rendered header of one finding — `[BLOCKING] <rule>  <file>` — which is where
// the RULE ID lives. Per-rule counts are the actionable end of this: "which rule
// catches something, and how often". They are lossier than the summary totals (an
// agent that pipes the run through `tail -3` keeps the summary and drops the
// headers), so both are kept and a gap between them is visible truncation.
const HEADER_RE = new RegExp(`^${ACTIONS_STAMP}\\[(BLOCKING|ADVISORY)\\] ([a-z0-9][a-z0-9-]*) {2}`, 'gm');
export function findingHeaders(text) {
  return [...String(text ?? '').matchAll(HEADER_RE)]
    .map((m) => ({ severity: m[1] === 'BLOCKING' ? 'blocking' : 'advisory', rule: m[2] }));
}

// Runner invocations inside one Bash command. Requires `node` and the `.mjs` on the
// same shell word run — so `grep -i check_the_world` never counts — and the
// separator class stops one match from swallowing a second runner on the same line.
const INVOKE_RE = /\bnode\b[^\n;|&]*?\bcheck_the_(work|world)\.mjs\b/g;
export function checkInvocations(command) {
  const counts = { work: 0, world: 0 };
  for (const m of String(command ?? '').matchAll(INVOKE_RE)) counts[m[1]] += 1;
  return counts;
}

// A tool that fetches CI job logs — the one way a CI run reaches a session, and
// therefore the one way "the agent was in the loop on this CI run" is observable.
// Matched by name shape rather than by one hardcoded tool: the same session can
// reach CI through an MCP server, a different server, or a future rename, and all of
// them say what they are in their name.
const CI_LOG_TOOL_RE = /(job|run|workflow)_logs/i;

// The transcript entries that can carry check output, reduced to the text to read
// and the source that produced it. Five shapes, all verified against real captures:
// the hook's blocking feedback (an `isMeta` user turn), the harness's
// `stop_hook_summary` (which repeats that same stderr), the passing hook's
// `hook_success` attachment, a Bash tool result, and a fetched CI job log — the last
// two paired back to the tool that produced them, so a Read of a file that merely
// CONTAINS this vocabulary is never mistaken for a run.
//
// Two different duplicate problems, so two different identities:
//   - the first two shapes are ONE hook execution recorded twice, so hook texts
//     dedupe on the `hooklog` stamps they carry — stable across both shapes and
//     unique per execution (its own timestamp, to the second);
//   - a CI job log can be fetched repeatedly (re-read while iterating), and there is
//     no per-fetch identity that says which RUN it was, so CI texts dedupe on the
//     check output itself. Two fetches of one job are byte-identical and collapse;
//     two real runs differ by their Actions timestamps at least. Two genuinely
//     identical runs would collapse too — an under-count, which is the direction
//     this whole counter is allowed to be wrong in.
// A Bash result needs neither: each tool call is its own run, and the invocation is
// counted from the command.
export function checkOutputs(entries) {
  const toolById = new Map();
  for (const entry of entries) {
    if (entry?.type !== 'assistant') continue;
    for (const block of entry?.message?.content ?? []) {
      if (block?.type !== 'tool_use' || typeof block?.name !== 'string') continue;
      if (block.name === 'Bash' && typeof block?.input?.command === 'string') {
        toolById.set(block.id, { source: 'bash', command: block.input.command });
      } else if (CI_LOG_TOOL_RE.test(block.name)) {
        toolById.set(block.id, { source: 'ci', command: null });
      }
    }
  }

  const out = [];
  const seenHooks = new Set();
  const seenCi = new Set();
  const hook = (text) => {
    const key = hookCheckRuns(text).map((r) => r.stamp).join('|');
    if (key && seenHooks.has(key)) return;      // the same execution, recorded twice
    if (key) seenHooks.add(key);
    out.push({ source: 'hook', text, command: null });
  };

  for (const entry of entries) {
    if (entry?.type === 'system' && entry?.subtype === 'stop_hook_summary') {
      hook((entry.hookErrors ?? []).join('\n'));
    } else if (entry?.type === 'attachment' && entry?.attachment?.hookEvent === 'Stop') {
      hook(`${entry.attachment.stderr ?? ''}\n${entry.attachment.stdout ?? ''}`);
    } else if (entry?.type === 'user' && entry?.isMeta === true && typeof entry?.message?.content === 'string') {
      if (entry.message.content.includes('Stop hook feedback')) hook(entry.message.content);
    } else if (entry?.type === 'user' && Array.isArray(entry?.message?.content)) {
      for (const block of entry.message.content) {
        if (block?.type !== 'tool_result') continue;
        const tool = toolById.get(block.tool_use_id);
        if (tool === undefined) continue;       // neither a runner nor a CI log — not a run
        const text = resultText(entry.toolUseResult, block.content);
        if (tool.source === 'ci') {
          // The CI log's OWN content is its identity; a fetch that carried no check
          // output at all (a green run, a different job) is not a run to dedupe.
          const key = checkOutputKey(text);
          if (!key || seenCi.has(key)) continue;
          seenCi.add(key);
        }
        out.push({ source: tool.source, text, command: tool.command });
      }
    }
  }
  return out;
}

// A tool result's text, whichever shape the tool reports in: Bash reports
// `{ stdout, stderr }`, an MCP tool reports content blocks the harness also copies
// onto the result block. Both are read, so neither tool family needs special-casing
// beyond this one function.
function resultText(result, blockContent) {
  if (typeof result === 'string') return unwrapJson(result);
  if (result && (typeof result.stdout === 'string' || typeof result.stderr === 'string')) {
    return `${unwrapJson(result.stdout ?? '')}\n${result.stderr ?? ''}`;
  }
  if (typeof blockContent === 'string') return unwrapJson(blockContent);
  if (Array.isArray(blockContent)) {
    return unwrapJson(blockContent.map((b) => (typeof b?.text === 'string' ? b.text : '')).join('\n'));
  }
  return result === undefined || result === null ? '' : unwrapJson(JSON.stringify(result));
}

// An MCP tool returns its payload as a JSON DOCUMENT inside a text block, so a job
// log's newlines arrive escaped and every mark below — all of them line-anchored —
// would see one enormous single line and match nothing. Decode by parsing and
// joining every string leaf with real newlines: field names never matter, so this
// holds for whichever tool or server delivers the log. Text that is not JSON is
// returned untouched, which is every Bash stdout.
function unwrapJson(text) {
  const trimmed = String(text ?? '').trim();
  if (!trimmed.startsWith('{') && !trimmed.startsWith('[')) return text;
  let parsed;
  try { parsed = JSON.parse(trimmed); } catch { return text; }
  const strings = [];
  const walk = (value) => {
    if (typeof value === 'string') strings.push(value);
    else if (Array.isArray(value)) value.forEach(walk);
    else if (value && typeof value === 'object') Object.values(value).forEach(walk);
  };
  walk(parsed);
  return strings.join('\n');
}

// The check output a text carries, as one string — the identity of a CI job log for
// deduping. Built from the marked lines only, so unrelated log noise around them
// (which differs between a tailed fetch and a full one) cannot make one run look
// like two.
function checkOutputKey(text) {
  const marks = [
    ...String(text ?? '').matchAll(SUMMARY_RE),
    ...String(text ?? '').matchAll(HEADER_RE),
  ].map((m) => m[0]);
  return marks.length ? marks.join('|') : null;
}

// An empty per-scope check row. Uniform across scopes so folding is one loop:
// `runs` is observed activations, `failures` the subset that reported at least one
// blocking finding, `errors` the runs where the runner itself could not launch, and
// `blocking`/`advisory` the finding VOLUME summed over those runs (a rule blocking
// twice across two runs counts twice — the question is how often the checks caught
// something, not how many distinct problems existed).
//
// `ciRuns`/`ciFailures` are the SUBSET of `runs`/`failures` that came from a CI job
// log the session pulled in, carried separately because that source can only see a
// run that printed something: a green CI sweep prints nothing and is invisible. A
// consumer wanting a rate over runs it can see the whole of subtracts them; one
// asking "how often did the checks catch something" adds nothing and uses the total.
const emptyScope = () => Object.fromEntries(USAGE_FIELDS.checks.map((f) => [f, 0]));

// Count check activations across one capture file's entries.
//
// Runs are counted from the marks that a PASSING run also leaves — hook completion
// lines, and Bash invocations — never from the summary line, which only a run with
// findings prints. Where a runner ran without its command naming it (a `make test`
// step that wraps it), the summary lines in its output are the floor: hence the
// `max` — the two signals are alternative views of the same runs, not additive ones.
export function countChecks(entries) {
  const checks = {};
  const checkFindings = {};
  const scope = (name) => (checks[name] ??= emptyScope());
  const emptyFinding = () => Object.fromEntries(USAGE_FIELDS.checkFindings.map((f) => [f, 0]));
  const finding = (rule, severity) => { (checkFindings[rule] ??= emptyFinding())[severity] += 1; };
  // The findings each Stop sweep printed, in order - `persisted` reads the last
  // one (what the session left standing), `relent` the one before a sweep that
  // gave up, which prints its reason instead of its findings.
  const blocks = [];

  for (const { source, text, command } of checkOutputs(entries)) {
    const summaries = checkSummaries(text);

    if (source === 'hook') {
      const headers = findingHeaders(text);
      if (headers.length) blocks.push(headers);
      // The hook only ever runs the WORK scope, and its completion line is the run.
      for (const run of hookCheckRuns(text)) {
        const work = scope('work');
        work.runs += 1;
        if (run.reason === 'runner-error') work.errors += 1;
        // A relent prints the reason instead of the findings, so its failure is
        // visible here and nowhere else - and the sweep it gave up on is the last
        // one that printed any, which is the block its rules are read from.
        if (run.reason === 'loop-guard-relent') {
          work.failures += 1;
          for (const rule of new Set((blocks.at(-1) ?? []).map((f) => f.rule))) {
            (checkFindings[rule] ??= emptyFinding()).relent += 1;
          }
        }
      }
      for (const s of summaries) if (s.blocking > 0) scope(s.scope).failures += 1;
    } else if (source === 'ci') {
      // A CI log has no invocation to count — the summary lines ARE the runs, and
      // only the runs that printed. Recorded in the totals AND in the ci-only
      // counters, so the visible-in-full share stays derivable.
      for (const name of ['work', 'world']) {
        const reported = summaries.filter((s) => s.scope === name);
        if (reported.length === 0) continue;
        const failed = reported.filter((s) => s.blocking > 0).length;
        const row = scope(name);
        row.runs += reported.length;
        row.ciRuns += reported.length;
        row.failures += failed;
        row.ciFailures += failed;
      }
    } else {
      const invoked = checkInvocations(command);
      for (const name of ['work', 'world']) {
        const reported = summaries.filter((s) => s.scope === name);
        const runs = Math.max(invoked[name], reported.length);
        if (runs === 0) continue;
        scope(name).runs += runs;
        scope(name).failures += reported.filter((s) => s.blocking > 0).length;
      }
    }

    for (const s of summaries) {
      const row = scope(s.scope);
      row.blocking += s.blocking;
      row.advisory += s.advisory;
    }
    for (const f of findingHeaders(text)) finding(f.rule, f.severity);
  }
  // A rule this capture file saw at all was seen in one session - the day tier
  // reduces these to distinct sessions, which is the denominator the "fires in most
  // sessions" rule reads.
  for (const row of Object.values(checkFindings)) row.sessions = 1;
  // What the session's LAST sweep still carried: an advisory standing there is one
  // nobody acted on, which is the whole of the advisory-ignored rule's evidence.
  for (const f of blocks.at(-1) ?? []) {
    if (f.severity === 'advisory') (checkFindings[f.rule] ??= emptyFinding()).persisted += 1;
  }
  return { checks, checkFindings };
}

// --- per-file counting ---------------------------------------------------------

// An empty per-task execution row — every status present, zeros included, same
// fixed-shape discipline as the scheduler's task-run rows.
export const emptyTaskExec = () => Object.fromEntries(TASK_EXEC_STATUSES.map((s) => [s, 0]));

// The executor-side task statuses one capture file attests: `claudinite-task-exec`
// records (the owned contract, never scraped prose), DEDUPED on
// the full (pack, task, slot, status) tuple within the file. One session runs one
// dispatch, so a record echoed by the model, or repeated across a command's
// stdout and the harness's copy of it, collapses to the one execution it names;
// a retry of the same slot is a different session, hence a different capture
// file, and still counts.
// @deprecated The `taskExec` rows have a successor: the `queue` rows of
// `.claudinite/usage/task-runs-and-costs.json`, which read what each occurrence
// came to off the item itself rather than off whether its session happened to
// capture (the README's "The machinery half"). Still
// written, and still a sample of the sessions that captured; retiring it is a later
// plan of its own.
export function countTaskExecs(entries) {
  const seen = new Set();
  const taskExec = {};
  for (const entry of entries) {
    for (const rec of parseTaskExecs(entryText(entry).join('\n'))) {
      const key = `${rec.pack}/${rec.task}|${rec.slotId}|${rec.status}`;
      if (seen.has(key)) continue;
      seen.add(key);
      const row = (taskExec[`${rec.pack}/${rec.task}`] ??= emptyTaskExec());
      row[rec.status] += 1;
    }
  }
  return taskExec;
}

// --- what Claudinite put into the session, and what the session cost --------------

// What the session spent, from the usage records the transcript's own assistant
// entries carry. ASPIRATIONAL AND PROBED, never assumed: a transcript shape that
// records no usage returns null, and the consumer states the series as absent rather
// than drawing a zero line that would read as a free session.
//
// Cache reads and cache writes are counted into `in` because they are input tokens the
// turn was billed for; a consumer wanting the uncached share cannot have it from here
// and is not offered a number that looks like it.
export function tokensIn(entries) {
  let input = 0;
  let output = 0;
  let seen = false;
  for (const entry of entries) {
    const u = entry?.type === 'assistant' ? entry?.message?.usage : null;
    if (!u || typeof u !== 'object') continue;
    const n = (v) => (typeof v === 'number' && Number.isFinite(v) ? v : 0);
    const i = n(u.input_tokens) + n(u.cache_read_input_tokens) + n(u.cache_creation_input_tokens);
    const o = n(u.output_tokens);
    if (i === 0 && o === 0) continue;
    seen = true;
    input += i;
    output += o;
  }
  return seen ? { input, output } : null;
}

// The same spend, split by the model that was billed for it — and with the four usage
// counters kept APART, where `tokensIn` sums the first three. Pricing is per model and
// per counter (a cache read is not an input token at the same rate), so a total cannot
// be priced and a split that had already summed them could not be either.
//
// An entry carrying usage and no model id keys as `(unknown)`: the spend is real and
// its rate is not knowable, which is a different state from an unpriced model.
export const TOKENS_BY_MODEL_UNKNOWN = '(unknown)';

export function tokensByModelIn(entries) {
  const out = {};
  for (const entry of entries) {
    const u = entry?.type === 'assistant' ? entry?.message?.usage : null;
    if (!u || typeof u !== 'object') continue;
    const n = (v) => (typeof v === 'number' && Number.isFinite(v) ? v : 0);
    const row = {
      input: n(u.input_tokens),
      cacheRead: n(u.cache_read_input_tokens),
      cacheCreate: n(u.cache_creation_input_tokens),
      output: n(u.output_tokens),
    };
    // The same "an entry that was billed for nothing is not a record" test `tokensIn`
    // makes, so the two agree about which entries they saw.
    if (!row.input && !row.cacheRead && !row.cacheCreate && !row.output) continue;
    const model = typeof entry?.message?.model === 'string' && entry.message.model
      ? entry.message.model : TOKENS_BY_MODEL_UNKNOWN;
    const into = (out[model] ??= { input: 0, cacheRead: 0, cacheCreate: 0, output: 0 });
    for (const field of Object.keys(row)) into[field] += row[field];
  }
  return Object.keys(out).length ? out : null;
}

// How the session's wall-clock divided between the person and the agent, from the
// entry timestamps alone.
//
// A turn's span is the gap from the previous entry to it: the time spent producing it.
// So a HUMAN turn's gap is the person's thinking-and-typing time, and an ASSISTANT
// entry's gap is the agent's. Every other entry shape — a tool result, an injected
// turn — closes the gap for whatever comes next rather than claiming it.
//
// THE CAP is on the human side only, and it is what makes `humanSeconds` a floor: a
// session left open overnight shows a twelve-hour gap before its next human turn, and
// that is not twelve hours of a person's attention. The agent side needs no cap — an
// assistant entry follows its request in machine time — and capping it would hide the
// long runs that are exactly what the figure is for.
//
// SIDECHAIN ENTRIES ARE EXCLUDED from both: a subagent runs inside a main-stream turn
// whose span is already counted, so counting it again would bill the same seconds
// twice and could exceed the wall clock.
//
// Absent, never zero, for a transcript shape whose entries carry no timestamp: the
// session's own time is unknown, and a zero would read as an instant one.
export function turnSeconds(entries, cap = USAGE_CAPS.humanSeconds) {
  const stamped = entries
    .filter((e) => e?.isSidechain !== true && typeof e?.timestamp === 'string')
    .map((entry) => ({ entry, at: Date.parse(entry.timestamp) }))
    .filter(({ at }) => Number.isFinite(at))
    .sort((a, b) => a.at - b.at);
  if (!stamped.length) return null;
  let human = 0;
  let agent = 0;
  let prev = null;
  for (const { entry, at } of stamped) {
    // A clock that went backwards between two entries yields no span rather than a
    // negative one.
    const gap = prev === null ? null : Math.max(0, (at - prev) / 1000);
    if (gap !== null) {
      if (isUserMessage(entry)) human += Math.min(cap, gap);
      else if (entry?.type === 'assistant') agent += gap;
    }
    prev = at;
  }
  return { human: Math.round(human), agent: Math.round(agent) };
}

// Which task a captured session belongs to, for the per-task cost split. The join is
// the executor's own `claudinite-task-exec` record, already counted into `taskExec` by
// the same pass — so this costs nothing beyond reading its keys.
//
// The two synthetic keys are states, not fallbacks: `(none)` is a session a PERSON
// started (its capture names no issue and no PR), which is the human-driven share and
// worth seeing; `(unresolved)` is a session that names an issue or a PR but attests no
// execution record, which is a gap in the record rather than a person at the keyboard,
// and must never be quietly filed as one.
export const TASK_COST_NONE = '(none)';
export const TASK_COST_UNRESOLVED = '(unresolved)';

// `keyed` is the number the capture's filename carries — its PR, or its issue.
//
// @deprecated The `taskCost` rows have a successor for the cost half of the
// question: `.claudinite/usage/task-runs-and-costs.json` carries what each run of
// the machinery was billed and what it spent in API calls, per workflow and per run
// (the README's "The machinery half"). The TOKEN share these
// rows carry has no successor there and is not meant to gain one — that is what the
// sessions spent, which is the session fold's subject. Still written; retiring it is
// a later plan of its own.
export function taskCostKey(counts, keyed) {
  const named = Object.keys(counts?.taskExec ?? {}).sort();
  if (named.length) return named[0];
  return keyed > 0 ? TASK_COST_UNRESOLVED : TASK_COST_NONE;
}

// How much a key is worth when a session's captures disagree: a named task beats
// "this ran for an issue and named no record", which beats "nobody filed this at all".
export const taskCostRank = (key) =>
  (key === null || key === undefined ? 0 : key === TASK_COST_NONE ? 1 : key === TASK_COST_UNRESOLVED ? 2 : 3);

// Names still exported are not removals: a member's local pack may import the mount by
// them, and the canon cannot see whether one does. Both always `null` — the summary
// line's token figure is no longer folded.
// @legacy-tolerance advisory:none retire:#1989
export const ruleTokensIn = () => null;
// @legacy-tolerance advisory:none retire:#1989
export const ruleTokensByPackIn = () => null;

// Count one capture file's entries. A typed `/command` counts as a skill load only
// when it names a mounted skill, which is what keeps the built-in CLI commands
// (`/model`, `/clear`, …) out. Stated overlap: a typed `/merge-to-main` counts in
// BOTH userCommands and skillLoads. One event, two axes, both true.
//
// `corpus` is what the mounted corpus offers this repo, for the counters that need
// to know it: `{ mounted, declarations, hits, ownerOf }`. Absent - a caller that
// only wants the production counters, or an engine too old to resolve the
// declarations - the counters that depend on it record no key rather than a zero.
export function countEntries(entries, corpus = {}) {
  const mounted = corpus instanceof Set ? corpus : (corpus.mounted ?? new Set());
  const skillLoads = {};
  let userMessages = 0;
  let userCommands = 0;
  const load = (name) => { skillLoads[name] = (skillLoads[name] ?? 0) + 1; };

  for (const entry of entries) {
    for (const name of skillToolLoads(entry)) load(name);
    if (isUserMessage(entry)) userMessages += 1;
    const command = commandName(entry);
    if (command !== null) {
      userCommands += 1;
      if (mounted.has(command)) load(command);
    }
  }
  const checks = countChecks(entries);
  const use = countCorpusUse(entries, mounted);
  return {
    userMessages,
    userCommands,
    skillLoads,
    tokens: tokensIn(entries),
    tokensByModel: tokensByModelIn(entries),
    seconds: turnSeconds(entries),
    taskExec: countTaskExecs(entries),
    ...checks,
    ...use,
    moments: countMoments(entries, corpus.declarations ?? [], corpus.hits ?? {}),
    checkTiming: countCheckTiming(entries),
    checkBuild: readCheckBuild(entries),
    skillCaught: caughtSkills(Object.keys(use.skillLoadsBy), checks.checkFindings, corpus.ownerOf),
  };
}

// The skills that loaded and were then caught anyway by a check they own. Per
// capture file, so the day tier's count is sessions rather than findings - a
// session caught three times by one rule is one session the skill did not save.
// `ownerOf` maps a rule id to the skill that owns it; without it no key is written.
export function caughtSkills(loaded, checkFindings, ownerOf) {
  if (typeof ownerOf !== 'function') return {};
  const out = {};
  const held = new Set(loaded);
  for (const [rule, row] of Object.entries(checkFindings ?? {})) {
    if (!(row?.blocking > 0)) continue;
    const skill = ownerOf(rule);
    if (skill && held.has(skill)) out[skill] = 1;
  }
  return out;
}

// --- day buckets ---------------------------------------------------------------

// An empty day row — the shape every counter folds through. Only the CAPTURE-derived
// scalars are zeroed: those are answered by files this fold reads in full every run,
// so zero is a fact about the day. Every other day field is left ABSENT until a source
// that can answer it does, because a source that could not be read is unknown and a
// zero written for it would read as a quiet day.
const emptyDay = () => ({
  ...Object.fromEntries(CAPTURE_DAY_FIELDS.map((f) => [f, 0])),
  // Driven off the vocabularies rather than a list here, so a newly appended map
  // or group cannot be silently absent from the day tier that feeds the week one.
  ...Object.fromEntries(BARE_MAPS.map((m) => [m, {}])),
  ...Object.fromEntries(COUNTER_GROUPS.map((g) => [g, {}])),
});

// An empty hour row. All four counters are zeroed: an hour inside the window with no
// runs in it genuinely had none — the run listing covers the whole window or the fold
// does not advance its watermark at all.
const emptyHour = () => ({ ...Object.fromEntries(USAGE_FIELDS.hour.map((f) => [f, 0])), taskExec: {} });

function addLoads(into, from) {
  for (const [name, n] of Object.entries(from ?? {})) into[name] = (into[name] ?? 0) + n;
}

// The check maps fold the same way skillLoads do — key-wise, zeros implicit — only
// with a fixed-shape counter object under each key instead of a bare number. A
// field the group declares as a peak takes the larger of the two rather than their
// sum; everything else adds.
function addCounters(into, from, group = null) {
  const peaks = new Set(MAX_FIELDS[group] ?? []);
  for (const [key, row] of Object.entries(from ?? {})) {
    const target = (into[key] ??= Object.fromEntries(Object.keys(row).map((k) => [k, 0])));
    for (const [field, n] of Object.entries(row)) {
      target[field] = peaks.has(field) ? Math.max(target[field] ?? 0, n) : (target[field] ?? 0) + n;
    }
  }
}

// Recompute the day rows from scratch, from the live capture files. `files` is
// `[{ date, issue, pr, sessionId, counts }]` — one entry per capture file in the raw
// window, `counts` being that file's `countEntries` result.
//
// Stateless by construction: a day is a pure function of the files stamped with it,
// so there is no ingest ledger, no double-count risk, and a counting-bug fix
// self-heals the entire visible window on its next run.
export function foldDays(files) {
  const days = {};
  const sessionsByDay = {};
  const skillSessionsByDay = {};
  const ruleSessionsByDay = {};
  // This capture's session, filed under the day and the name it attests.
  const touched = (into, file, name) => {
    const byName = (into[file.date] ??= new Map());
    if (!byName.has(name)) byName.set(name, new Set());
    byName.get(name).add(file.sessionId);
  };
  // The two PER-SESSION figures, which must not be summed over capture files: a
  // session that captured twice (a merge, then the session-end tail) writes the same
  // facts into both files, and the second is usually a superset of the first. So they
  // are collected per (day, session) and reduced at the end — the largest token spend
  // any of the session's captures attests.
  const perSession = {};
  const blankSession = () => ({
    tokens: null, tokensByModel: null,
    seconds: null, task: null, userMessages: 0,
  });
  const session = (date, id) => ((perSession[date] ??= new Map()).get(id)
    ?? (perSession[date].set(id, blankSession()), perSession[date].get(id)));

  for (const file of files) {
    const day = (days[file.date] ??= emptyDay());
    day.captures += 1;
    // A capture keyed to a PR or an issue has work behind it; issue 0 is a tail
    // capture with no merge behind it.
    if (file.pr > 0 || file.issue > 0) day.merges += 1;
    day.userMessages += file.counts.userMessages;
    day.userCommands += file.counts.userCommands;
    for (const map of BARE_MAPS) if (map !== 'skillSessions') addLoads(day[map], file.counts[map]);
    for (const group of ['checks', 'checkFindings', 'taskExec', 'skillLoadsBy', 'triggerFires', 'guardFires', 'checkTiming']) {
      addCounters(day[group], file.counts[group], group);
    }
    // The two DISTINCT-SESSION counters, which are not sums over capture files: a
    // session that captured twice wrote the same facts into both, and both figures
    // are rates per session rather than per load or per finding.
    for (const skill of Object.keys(file.counts.skillLoadsBy ?? {})) touched(skillSessionsByDay, file, skill);
    for (const rule of Object.keys(file.counts.checkFindings ?? {})) touched(ruleSessionsByDay, file, rule);
    (sessionsByDay[file.date] ??= new Set()).add(file.sessionId);

    const s = session(file.date, file.sessionId);
    const t = file.counts.tokens;
    // The per-model split rides the SAME winning capture as the total it splits, so
    // the two can never describe different captures of one session.
    if (t && (s.tokens === null || t.input + t.output > s.tokens.input + s.tokens.output)) {
      s.tokens = t;
      s.tokensByModel = file.counts.tokensByModel ?? null;
    }
    const secs = file.counts.seconds;
    if (secs && (s.seconds === null || secs.human + secs.agent > s.seconds.human + s.seconds.agent)) {
      s.seconds = secs;
    }
    // The task the session belongs to, resolved ACROSS its captures rather than per
    // capture: a session has one dispatch, but its captures disagree about the evidence
    // — the tail capture is filed under issue 0 where the merge capture named the PR,
    // and a capture written mid-run can predate the execution record the tail
    // carries. So the most-informed answer any of them gives wins.
    const key = taskCostKey(file.counts, file.pr ?? file.issue);
    if (taskCostRank(key) > taskCostRank(s.task)) s.task = key;
    // Summed over the session's captures rather than deduped, so the per-task column
    // adds up to the day's own `userMessages` scalar, which is summed the same way.
    s.userMessages += file.counts.userMessages;
  }

  foldCheckBuild(days, files);
  // Distinct sessions, not capture count: one session can capture more than once
  // (a merge, then the session-end tail).
  for (const [date, set] of Object.entries(sessionsByDay)) days[date].sessions = set.size;
  // Overwriting rather than adding: the per-file counters above attested presence,
  // and what the day carries is how many distinct sessions that came to.
  for (const [date, byName] of Object.entries(skillSessionsByDay)) {
    for (const [skill, set] of byName) days[date].skillSessions[skill] = set.size;
  }
  for (const [date, byName] of Object.entries(ruleSessionsByDay)) {
    for (const [rule, set] of byName) days[date].checkFindings[rule].sessions = set.size;
  }

  for (const [date, bySession] of Object.entries(perSession)) {
    const day = days[date];
    for (const { tokens, tokensByModel, seconds, task, userMessages } of bySession.values()) {
      // Absent until one session on this day attested a spend — the fields stay off
      // the row entirely on a day whose transcripts carried no usage records, which is
      // what makes "this shape does not record it" distinguishable from "it was free".
      if (tokens) {
        day.tokensIn = (day.tokensIn ?? 0) + tokens.input;
        day.tokensOut = (day.tokensOut ?? 0) + tokens.output;
        day.tokenSessions = (day.tokenSessions ?? 0) + 1;
      }
      if (tokensByModel) addCounters(day.tokensByModel, tokensByModel);
      // Same absence rule for the two wall-clock scalars: a day whose sessions carried
      // no entry timestamps keeps no key rather than reporting nobody worked.
      if (seconds) {
        day.humanSeconds = (day.humanSeconds ?? 0) + seconds.human;
        day.agentSeconds = (day.agentSeconds ?? 0) + seconds.agent;
      }
      // `sessions` and `userMessages` are counted off the capture files and are always
      // real; the two token columns stay ABSENT until a session of this task attested a
      // spend, so a task whose transcripts record no usage reads as unknown rather than
      // as having run for free.
      const cost = (day.taskCost[task] ??= { sessions: 0, userMessages: 0 });
      cost.sessions += 1;
      cost.userMessages += userMessages;
      if (tokens) {
        cost.tokensIn = (cost.tokensIn ?? 0) + tokens.input;
        cost.tokensOut = (cost.tokensOut ?? 0) + tokens.output;
      }
    }
  }
  return days;
}

// --- the sources outside the capture files ----------------------------------------

// Merge a day-keyed map of already-computed fields into the day rows — the shape both
// the local-git series (commits and lines) and the releases listing arrive in. A day
// the source could not speak for is simply absent from `bySource` and keeps no key,
// which is the whole point of doing this outside `emptyDay`.
export function foldDayFields(days, bySource = {}) {
  for (const [date, fields] of Object.entries(bySource)) {
    const day = (days[date] ??= emptyDay());
    for (const [field, value] of Object.entries(fields)) {
      if (typeof value === 'number' && Number.isFinite(value)) day[field] = value;
    }
  }
  return days;
}

// The queue's own record of what each occurrence came to: closed work items, per task,
// per outcome word. APPEND-ONCE past `queueFoldedThrough`, for the same reason the run
// ledger is — the items are a paged REST read where the capture files are local git —
// and safe to append because a closed item is settled: its outcome label is written at
// convergence and nothing later moves it.
//
// `records` is `[{ date, pack, task, outcome, parks }]`, already filtered by the reader
// to items that closed past the mark. `parks` is the kinds the item was parked for at
// any point in its life, each counted ONCE for it — an item bounced between a person
// and the machine twice is one park of that kind, not two — or `null` where the item's
// event listing could not be read, which costs its parks and not its outcome.
// @deprecated The `queue` and `parks` rows have a successor:
// `.claudinite/usage/task-runs-and-costs.json`, which counts the same outcomes and
// the same parks beside the latencies and costs they belong with
// (the README's "The machinery half"). This writer keeps
// running — the rows it has already written are real and its readers still read them
// — and retiring it is a later plan of its own rather than a window this one closes.
export function foldQueueOutcomes(days, priorDays = {}, records = [], today) {
  for (const [date, row] of Object.entries(priorDays)) {
    if (!withinTaskWindow(date, today, DAY_WINDOW_DAYS)) continue;
    for (const group of ['queue', 'parks']) {
      const prior = row?.[group];
      if (!prior || !Object.keys(prior).length) continue;
      (days[date] ??= emptyDay())[group] = structuredClone(prior);
    }
  }
  for (const { date, pack, task, outcome, parks } of records) {
    const day = (days[date] ??= emptyDay());
    const id = `${pack}/${task}`;
    if (QUEUE_OUTCOMES.includes(outcome)) {
      const row = (day.queue[id] ??= Object.fromEntries(QUEUE_OUTCOMES.map((o) => [o, 0])));
      row[outcome] += 1;
    }
    if (!Array.isArray(parks)) continue;
    const row = (day.parks[id] ??= Object.fromEntries(USAGE_FIELDS.parks.map((k) => [k, 0])));
    for (const kind of new Set(parks)) if (kind in row) row[kind] += 1;
  }
  return days;
}

// --- merged pull requests ---------------------------------------------------------

// What each merged PR took, filed under the day it merged. APPEND-ONCE past
// `prsFoldedThrough` for the reason the queue read is: a paged REST resource where the
// capture files are local git, and a merge is settled — `merged_at` never moves.
//
// The rows carry DURATIONS, never percentiles: a week's p50 is not the mean of its
// days' p50s, so the quantile is the reader's reduction over whatever window it draws
// and the fold's job is to carry the sample. `merged` is the key count.
//
// `records` is `[{ date, number, leadHours, issueLeadHours, sessionToMergeHours }]`; a
// slot whose far end is unknown is `null` and keeps no key, which is not a zero lead.
export function foldPrs(days, priorDays = {}, records = [], today) {
  for (const [date, row] of Object.entries(priorDays)) {
    const prior = row?.prs;
    if (!prior || !Object.keys(prior).length || !withinTaskWindow(date, today, DAY_WINDOW_DAYS)) continue;
    (days[date] ??= emptyDay()).prs = structuredClone(prior);
  }
  for (const { date, number, ...hours } of records) {
    const day = (days[date] ??= emptyDay());
    const row = {};
    for (const field of USAGE_FIELDS.prs) {
      if (typeof hours[field] === 'number' && Number.isFinite(hours[field])) row[field] = hours[field];
    }
    day.prs[String(number)] = row;
  }
  return days;
}

// --- the hour tier ----------------------------------------------------------------

// How long an hour row lives. Three days: long enough for the two-day view the
// dashboard draws plus a fold outage, short enough that the tier stays a few dozen
// rows rather than a log.
export const HOUR_WINDOW_HOURS = 72;

export const withinHourWindow = (key, nowIso, hours = HOUR_WINDOW_HOURS) => {
  const age = (new Date(`${String(nowIso).slice(0, 13)}:00:00Z`) - new Date(`${key}:00:00Z`)) / 3600000;
  return Number.isFinite(age) && age >= 0 && age < hours;
};

// The hour rows for this run. Two sources meeting in one row, and they are kept in
// separate FIELDS rather than merged, because they are trued up on different clocks:
//
//   - the run counts (`scheduler`, `executor`, `failed`) are APPENDED from the runs
//     read past the watermark, so prior rows carry forward and are added to;
//   - the capture-derived counts (`agentic`, and the per-task executions behind the
//     hover) are RECOMPUTED from the capture files every run, so they overwrite.
//
// Merging them into one counter would make the second source's recompute silently
// double the first's appended total.
export function foldHours({ prior = {}, runs = [], captureHours = {}, now }) {
  const hours = {};
  for (const [key, row] of Object.entries(prior)) {
    if (!withinHourWindow(key, now)) continue;
    hours[key] = { ...emptyHour(), ...structuredClone(row), taskExec: {} };
  }
  for (const run of runs) {
    const key = hourKey(run.startedAt);
    if (!withinHourWindow(key, now)) continue;
    const row = (hours[key] ??= emptyHour());
    if (run.workflow === 'scheduler') row.scheduler += 1;
    else if (run.workflow === 'executor') row.executor += 1;
    if (run.conclusion === 'failure' || run.conclusion === 'timed_out' || run.conclusion === 'startup_failure') {
      row.failed += 1;
    }
  }
  for (const [key, capture] of Object.entries(captureHours)) {
    if (!withinHourWindow(key, now)) continue;
    const row = (hours[key] ??= emptyHour());
    row.agentic = capture.agentic;
    row.taskExec = structuredClone(capture.taskExec ?? {});
  }
  return hours;
}

// The capture files' own view of an hour: how many distinct sessions captured in it,
// and what they executed. The filename stamp is the clock — the same stamp the logs
// branch's retention rules read, machine-written by the capture step.
export function captureHours(files) {
  const out = {};
  const sessions = {};
  for (const file of files) {
    if (!file.stamp) continue;
    const key = hourKey(file.stamp);
    const row = (out[key] ??= { agentic: 0, taskExec: {} });
    (sessions[key] ??= new Set()).add(file.sessionId);
    addCounters(row.taskExec, file.counts.taskExec);
  }
  for (const [key, set] of Object.entries(sessions)) out[key].agentic = set.size;
  return out;
}

// --- task invocations -----------------------------------------------------------

// How long a task row stays in the DAY tier. Independent of the capture retention
// on purpose: these rows come from the scheduler's Actions logs, not from the logs
// branch, so nothing about them ages out when a capture file does — and a repo that
// captured nothing for a week must still show that its scheduled tasks ran. Past
// this, the day row goes and its week row carries it, exactly as the capture-derived
// days do.
export const TASK_DAY_WINDOW_DAYS = 14;

// How long a day row lives at all. Wider than the task rows and wider than the capture
// retention, because the local-git and queue series reach further back than either and
// the growth panels read a month of them. A day past this drops out of the tier; its
// week row keeps what it held.
export const DAY_WINDOW_DAYS = 30;

export function withinTaskWindow(date, today, days = TASK_DAY_WINDOW_DAYS) {
  const age = (new Date(`${today}T00:00:00Z`) - new Date(`${date}T00:00:00Z`)) / 86400000;
  return Number.isFinite(age) && age >= 0 && age < days;
}

// Carry the slot scheduler's task-invocation rows forward while they are still inside
// the day window.
//
// HISTORY ONLY, WITH NO WRITER LEFT (#974). These rows counted what the retired slot
// scheduler printed into its own Actions log about each due task, and nothing appends
// to them any more. What each occurrence came to is read from the queue's own closed
// items (`foldQueueOutcomes`).
//
// So this only ages them out: a day row keeps its `tasks` counts until it leaves the
// window, and the week rows that already froze them keep them forever.
export function carryTaskRuns(days, priorDays = {}, today) {
  for (const [date, row] of Object.entries(priorDays)) {
    const tasks = row?.tasks;
    if (!tasks || !Object.keys(tasks).length || !withinTaskWindow(date, today)) continue;
    (days[date] ??= emptyDay()).tasks = structuredClone(tasks);
  }
  return days;
}

// --- week buckets --------------------------------------------------------------

// The ISO-8601 week a UTC date falls in, `YYYY-Www`. ISO weeks start Monday and
// belong to the year containing their Thursday — computed, never approximated,
// because an off-by-one here would silently mis-file a whole week's row.
export function isoWeek(date) {
  const d = new Date(`${date}T00:00:00Z`);
  const day = (d.getUTCDay() + 6) % 7;                 // Mon=0 … Sun=6
  d.setUTCDate(d.getUTCDate() - day + 3);              // the week's Thursday
  const year = d.getUTCFullYear();
  const firstThursday = new Date(Date.UTC(year, 0, 4));
  const offset = (firstThursday.getUTCDay() + 6) % 7;
  firstThursday.setUTCDate(firstThursday.getUTCDate() - offset + 3);
  const week = 1 + Math.round((d - firstThursday) / (7 * 86400000));
  return `${year}-W${String(week).padStart(2, '0')}`;
}

// The days to fold into weeks this run: every completed day strictly after the
// watermark and strictly before today, in order. Days close strictly in order, so a
// single monotone watermark is the WHOLE exactly-once mechanism — no ingest ledger.
// `today` is excluded because its capture files are still arriving.
export function daysToFold(days, foldedThrough, today) {
  return Object.keys(days)
    .filter((d) => d < today && (!foldedThrough || d > foldedThrough))
    .sort();
}

// Add one day row into its week row, append-once. Weeks carry `days` — how many day
// rows they absorbed — so a fold outage longer than the raw retention window
// declares its own hole (`days: 5`) instead of silently under-reporting.
//
// `sessionDays` rather than `sessions`: every counter here sums exactly under
// folding EXCEPT a distinct-session count (a session spanning two days is distinct
// in each), so the week-level field is named for what it actually is — the sum of
// the day-level distinct counts — rather than claiming a precision folding cannot
// give.
// Every scalar add is `?? 0` on the WEEK side for the same reason the counter maps
// below default rather than crash: a week frozen before a field existed carries no key
// for it, and the field must start accumulating from the first day that has it instead
// of wedging the watermark or reading back as NaN.
export function addDayToWeek(week, day) {
  const w = week ?? { skillLoads: {}, checks: {}, checkFindings: {} };
  const add = (field, n) => { w[field] = (w[field] ?? 0) + n; };
  add('days', 1);
  // Every other week scalar is the sum of the day field of the same name — the two
  // exceptions are spelled once, in WEEK_FROM_DAY. Driven off the vocabulary rather
  // than a hand-written list so a field appended to both rows folds without a third
  // edit here, which is where a new counter would otherwise be silently dropped.
  //
  // A day with NO opinion on a field adds nothing rather than zero: a week that
  // absorbed five days of unreadable git history and two of readable must report the
  // two, not seven days' worth of understated lines.
  for (const field of USAGE_FIELDS.week) {
    if (field === 'days') continue;
    const value = day[WEEK_FROM_DAY[field] ?? field];
    if (typeof value === 'number' && Number.isFinite(value)) add(field, value);
  }
  // The bare maps a week row can carry, so a week frozen before one existed reads
  // back the same shape a fresh fold builds.
  for (const map of BARE_MAPS) addLoads((w[map] ??= {}), day[map]);
  // Every counter group folds key-wise, driven off the vocabulary rather than a
  // hand-written list here — which is where a newly appended group would otherwise be
  // silently dropped out of the week tier.
  //
  // A week frozen before a group existed carries no key for it: defaulted rather than
  // crashed, so the first fold after the group ships extends those weeks from the day
  // it closes forward instead of wedging the watermark behind them.
  //
  for (const group of COUNTER_GROUPS) addCounters((w[group] ??= {}), day[group], group);
  return w;
}

// --- the whole file ------------------------------------------------------------

export { USAGE_VERSION };

// Sorted keys throughout, so a recompute that found nothing new produces a
// byte-identical file and the delivery opens no PR.
function sortKeys(obj) {
  return Object.fromEntries(Object.keys(obj).sort().map((k) => [k, obj[k]]));
}

// Fold one run: hour rows over the last three days, day rows recomputed from `files`
// (the live raw window), week rows carried forward from `prior` and advanced by every
// day that closed since the watermark. Pure — the caller supplies today's UTC date,
// the prior file, and whatever the outside sources answered.
//
// The three tiers answer different questions and are kept honest by different
// mechanisms: hours are for what is happening right now and expire in three days;
// days are cheap to be wrong about (recomputed every run, so a fix heals them); weeks
// are not (frozen once folded — re-freezing would need raw data the retention TTL
// deliberately destroyed), so weeks only ever absorb days that have closed and can no
// longer change.
export function foldUsage({
  files, prior = {}, today, now = null, runsFoldedThrough = null,
  queueRecords = [], queueFoldedThrough = null, prRecords = [], prsFoldedThrough = null,
  runs = [], dayFields = {}, generated = null,
}) {
  const days = foldDays(files);
  // The appended rows are accumulated BEFORE the week fold, so a day that closed since
  // the last run carries them into its week in the same pass that freezes it. (A day
  // whose week is already frozen still shows a late arrival in the day tier — visible
  // there, absent from the week: the same boundary every new counter has, and the same
  // one weeks state for themselves.)
  carryTaskRuns(days, prior.days ?? {}, today);
  foldQueueOutcomes(days, prior.days ?? {}, queueRecords, today);
  foldPrs(days, prior.days ?? {}, prRecords, today);
  foldDayFields(days, dayFields);
  const weeks = structuredClone(prior.weeks ?? {});
  let foldedThrough = prior.foldedThrough ?? null;

  for (const date of daysToFold(days, foldedThrough, today)) {
    const key = isoWeek(date);
    weeks[key] = addDayToWeek(weeks[key], days[date]);
    foldedThrough = date;
  }

  for (const date of Object.keys(days)) {
    if (!withinTaskWindow(date, today, DAY_WINDOW_DAYS)) delete days[date];
  }

  return {
    generated,
    foldedThrough,
    // How far the queue's own closed items have been read. Its own mark for the same
    // reason the run ledger has one: a different source on a different clock, and one
    // outage must not read as the other's.
    queueFoldedThrough: queueFoldedThrough ?? prior.queueFoldedThrough ?? null,
    // …and the merged-PR listing's own mark, bounded on `merged_at` for the same
    // reason the queue's is bounded on `closed_at`.
    prsFoldedThrough: prsFoldedThrough ?? prior.prsFoldedThrough ?? null,
    hours: sortKeys(foldHours({
      prior: prior.hours ?? {}, runs, captureHours: captureHours(files), now: now ?? `${today}T23:59:59Z`,
    })),
    // The second watermark: how far the scheduler's own run ledger has been read.
    // Separate from `foldedThrough` because it advances on a different clock (runs,
    // not closed days) over a different source, and conflating them would make an
    // outage in one silently look like an outage in the other. Carried forward
    // unchanged when this run read no new runs.
    runsFoldedThrough: runsFoldedThrough ?? prior.runsFoldedThrough ?? null,
    days: sortKeys(days),
    weeks: sortKeys(weeks),
  };
}

// --- the file boundary ----------------------------------------------------------
// Everything above works in NAMED counters; the on-disk tuple shape is met only here.
export { encodeUsageFile as encodeUsage, decodeUsageFile as decodeUsage };

// --- the mounted-skill set -----------------------------------------------------

// Where each kind of declared pack is mounted in the member.
const MOUNTS = { canon: '.claudinite/shared/packs', local: '.claudinite/local/packs', temp: '.claudinite/temp/packs' };

// The skill names this repo mounts, read off the declared packs' own trees — never
// from `.claude/skills/`, which is gitignored session state an Action checkout does
// not carry at all. Fails soft to an empty set: with no mounted set, a typed
// `/command` still counts as a userCommand and simply never counts as a skill load.
export async function mountedSkillNames(root, declared) {
  return (await mountedCorpus(root, declared)).mounted;
}

// What the mounted corpus offers the counters that need to know it: the skill names
// of the declared packs (`declared` is the engine's `packs()` answer).
//
// The force-load declarations, the predicates that decide whether a moment hit, and
// which skill owns which check are the engine's, and no SDK call answers them, so
// they stay unset: the counters reading them write NO KEY - *not recorded*, which is
// the honest answer, where a zero would report a skill whose moments could not be
// resolved as one whose moments never came.
export async function mountedCorpus(root, declared) {
  const mounted = new Set();
  for (const pack of Array.isArray(declared) ? declared : []) {
    const dir = join(root, MOUNTS[pack?.kind] ?? MOUNTS.canon, String(pack?.id ?? ''), 'skills');
    let names = [];
    try { names = readdirSync(dir, { withFileTypes: true }); } catch { continue; }
    for (const d of names) if (d.isDirectory() && existsSync(join(dir, d.name, 'SKILL.md'))) mounted.add(d.name);
  }
  return { mounted, declarations: [], hits: {}, ownerOf: null };
}
