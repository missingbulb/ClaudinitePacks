// Code-work, executor-side: a subprocess with the task dir as cwd, the declared
// `code_work_required_secrets` as environment, a hard timeout, and the conditional
// `CLAUDINITE_REQUEST_AGENT` hand-off. Two things the queue states explicitly:
//
//  - RE-ENTRANCY IS THE REQUIREMENT, NOT IDEMPOTENCY. A dead executor's claim is
//    reclaimed and the item re-picked, so code-work can run again over its own
//    half-done work. That is convergence - check what exists, continue from there.
//    Overlap is not excluded by construction: a partitioned runner keeps working
//    while its beats fail to post, its claim is reclaimed on that silence, and the
//    replacement starts. Re-entrancy is what makes that safe.
//  - A DECLARED SECRET THAT IS NOT CONFIGURED IS NAMED, NOT GUESSED AT.
//    Code-work is the only task code that ever sees a secret VALUE, so this is the
//    one place that can tell "unset" from "empty", and the item converges to
//    triage naming exactly which one is missing.

import { fileURLToPath } from 'node:url';
import { runCodeWork, codeWorkFailure, agentRequestPath, clearAgentRequest, agentRequested, readAgentRequest, readTriageMarker, readRequeueMarker } from './code-work.mjs';
import { SECRETS_BAG_ENV, secretsBag, secretValue, secretsFor } from '../world/secrets-bag.mjs';
import { VARS_BAG_ENV, varsEnv } from '../world/vars-bag.mjs';
import { targetEnv } from './target.mjs';
import { actionsEnv } from '../world/actions.mjs';

// The declared secrets this environment does not carry. Absent is missing; a
// set-but-empty one is the repo's own choice and is passed through.
export const missingSecrets = (names = [], env = actionsEnv()) =>
  names.filter((n) => secretValue(n, env) === undefined);

// The environment a task's work step runs under: this job's, minus every secret, plus
// the ones this task declared, plus every repository variable.
//
// The two bags are treated differently on purpose. Secrets are SELECTED — the bag
// carries the whole repository's, and a task's blast radius should be the list it wrote
// down (#1336). Variables are not: `vars` is non-sensitive by construction, so there is
// no blast radius to narrow and a declaration would buy nothing but a second place to
// keep in sync.
//
// Under a workflow that names its secrets there is no bag to subtract, so the stamped
// names stay inherited. Neither raw blob is ever handed on.
export function taskEnv(names = [], env = actionsEnv()) {
  const out = { ...env };
  delete out[SECRETS_BAG_ENV];
  delete out[VARS_BAG_ENV];
  for (const name of Object.keys(secretsBag(env) ?? {})) delete out[name];
  return { ...out, ...varsEnv(env), ...secretsFor(names, env) };
}

// The CLAUDINITE_* variables code-work is handed, and the whole of them: a worker
// reading any other one is reading something nobody sets, which is silent and
// permanent: a parameter that never arrives leaves the run in its most dangerous
// mode (#974).
//
// Built as one object so the NAMES cannot drift from what is actually passed:
// `CODE_WORK_ENV_VARS` below is this function's own key set, and the check that
// polices task workers reads it rather than a hand-kept list.
export const codeWorkEnv = ({ root, repo, defaultBranch, task, item, context = [], requestPath, target = null }) => ({
  CLAUDINITE_REPO_ROOT: root,
  CLAUDINITE_REPO: repo,
  CLAUDINITE_DEFAULT_BRANCH: defaultBranch ?? '',
  // The issue number IS the occurrence.
  CLAUDINITE_ITEM: String(item.number),
  CLAUDINITE_PACK: task.pack,
  CLAUDINITE_TASK: task.id,
  // The item's binding scope, one line per Context bullet — and the channel an
  // operator's parameters ride.
  CLAUDINITE_CONTEXT: context.join('\n'),
  CLAUDINITE_REQUEST_AGENT: requestPath,
  // WHICH BRANCH AND PULL REQUEST THIS RUN WORKS ON, decided by the
  // executor before this subprocess started. A worker pushes to the branch and
  // opens or updates the pull request it is told about — never finds one itself.
  ...targetEnv(target),
});

export const CODE_WORK_ENV_VARS = Object.freeze(
  Object.keys(codeWorkEnv({ task: { pack: '', id: '' }, item: { number: 0 }, requestPath: '' })),
);

// The command this phase actually spawns. A `code_work` declaration IS the command;
// a `code_worker_mjs` one names a module, and the command is the runner's own entry
// point around it - which is the whole point of the field: the wrapping is ours to
// write once rather than every worker's to re-implement.
//
// The entry point is addressed absolutely because the subprocess runs with the TASK
// directory as cwd, and it is resolved from this module's own URL so the path holds
// wherever the pack is mounted. Both parts are quoted: the command goes through a
// shell, and a checkout path can carry a space.
export function codeWorkCommand(decl) {
  if (decl.code_worker_mjs === undefined) return decl.code_work;
  const entry = fileURLToPath(new URL('./worker-entry.mjs', import.meta.url));
  return `node "${entry}" "${decl.code_worker_mjs}"`;
}

export function codeWorkRunner({ root, repo, defaultBranch, env = actionsEnv() }) {
  return async function runFor(task, { item, context = [], target = null }) {
    const missing = missingSecrets(task.decl.code_work_required_secrets ?? [], env);
    if (missing.length) return { ok: true, agentRequested: false, missingSecrets: missing };

    const requestPath = agentRequestPath({ pack: task.pack, task: task.id, slotId: `item-${item.number}` });
    clearAgentRequest(requestPath);

    console.log(`::group::code_work ${task.pack}/${task.id} [#${item.number}]`);
    const result = await runCodeWork(codeWorkCommand(task.decl), {
      taskDir: task.taskDir,
      env: { ...taskEnv(task.decl.code_work_required_secrets ?? [], env), ...codeWorkEnv({ root, repo, defaultBranch, task, item, context, requestPath, target }) },
      timeoutSeconds: task.decl.code_work_timeout,
    });
    console.log('::endgroup::');

    if (!result.ok) {
      clearAgentRequest(requestPath);
      const tail = result.stderr?.trim().split('\n').slice(-5).join('\n') ?? '';
      // Repeated OUTSIDE the group: Actions renders a group collapsed, so a failure
      // whose only evidence sits inside one still reads as unexplained.
      if (tail) console.log(tail);
      // The worker's own verdict on its failure, if it left one — read over BOTH
      // streams, since a marker is a diagnosis and workers print those wherever
      // they print everything else.
      return { ok: false, why: codeWorkFailure(result), detail: tail, triage: readTriageMarker(`${result.stdout}\n${result.stderr}`) };
    }

    const requested = agentRequested(requestPath);
    const payload = requested ? readAgentRequest(requestPath) : null;
    clearAgentRequest(requestPath);
    return {
      ok: true,
      agentRequested: requested,
      // The worker's come-back-later ask, honoured only on this OK path — a failed
      // run is a failure whatever it printed. Read over both streams like the
      // triage marker, and null for the workers that never ask.
      requeue: readRequeueMarker(`${result.stdout}\n${result.stderr}`),
      delivered: deliveredLines(payload?.delivered),
      // The unmerged PR, structured, beside its rendered line: an item whose run
      // left one parks for approval instead of closing, and that decision cannot
      // be made off a prose line.
      openPr: payload?.delivered?.pr && !payload.delivered.merged ? payload.delivered.pr : null,
      // The pull request this run delivered, open OR merged — what a supersede's
      // incumbents were waiting to be replaced by, whichever way it landed.
      deliveredPr: payload?.delivered?.pr ?? null,
      reason: payload?.reason ? (payload.reason.detail || payload.reason.code) : null,
    };
  };
}

// What code-work created, by identity — the agent's only source for those
// artifacts, and (absent an agent) what makes an outcome `delivered` rather than
// `done`. Absence is meaningful: a worker that created nothing writes no
// `delivered`, and the item then says nothing about artifacts rather than
// asserting something false.
export function deliveredLines(delivered) {
  const { branch = null, pr = null, merged = false, issue = null } = delivered ?? {};
  const out = [];
  if (pr) out.push(`PR: #${pr}${merged ? ' (already merged — open your own PR for further work)' : ' (open)'}`);
  if (branch) out.push(`Branch: \`${branch}\``);
  // An ISSUE this run resolved for the agent to write to — a task's standing
  // tracker, typically, found or created by its own code-work. Rendered for the same
  // reason a PR number is: the agent's only source for it is this line, and without
  // it a worker that took the trouble to resolve one hands over nothing.
  if (issue) out.push(`Issue: #${issue} — write this run's record there.`);
  return out;
}
