// The executor - a pull worker over the queue. Each
// iteration: pick the next ready item, claim it by a verified lease, re-evaluate
// the precondition (the scheduler run asked once at the anchor; a chained stage
// re-derives world state rather than trusting a verdict passed forward), then on
// a go run code-work and either converge (agentless) or hand off to an agent
// session; on a no-go close the item with the reason on record — the next
// occurrence is the scheduler run's ask at the task's next anchor.
//
// An executor's whole interface is issue read/write plus the repo at HEAD, which
// is what makes it platform-agnostic: the reference deployment is a job in the
// vendored workflows (the scheduler run's drain, and a `labeled`-event run for
// latency), but a runner anywhere with an issues-scope token qualifies. Nothing
// enumerates executors; identity is self-declared in the claim comment.
//
// The pure decisions live at the top and test with fixtures; the shell below is
// the GitHub/code-work/invocation I/O around them.

import { existsSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
import { isSuspended, suspendedNotice } from '../world/hold.mjs';
import { HEARTBEAT_MS, heartbeatComment, withHeartbeat, realTimers } from '../items/heartbeat.mjs';
import { renderTaskExec, startRunCost } from '../items/run-record.mjs';
import { evaluatePrecondition } from '../contract/precondition.mjs';
import { declaresCodeWork, isScheduledTask } from '../contract/task-contract.mjs';
import { swapStatus, clearStatus } from '../items/apply-status.mjs';
import { pickOrder, taskIdOf, titleOf, running } from '../items/pick-order.mjs';
import { resolveTarget, closeSuperseded } from './target.mjs';
import { deliveryFor } from '../deliver/land-pr.mjs';
import { actionsEnv, repoRoot } from '../world/actions.mjs';
import { now as clockNow } from '../world/clock.mjs';
import { setIssueBody } from '../world/github.mjs';
import {
  STATUS_BLOCKED, STATUS_READY, URGENT, STATUS_RUNNING_EXECUTOR, STATUS_RUNNING_AGENT, requeueHint, 
  STATUS_DONE, STATUS_REJECTED, QUEUE_LABELS, QUEUED_LABEL, STATUS_NEEDS_HUMAN_ACTION,
  STATUS_NEEDS_HUMAN_APPROVAL, STATUS_NEEDS_HUMAN_FAILURE, CLAIM_MARKER, HANDOFF_MARKER, EPISODE_MARKER,
  DELIVERED_HEADING, LEGACY_DELIVERED_HEADINGS, LAST_VERDICT_HEADING,
} from '../../public/task-constants.mjs';
import {
  isStatus, isStandingItem, parseWorkItemTitle, parseWorkItemBody, taskIdFromPath,
  parseContextLines, mergeContext, withNotBefore, withSection, editItemBody, hasLabel,
  lastVerdictLines, withTarget, itemFacts,
} from '../../public/work-item-grammar.mjs';

// The claim comment carries WHO and WHEN — the executor id and its run URL —
// because executor identity is an unbounded set and must never become a label.
export const claimComment = ({ executor, runUrl, at }) =>
  `${CLAIM_MARKER}\nClaimed by executor \`${executor}\` at ${at}.${runUrl ? `\n\nRun: ${runUrl}` : ''}`;

// Who won the claim, out of an item's comments. Three precisions,
// each an implicit assumption made explicit:
//
//  - "EARLIEST" MEANS LOWEST COMMENT ID, never timestamp. GitHub comment
//    `created_at` has one-second granularity, so simultaneous claims tie on time;
//    comment ids are server-assigned and strictly increasing — a total order the
//    protocol gets for free. Nothing here compares runner clocks.
//  - THE ARBITER IS EPISODE-SCOPED (F18): the earliest claim SINCE the item last
//    became ready. Over an item's lifetime dead claims accumulate (every reclaim
//    and revert leaves one), and arbitrating over all of them makes a dead claim
//    outrank every future live claimant — the item then livelocks through reclaim
//    cycles forever. The reclaim / revert / re-queue comment is the boundary.
//  - THE LABEL SWAP IS NOT THE ARBITER, so a torn swap can never mint a second
//    owner; it can only leave an item with no state label, which the repair phase
//    repairs.
export function claimWinner(comments = []) {
  const sorted = [...comments].sort((a, b) => a.id - b.id);
  const boundary = sorted.filter((c) => (c.body ?? '').includes(EPISODE_MARKER)).at(-1);
  const claims = sorted
    .filter((c) => (c.body ?? '').includes(CLAIM_MARKER))
    .filter((c) => !boundary || c.id > boundary.id);
  return claims[0] ?? null;
}

// After WINNING a claim, re-verify the pick filters against live state (F15). The
// filters read possibly-stale state, so two executors can pass them simultaneously
// and claim DIFFERENT items the filters should have serialized — a twin pair, or
// an upstream and its dependent. The per-item lease cannot see that: it protects
// one item, not one title. If a conflicting item now holds an EARLIER claim
// (comment id — the same arbiter the lease trusts), this executor reverts its own
// claim and moves on. Bounded, deterministic, and the earlier claim never notices.
export function conflictsWithEarlierClaim(item, myClaimId, others, { taskAfter = () => [], scheduledOf = () => null, pathTo = () => null } = {}) {
  const idOf = (i) => taskIdOf(i, pathTo);
  const standing = (i) => isStandingItem(i, scheduledOf(idOf(i)));
  const upstreams = standing(item) ? taskAfter(idOf(item)) : [];
  return others.some((o) => {
    if (o.number === item.number) return false;
    if (!running(o)) return false;
    const conflicting = titleOf(o) === titleOf(item)
      || (upstreams.includes(idOf(o)) && standing(o));
    return conflicting && o.claimId != null && o.claimId < myClaimId;
  });
}

// The no-go outcome: every decline CLOSES the item with the reason. A scheduled
// task's next occurrence is the scheduler run's ask at its next tick, and the closed item is itself the
// history the task's cadence term reads (the period this item started in is
// consumed by it). `standing` marks whether the close should say so.
export function noGoPlan(item, task, now, reason) {
  return {
    kind: 'close',
    outcome: STATUS_REJECTED,
    stateReason: 'not_planned',
    reason,
    standing: isStandingItem(item, task?.decl ? isScheduledTask(task.decl) : null),
  };
}

// --- the shell ----------------------------------------------------------------

const nowIso = () => clockNow().toISOString();

// Time `fn` under one of the run's phases, or just run it when this run is not
// timing itself. `finally`, so a phase that threw is still closed — the record is
// about where the wall clock went, and a run that died inside code-work spent that
// time whatever the exit was.
async function timed(cost, name, fn) {
  const end = cost ? cost.phase(name) : () => {};
  try { return await fn(); } finally { end(); }
}

// ONE EXECUTOR RUN DRAINS THE QUEUE. Actions bills each job's runtime rounded UP
// to the next minute, so a day's cost is the RUN count: a run per item would pay a
// whole invocation — checkout, setup, rounding — per item. So a run claims an
// item, sees it to its settle, then picks the next, and ends when nothing is
// pickable. Items still settle ONE AT A TIME: capacity is executor width.
//
// What starts a run is an enumerable list, each cause on the record: the scheduler run's drain job (dispatched only when that run leaves
// something pickable), a label event, an agent session's close-time drain, and
// the workflow's failure-continuation job when a run dies mid-drain. A run never
// re-dispatches itself - the remainder is this run's own.
//
// AN ITEM THIS RUN LET GO OF IS NEVER RE-ATTEMPTED BY IT. Losing a claim race
// leaves the item running under its winner, so the next pick simply does not see
// it — but a post-claim REVERT puts the item back to ready, and re-picking what
// this run just returned to the queue is an unbounded loop, not a retry. Both
// exits are therefore recorded in `standDown` and skipped for the rest of the
// run; the executor that won, and the scheduler run behind it, carry those.
//
// The loop terminates because every iteration either settles an item (which
// leaves the ready state) or stands down from one — and the only items that
// newly become pickable are the dependents a close releases, which is the
// chaining this exists to do. Its outer bound is the workflow's own timeout.
//
// Injected seams keep the run testable end to end without GitHub, code-work
// subprocesses or an invocation endpoint.
// `runCost` is the run's own stopwatch, supplied by the CLI below
// and left null everywhere else: a run driven by a test or the simulator is not a
// billed invocation and has no run id to file a cost under, so it times nothing and
// stamps nothing. Where one IS supplied, every item this run settles carries the
// record away with it — see `recordFor`.
export async function runExecutor({
  gh, repo, root, config, tasks, executorId, runUrl = null,
  now = () => clockNow(), random = Math.random, heartbeatMs = HEARTBEAT_MS,
  collectSignalsFor, runTaskCodeWork, invokeAgent, log = console.log,
  resolveTargetFor = null, runCost = null, timers = realTimers,
}) {
  const api = await import('../world/github.mjs');
  const { listOpenWorkItems } = await import('../items/read.mjs');
  const schedule = config.taskScheduler;
  const byId = new Map(tasks.map((t) => [`${t.pack}/${t.id}`, t]));
  const taskAfter = (id) => byId.get(id)?.decl?.schedule_after ?? [];
  const scheduledOf = (id) => (byId.has(id) ? isScheduledTask(byId.get(id).decl) : null);
  // A marked issue names its task by worker path, so the run needs the inverse of
  // the id map — built from the same task set, so a path this repo does not carry
  // resolves to nothing and the item is malformed rather than guessed at.
  const byPath = new Map(tasks.map((t) => [t.taskPath, `${t.pack}/${t.id}`]));
  const pathTo = (p) => byPath.get(p) ?? null;
  // THE TARGET SEAM: which branch and pull request a run works on,
  // resolved from the task's declared outcome against the repo's open pull
  // requests. The member's delivery preference is what says whether a green
  // incumbent may be landed on the way; it is read once, from the same config the
  // hand-off reads.
  const resolveTargetOf = resolveTargetFor ?? ((task, at) => resolveTarget({
    gh, repo, taskId: `${task.pack}/${task.id}`, outcome: task.decl.expected_outcome,
    delivery: deliveryFor(config), now: at, log,
  }));
  const done = [];
  // Items this run has let go of — a lost race, a reverted claim — and must not
  // pick again. Without it a revert re-picks what it just returned to the queue.
  const standDown = new Set();

  // A phase of a run that is not timing itself is a no-op pair, so the loop below
  // reads the same either way.
  const phase = (name) => (runCost ? runCost.phase(name) : () => {});

  for (;;) {
    // Read live every time: the settle just made may have readied a dependent,
    // and another executor may have taken what was pickable a moment ago.
    const endPick = phase('pick');
    const open = await listOpenWorkItems(gh, repo);
    const candidate = pickOrder(open, { taskAfter, scheduledOf, random, pathTo })
      .find((i) => !standDown.has(i.number));
    endPick();
    if (!candidate) break;

    // --- claim: the verified lease ------------------------------------------
    const endClaim = phase('claim');
    await swapStatus(api, gh, repo, candidate, STATUS_READY, STATUS_RUNNING_EXECUTOR);
    await api.comment(gh, repo, candidate.number, claimComment({
      executor: executorId, runUrl, at: nowIso(),
    }));
    const comments = await api.listComments(gh, repo, candidate.number);
    const winner = claimWinner(comments);
    const mine = [...comments]
      .sort((a, b) => a.id - b.id)
      .filter((c) => (c.body ?? '').includes(CLAIM_MARKER) && (c.body ?? '').includes(`executor \`${executorId}\``))
      .at(-1);
    if (!winner || winner.id !== mine?.id) {
      // The loser reverts nothing — the winner's labels already stand. It does
      // strike its own claim (F24): letting go covers losing too, and a claim left
      // behind here outlives the winner's episode and becomes the earliest of the
      // NEXT one, moving the livelock one episode along.
      await strikeClaim(api, gh, repo, mine);
      standDown.add(candidate.number);
      endClaim();
      log(`- #${candidate.number}: another executor holds this episode's earliest claim — leaving it to them`);
      continue;
    }

    // --- post-claim re-verify (F15) -----------------------------------------
    const others = await withClaimIds(api, gh, repo, await listOpenWorkItems(gh, repo), candidate.number);
    if (conflictsWithEarlierClaim(candidate, winner.id, others, { taskAfter, scheduledOf, pathTo })) {
      await api.comment(gh, repo, candidate.number,
        `${EPISODE_MARKER}\nReverting this claim: a conflicting item holds an earlier claim this cycle. Returning the item to the queue.`);
      await swapStatus(api, gh, repo, candidate, STATUS_RUNNING_EXECUTOR, STATUS_READY);
      standDown.add(candidate.number);
      endClaim();
      log(`- #${candidate.number}: reverted — a conflicting item claimed earlier`);
      continue;
    }
    endClaim();

    const outcome = await executeItem({
      api, gh, repo, root, config, schedule, byId, pathTo, item: candidate, executorId,
      claim: winner, now, heartbeatMs, collectSignalsFor, runTaskCodeWork, invokeAgent, log,
      resolveTargetOf, cost: runCost, phase, timers,
    });
    done.push({ issue: candidate.number, outcome });
  }
  return done;
}

// Whether `claim` is still the item's live claim — the earliest of THIS episode,
// by the same arbiter the lease itself trusts. False where a reclaim's episode
// marker struck it, or where another executor now holds the item.
async function holdsClaim(api, gh, repo, item, claim) {
  if (!claim) return true;
  const winner = claimWinner(await api.listComments(gh, repo, item.number));
  return !!winner && winner.id === claim.id;
}

// The claim id of each live item, so the post-claim verify can compare episodes.
// One comment read per conflicting-looking item, not per item in the repo.
async function withClaimIds(api, gh, repo, items, selfNumber) {
  const out = [];
  for (const i of items) {
    if (i.number === selfNumber || !running(i)) { out.push(i); continue; }
    const winner = claimWinner(await api.listComments(gh, repo, i.number));
    out.push({ ...i, claimId: winner?.id ?? null });
  }
  return out;
}

// One claimed item, from validation through to a terminal state (or a hand-off).
async function executeItem({
  api, gh, repo, root, config, schedule, byId, pathTo = () => null, item, executorId, claim,
  now, heartbeatMs, collectSignalsFor, runTaskCodeWork, invokeAgent, log, resolveTargetOf,
  cost = null, phase = () => () => {}, timers,
}) {
  const parsed = parseWorkItemTitle(item.title);
  const { taskPath } = parseWorkItemBody(item.body);
  // A marked issue's identity is its machine block, not its title: the id
  // is whichever task owns the worker path the block names.
  const id = parsed ? `${parsed.pack}/${parsed.task}` : pathTo(taskPath);
  const task = id ? byId.get(id) : null;
  // The exec record joins back to the work by pack and task, which a marked issue's
  // human title cannot supply — so the resolved id travels with the item.
  item.taskId = id;

  // --- validate in code, before anything trusts the issue ------------------
  if (!taskPath || (!parsed && !id)) {
    await converge(cost, api, gh, repo, item, STATUS_RUNNING_EXECUTOR, STATUS_NEEDS_HUMAN_FAILURE, claim,
      'This work item is malformed — its title or first body line does not name a task. Possible forgery; a human should look at it.', 'invalid');
    return 'needs-human';
  }
  if (!task) {
    await close(cost, api, gh, repo, item, STATUS_RUNNING_EXECUTOR, STATUS_REJECTED, 'not_planned',
      `\`${id}\` is not a task this repo carries at HEAD (the pack may be undeclared, or the task removed). Closing obsolete.`, 'task-gone');
    return 'obsolete';
  }
  // THE SAME FACT, LEARNED LATER. The task set was built once, at the start of the
  // run; one run drains several items from one checkout, and an earlier item's own
  // work rewrites that checkout — the mount update deletes a retired task's
  // directory out from under the items behind it. So a task can resolve here and
  // not exist on disk — the same fact the branch above closes on, and it converges
  // the same way. Without this the run reaches code-work and spawns with a cwd that is gone
  // (missingbulb/Shepherd#300).
  if (!existsSync(task.taskDir)) {
    await close(cost, api, gh, repo, item, STATUS_RUNNING_EXECUTOR, STATUS_REJECTED, 'not_planned',
      `\`${id}\` no longer exists in this checkout (\`${task.taskPath}\`) — it was removed while this run was in flight. Nothing ran. Closing obsolete.`, 'task-gone');
    return 'obsolete';
  }
  if (task.taskPath !== taskPath) {
    // A MISMATCH HAS TWO CAUSES AND ONLY ONE IS A PERSON'S PROBLEM (#1461). The guard
    // exists for a tampered or forged item, whose path names some OTHER task — that
    // parks. But an item open across a pack rename hits it too: only the title's id is
    // canonicalized (`parseWorkItemTitle`), so the body keeps naming the pre-rename
    // directory forever, and parking it strands the item AND holds the task's lane,
    // since nothing rewrites an item body. When the path resolves to this very task —
    // `taskIdFromPath` canonicalizes too — the item is merely stale, which is the
    // `!task` branch's verdict: close it obsolete and let the generator file a fresh
    // occurrence at today's path.
    const named = taskIdFromPath(taskPath);
    if (named && `${named.pack}/${named.task}` === id) {
      await close(cost, api, gh, repo, item, STATUS_RUNNING_EXECUTOR, STATUS_REJECTED, 'not_planned',
        `This item names \`${id}\` at \`${taskPath}\`, where it no longer lives — the pack was renamed since the item `
        + `was filed, and the task is at \`${task.taskPath}\` now. An item's stored path is never rewritten, so this one `
        + 'can never run. Closing obsolete; the scheduler files a fresh occurrence at the current path.', 'task-gone');
      return 'obsolete';
    }
    await converge(cost, api, gh, repo, item, STATUS_RUNNING_EXECUTOR, STATUS_NEEDS_HUMAN_FAILURE, claim,
      `This item's task path (\`${taskPath}\`) is not where \`${id}\` lives at HEAD (\`${task.taskPath}\`). Not running it.`, 'invalid');
    return 'needs-human';
  }

  // --- the single precondition evaluation ------------------------------------
  const at = now();
  // The item's own facts — its fields, its number, whether somebody woke it — are
  // what the terms judge over: a request item's verdict is about the issue it
  // names, which no signal bundle can single out on its own, and
  // the cadence terms hold on a woken item. The signals are collected FOR
  // THIS OCCURRENCE, its own run history excluding it.
  const fields = itemFacts(item);
  const signals = await collectSignalsFor(task, at, item);
  const verdict = evaluatePrecondition(task, signals, config.packConfig?.[task.pack] ?? {}, fields, at);

  // A PRECONDITION THAT COULD NOT ANSWER IS A RUN FAILURE, NOT A VERDICT (F27). A
  // decline is a decision about the world; one taken on an API that would not answer
  // is a guess, and its write-backs cannot land — for a request that would strand
  // the issue armed-but-queued forever, the request silently eaten. So the item
  // parks open in the failure lane, where the ordinary re-queue lever retries it
  // once the API recovers, and nothing is written to whatever it could not read.
  if (verdict.error) {
    await converge(cost, api, gh, repo, item, STATUS_RUNNING_EXECUTOR, STATUS_NEEDS_HUMAN_FAILURE, claim,
      `This run could not be decided: ${verdict.error}\n\nNothing ran and nothing was written. Re-queue this item (${requeueHint}) once the cause has cleared.`);
    log(`! #${item.number} ${id}: the precondition could not answer — ${verdict.error}`);
    return 'needs-human';
  }

  if (verdict.run !== true) {
    const plan = noGoPlan(item, task, at, verdict.reason || 'no work');
    // A DECLINED REQUEST IS DISARMED IN THE SAME CONVERGENCE.
    // Nothing else would: an issue left carrying `claude-queued` after its run was
    // refused is one no later scheduler run adopts and no person is told about, and one
    // whose mark — if re-applied — walks into the same refusal forever.
    // A LEGACY shadow item wrote its decline back to the issue it named. A marked
    // issue IS the item, so the decline's comment and its `rejected` status already
    // land where the person is looking and there is nothing to mirror.
    if (fields.request && fields.request !== item.number) {
      await declineRequest(api, gh, repo, fields.request, item.number, plan.reason);
    }
    // A DECLINE IS A COMPLETED RUN, not a failure: the executor asked, got a
    // no, and closed the occurrence — so the record says `success` and the
    // reason sits beside it in the same comment.
    await close(cost, api, gh, repo, item, STATUS_RUNNING_EXECUTOR, STATUS_REJECTED, 'not_planned',
      `The precondition declined: ${plan.reason}`
      + (plan.standing
        ? '\n\nThis task is asked again at the next scheduler run; a decline is recorded nowhere but here.'
        : ''), 'success');
    return 'obsolete';
  }

  // --- code-work, then converge or hand off ---------------------------------
  // The item's OWN Context is scope too, not decoration: an operator's parameters
  // (`create-work-item --context "REPOS=Alpha Beta"`) live there and nowhere else,
  // so code-work sees the union of what the item was created with and what this
  // occurrence's precondition added.
  const context = mergeContext(parseContextLines(item.body), verdict.context ?? []);

  // --- the target: which pull request this run works on ---------------------
  // Decided ONCE, here, between the go and the work, and handed to both phases —
  // code-work as environment, the agent as item fields — so neither phase
  // discovers, chooses or disposes of a pull request on its own. A read the
  // resolver could not make is a run failure like an unanswerable precondition
  // (F27): an unreadable pull request list looks exactly like an empty one, and
  // "nothing to amend" on that evidence stacks a duplicate.
  const target = await resolveTargetOf(task, at);
  if (target.error) {
    await converge(cost, api, gh, repo, item, STATUS_RUNNING_EXECUTOR, STATUS_NEEDS_HUMAN_FAILURE, claim,
      `This run could not be given a target: ${target.error}\n\nNothing ran and nothing was written. Re-queue this item (${requeueHint}) once the cause has cleared.`);
    log(`! #${item.number} ${id}: the target could not be resolved — ${target.error}`);
    return 'needs-human';
  }
  log(`- #${item.number} ${id}: target — ${target.reason}`);
  if (target.landed) {
    // The previous delivery had concluded green and was landed by the resolution.
    // That IS this occurrence: the tree this run holds predates the merge, so the
    // work would re-deliver a diff already on the base. The next occurrence
    // converges from the moved base.
    await closeSuperseded({ gh, repo, numbers: target.supersedes, successor: target.landed, log });
    await close(cost, api, gh, repo, item, STATUS_RUNNING_EXECUTOR, STATUS_DONE, 'completed',
      `Landed #${target.landed}, this task's previous delivery, which had concluded green and was never merged. `
      + 'The checkout this run holds predates that merge, so nothing else ran; the next occurrence converges from the moved base.', 'success');
    return STATUS_DONE;
  }

  if (declaresCodeWork(task.decl)) {
    // The work step may legitimately run for hours. While it does, the
    // item's only sign of life is this beat — which is also what the scheduler run's leash
    // measures, so a long run is legal rather than reclaimed underneath itself.
    const endCodeWork = phase('code-work');
    const result = await withHeartbeat(() => runTaskCodeWork(task, { item, context, target }), {
      intervalMs: heartbeatMs,
      timers,
      log,
      beat: (minutes) => api.comment(gh, repo, item.number,
        heartbeatComment({ executor: executorId, at: nowIso(), minutes })),
    });
    endCodeWork();
    // THE LEASE, RE-VERIFIED ACROSS THE ONE PHASE THAT CAN OUTLIVE IT (F17). The
    // work step is the only thing a run does that may legally take longer than the
    // executing leash, so it is the only place this run can have been reclaimed
    // while it was still alive: every other write here happens within seconds of
    // the claim. A run whose beats stopped reaching GitHub — the beat is fail-soft
    // by design, and a partitioned runner keeps working — is reclaimed, re-picked,
    // and would then converge the item out from under the executor now holding it.
    // Re-entrant code-work makes the second RUN safe; it says nothing about a
    // second CONVERGE. So the stale runner abandons silently: the item is not its
    // to write to, and the live holder never notices.
    if (!(await holdsClaim(api, gh, repo, item, claim))) {
      log(`- #${item.number} ${id}: reclaimed while this run's work step ran — another executor holds it now, leaving it to them`);
      return 'reclaimed';
    }
    if (!result.ok) {
      // A RUN THAT FAILED PARKS `failure`, whatever the worker asked for (#1452).
      // Routing the park by the worker's marker would put a failed run in a
      // NON-BLOCKING lane wherever the worker named `action`: the standing slot frees
      // and the task re-files the next day against a cause nobody has fixed.
      //
      // The worker's verdict goes into the human-facing instruction instead, kind
      // and detail both. A run that never STARTED is the other thing entirely and keeps its own lane: see the
      // `missingSecrets` branch below, where nothing failed because nothing ran.
      await converge(cost, api, gh, repo, item, STATUS_RUNNING_EXECUTOR, STATUS_NEEDS_HUMAN_FAILURE, claim,
        `Code-work failed: ${result.why}`
        + `${result.triage?.kind ? `\n\nThe worker asks for: **${result.triage.kind}**` : ''}`
        + `${result.triage?.detail ? `\n\nThe worker's own verdict: ${result.triage.detail}` : ''}`
        + `${result.detail ? `\n\n\`\`\`\n${result.detail}\n\`\`\`` : ''}`);
      return 'needs-human';
    }
    if (result.missingSecrets?.length) {
      await converge(cost, api, gh, repo, item, STATUS_RUNNING_EXECUTOR, STATUS_NEEDS_HUMAN_ACTION, claim,
        `This task declares repo Actions secrets that are not configured: ${result.missingSecrets.join(', ')}. Set them in repo settings and re-queue this item (${requeueHint}).`);
      return 'needs-human';
    }
    // SUPERSEDING, ONCE THE SUCCESSOR EXISTS. The pull request code-work delivered
    // — open or already merged — is what the task's earlier ones were waiting to be
    // replaced by; a run that delivered none leaves them where they were (a review
    // member's pending pull request is never taken away for nothing). Performed
    // here, the set is cleared before the hand-off so the agent's converge is not
    // asked to close them a second time.
    if (target.supersedes?.length && result.deliveredPr) {
      await closeSuperseded({ gh, repo, numbers: target.supersedes, successor: result.deliveredPr, log });
      target.supersedes = [];
    }
    if (!result.agentRequested) {
      // THE WORKER'S REQUEUE ASK (#1530): the run happened, found its subject not
      // yet there, and prescribed its own wake — neither done nor broken. Stamp
      // the instant as the item's `Not-before` (into the machine half, the only
      // half `parseWorkItemBody` reads) and return it to blocked; the scheduler's
      // readiness pass releases it when the moment comes. Silent on the timeline:
      // the bumped field is the record, and a retry
      // cadence must not grow a comment per wake. An ask whose instant could not
      // be read is refused loudly — the worker said "wait", and closing done on
      // it would record a pass nobody measured.
      if (result.requeue) {
        if (!result.requeue.until) {
          await converge(cost, api, gh, repo, item, STATUS_RUNNING_EXECUTOR, STATUS_NEEDS_HUMAN_FAILURE, claim,
            `Code-work asked to requeue this item but its \`claudinite-requeue:\` instant could not be read${result.requeue.reason ? ` (${result.requeue.reason})` : ''}. Fix the worker's marker, then re-queue this item (${requeueHint}).`);
          return 'needs-human';
        }
        const body = editItemBody(item.body, (machine) => withNotBefore(machine, result.requeue.until));
        await setIssueBody(gh, repo, item.number, body);
        await strikeClaim(api, gh, repo, claim);
        await swapStatus(api, gh, repo, item, STATUS_RUNNING_EXECUTOR, STATUS_BLOCKED);
        log(`- #${item.number} ${id}: requeued until ${result.requeue.until}${result.requeue.reason ? ` — ${result.requeue.reason}` : ''}`);
        return 'requeued';
      }
      // A run that deliberately left an UNMERGED PR is not finished, it is waiting
      // on a person — so the item stays OPEN at `task:needs-human-approval` rather
      // than closing as delivered. A park is not live, so the next occurrence is
      // filed on schedule around it and an unreviewed PR delays nobody but its
      // reviewer.
      if (result.openPr) {
        await converge(cost, api, gh, repo, item, STATUS_RUNNING_EXECUTOR, STATUS_NEEDS_HUMAN_APPROVAL, claim,
          `Code-work did this run's work and opened a PR for you to approve:\n${result.delivered.map((d) => `- ${d}`).join('\n')}`
          + `\n\nMerge or close #${result.openPr}, then close this item. This task keeps running on schedule meanwhile.`, null);
        return 'needs-human';
      }
      await close(cost, api, gh, repo, item, STATUS_RUNNING_EXECUTOR, STATUS_DONE, 'completed',
        result.delivered?.length
          ? `Code-work did this run's work and left:\n${result.delivered.map((d) => `- ${d}`).join('\n')}`
          : 'Code-work did this run\'s work; no agent was needed.', 'success');
      return STATUS_DONE;
    }
    return handOff({ api, gh, repo, item, task, id, context, result, target, executorId, claim, invokeAgent, config, log, cost });
  }

  // An agentless task with no code-work does nothing (the contract forbids it).
  if (task.decl.agent_model === 'none') {
    await converge(cost, api, gh, repo, item, STATUS_RUNNING_EXECUTOR, STATUS_NEEDS_HUMAN_FAILURE, claim,
      'This task is agentless but declares no code_work, so there is nothing to run — a contract-forbidden shape that reached the queue.', 'invalid');
    return 'needs-human';
  }
  return handOff({ api, gh, repo, item, task, id, context, result: {}, target, executorId, claim, invokeAgent, config, log, cost });
}

// @deprecated The write-back a refused SHADOW item's issue got — one comment saying
// why, and the queued label off, so the request was disarmed rather than left
// looking pending. Nothing writes it for an item filed under the one-issue model,
// where the item and the issue are the same object; it stays for the shadow items
// still draining, whose issue is a different one.
async function declineRequest(api, gh, repo, request, item, reason) {
  await api.comment(gh, repo, request,
    `Not implementing this: ${reason}\n\nThe queued run (#${item}) is closed and \`${QUEUED_LABEL}\` is removed. `
    + 'If this was wrong, mark the issue again — a request is only run when the person who opened it, or somebody who commented `/claude go`, has push access here.');
  await api.removeLabel(gh, repo, request, QUEUED_LABEL);
}

// @deprecated The roll retired with #1115 — nothing writes this any more. Kept
// exported because bodies the fielded roll wrote are stored data: the
// round-trip test over this writer is what pins `parseLastVerdict`'s decode,
// which the migration and the dashboard still read.
export function rollBody(body, until, reason, at) {
  const stamped = withNotBefore(body, until);
  return withSection(stamped, LAST_VERDICT_HEADING, lastVerdictLines({ at, reason, until }));
}

// Hand off to an agent session. ONE call per item, ever - which is
// what lets this be as short as it is. The nonce goes on the item before the call
// and travels in the payload, so the session can prove the fire it arrived on is
// the hand-off this item recorded and stop if it is not.
async function handOff({ api, gh, repo, item, task, id, context, result, target = null, executorId, claim, invokeAgent, config, log, cost = null }) {
  const endHandOff = cost ? cost.phase('hand-off') : () => {};
  const nonce = `${item.number}-${Math.random().toString(36).slice(2, 10)}`;
  // Every section lands in the machine's half of the body — the whole body for a
  // filed item, the machine block for a marked issue, whose prose is the person's.
  const body = editItemBody(item.body, (machine) => {
    let out = machine;
    // The target's fields first, under the task path: the branch the session
    // pushes to, the pull request it amends, the ones its converge supersedes.
    if (target) out = withTarget(out, target);
    if (context.length) out = withSection(out, 'Context', context);
    if (result.delivered?.length) out = withSection(out, DELIVERED_HEADING, result.delivered);
    if (result.reason) out = withSection(out, 'Why the agent is here', [result.reason]);
    return out;
  });
  await setIssueBody(gh, repo, item.number, body);

  await swapStatus(api, gh, repo, item, STATUS_RUNNING_EXECUTOR, STATUS_RUNNING_AGENT);
  // The hand-off is this run's LAST word on the item — the session converges it from
  // here — so the cost record rides this comment, where a terminal one would carry
  // it for an item the executor settled itself.
  await api.comment(gh, repo, item.number,
    `${HANDOFF_MARKER}\nHanded off by executor \`${executorId}\` — invocation nonce \`${nonce}\`.`
    + recordFor(item, null, cost));

  const invocation = await invokeAgent({ task, item, nonce, config });
  if (invocation.ok) {
    await api.comment(gh, repo, item.number,
      `Agent session started${invocation.sessionUrl ? `: ${invocation.sessionUrl}` : ''}.`);
    log(`- #${item.number} ${id}: handed off${invocation.sessionId ? ` (${invocation.sessionId})` : ''}`);
    endHandOff();
    return 'agent';
  }
  if (invocation.answered) {
    // The endpoint refused, so no session exists and none will: a token, a URL or
    // a routine is wrong, and every future pick would be refused the same way.
    endHandOff();
    await converge(cost, api, gh, repo, item, STATUS_RUNNING_AGENT, STATUS_NEEDS_HUMAN_ACTION, claim,
      `Could not start an agent session: ${invocation.error}\n\nNo session was started. Fix the invocation endpoint, then re-queue this item (${requeueHint}).`);
    return 'needs-human';
  }
  // NOTHING CAME BACK, and this is the case the whole design turns on: the call
  // may have started a session. Re-queueing here is what would put two sessions on
  // one item, and converging to triage would kill a run that is very possibly
  // alive. So the item STAYS with the agent and says the outcome is unknown —
  // whichever way it went is then settled by a rule that already exists: a session
  // that started converges the item, and one that never did leaves the item silent
  // until the repair phase's agent leash sweeps it to triage.
  await api.comment(gh, repo, item.number,
    `The agent invocation got no answer: ${invocation.error}\n\n`
    + 'The session may or may not have started, so nothing here re-tries it — a second call could put two sessions on this item. '
    + 'If a session did start it will converge this item; if it did not, the repair phase\'s agent leash parks it for a human within a few hours.');
  log(`! #${item.number} ${id}: invocation unanswered — left with the agent, leash decides — ${invocation.error}`);
  endHandOff();
  return 'unknown';
}

// LETTING GO OF AN OPEN ITEM KILLS YOUR CLAIM (F24). An executor
// that stops owning an item without closing it - a requeue, and every
// `needs-human` park — strikes its own claim by appending the episode marker to
// it. `claimWinner` already treats the last marker as the boundary, so a struck
// claim stops outranking anything and the next claimant wins on its first try.
//
// APPENDING rather than commenting is what lets a requeue stay silent: a worker
// waiting out its subject adds no timeline entry per wake. A successful
// hand-off deliberately does NOT strike — the episode is still live, owned by the
// agent session — and neither does a close, since nothing re-claims a closed item.
//
// Struck BEFORE the label swap, so the crash window degrades the safe way: an
// executor that dies between the two leaves the item `task:executing` with a
// spent claim, which the scheduler run's leash reclaim already recovers. Striking after
// would leave exactly the state this fixes — parked, re-queued by a human, and
// unclaimable forever.
async function strikeClaim(api, gh, repo, claim) {
  if (!claim || (claim.body ?? '').includes(EPISODE_MARKER)) return;
  await api.editComment(gh, repo, claim.id,
    `${claim.body}\n\n${EPISODE_MARKER}\nThis claim is spent — the executor released this item without closing it.`);
}

// Every exit converges the item exactly once, with one comment saying what
// happened — the terminal-state discipline the incidents bought. The claim sits
// before the body so every state argument is grouped ahead of the prose.
//
// THE COMMENT CARRIES THE EXECUTION RECORD. Actions logs
// expire, and for an agentless run — the majority — the item is the only durable
// trace there will ever be, so the record goes where the item is rather than into
// a log that ages out. The bracketed field is this item's issue number, which is
// the only join from a record back to the work it describes.
// A status of `null` writes NO record, and that is the honest answer for a park
// that is not a failure: the vocabulary's `success` means "ran to completion and
// the issue was closed" and `failed` means the run broke, so an approval park —
// a run that succeeded and left a PR for a person — is neither. Absence is a
// state of its own; inventing a fifth status is a change to stored data every
// decoder in the fleet would have to learn.
// THE RUN'S COST RIDES THE SAME BLOCK. A scheduler tick can only
// print its cost into a log that expires; an executor run has items, so it writes
// the record where the record survives. Every item this run settles gets the
// counters AS THEY STAND at that moment, so a run that settled three items leaves
// three snapshots of one record — the reader keys on the run id and keeps the
// largest, which is the run's total as of its last item.
//
// A run that is not timing itself (a test, the simulator) supplies no `cost` and
// the block carries no cost line.
const recordFor = (item, status, cost = null) => {
  // `item.taskId` is the resolved id — a marked issue's title names no task, so the
  // title parse alone would silently drop the record for every request run.
  const id = item.taskId ?? null;
  const parsed = status
    ? (id ? { pack: id.split('/')[0], task: id.split('/').slice(1).join('/') } : parseWorkItemTitle(item.title))
    : null;
  const lines = [
    ...(parsed ? [renderTaskExec({ pack: parsed.pack, task: parsed.task, slotId: `#${item.number}`, status })] : []),
    ...(cost ? [cost.record()] : []),
  ];
  return lines.length ? `\n\n\`\`\`\n${lines.join('\n')}\n\`\`\`` : '';
};

// Park an item for a human. ONE label: the park IS the status, and its kind is what
// the human is being asked for. A two-label park could be half-applied, a torn state
// of its own.
async function converge(cost, api, gh, repo, item, from, park, claim, body, status = 'failed') {
  return timed(cost, 'converge', async () => {
    await strikeClaim(api, gh, repo, claim);
    await api.comment(gh, repo, item.number, body + recordFor(item, status, cost));
    await swapStatus(api, gh, repo, item, from, park);
  });
}

// A close writes only to the item it holds: a dependent this close may make due is released solely by the
// scheduler run's own readiness job, on its next pass, never here.
async function close(cost, api, gh, repo, item, from, outcome, stateReason, body, status) {
  return timed(cost, 'converge', async () => {
    await api.comment(gh, repo, item.number, body + recordFor(item, status, cost));
    await clearStatus(api, gh, repo, item, from);
    await api.addLabel(gh, repo, item.number, outcome);
    // A TERMINAL CLOSES THE ISSUE IT STANDS ON, marked or filed, and both terminals do.
    // `done` means nothing is left to act on; `rejected`
    // means nothing will happen. Neither is a question, so neither leaves an open issue
    // behind asking a person to agree with a verdict already reached - re-asking is
    // clearing the status.
    await api.closeIssue(gh, repo, item.number, stateReason);
  });
}

// --- CLI ----------------------------------------------------------------------

export async function runExecutorJob() {
  // THE OPERATOR HOLD, FIRST ACT - before the config load, before the
  // first API call, so a held queue reads nothing and writes nothing rather than
  // deriving the world and then declining to act on it.
  if (isSuspended()) { console.log('## Claudinite executor\n'); console.log(suspendedNotice()); return; }
  const { makeGh, apiCallCount } = await import('../world/github.mjs');
  const { actionRepoContext, actionsEnv, executorId, repoRoot, runUrlFor } = await import('../world/actions.mjs');
  const { discoverTasks } = await import('../contract/discover.mjs');
  const { loadConfig } = await import('../../../../engine/checks/helpers/repo-context.mjs');
  const { isDormant, dormancyErrors } = await import('../contract/dormancy.mjs');
  const { ensureLabels } = await import('../world/github.mjs');
  const { collectSignalsForTask } = await import('../signals/for-task.mjs');
  const { codeWorkRunner } = await import('./code-work-run.mjs');
  const { agentInvoker } = await import('../world/sessions.mjs');

  const root = repoRoot();
  const { repo, defaultBranch } = actionRepoContext();
  if (!repo) { console.error('GITHUB_REPOSITORY not set - not in an Actions context'); process.exitCode = 1; return; }
  const config = loadConfig(root);

  console.log('## Claudinite executor\n');
  for (const e of dormancyErrors(config)) console.log(`! ${e.what} — ${e.fix}`);
  if (isDormant(config)) {
    console.log('- this project declares its scheduler dormant — nothing is picked up');
    return;
  }

  const gh = makeGh();
  const { tasks, errors } = await discoverTasks(root, config);
  for (const e of errors) console.log(`! ${e.what}`);
  await ensureLabels(gh, repo, QUEUE_LABELS);

  const runUrl = actionsEnv().GITHUB_RUN_ID
    ? `${actionsEnv().GITHUB_SERVER_URL ?? 'https://github.com'}/${repo}/actions/runs/${actionsEnv().GITHUB_RUN_ID}`
    : null;

  // WHAT THIS RUN COSTS. Only the real job times itself: a run id
  // is what the record is filed under, and a run without one is not a billed
  // invocation of anything.
  const runCost = startRunCost({
    workflow: 'executor', runId: actionsEnv().GITHUB_RUN_ID ?? null, apiCalls: apiCallCount,
  });

  const done = await runExecutor({
    gh, repo, root, config, tasks,
    executorId: actionsEnv().CLAUDINITE_EXECUTOR_ID || `actions-${actionsEnv().GITHUB_RUN_ID ?? 'local'}`,
    runUrl,
    // A COLLECTOR PER PICK. The collector holds the checkout's facts for the span
    // it was built for, and a `code_work` step during a pick rewrites that
    // checkout — one built for the whole drain would answer the next item from the
    // pre-edit tree. The executor asks for an item exactly once, so building it
    // per ask is building it per pick.
    collectSignalsFor: (task, at, item) => collectSignalsForTask({ gh, repo, root, config, defaultBranch })(task, at, item),
    runTaskCodeWork: codeWorkRunner({ root, repo, defaultBranch }),
    invokeAgent: agentInvoker({ repo, config }),
    runCost,
  });

  console.log(done.length
    ? done.map((d) => `- #${d.issue}: ${d.outcome}`).join('\n')
    : '- nothing ready to pick up');
  // Into the log as well as onto the items: a run that settled nothing has no item
  // to write on, and its cost — the pick that found an empty queue — is exactly the
  // figure a quiet day is made of.
  console.log(`\n${runCost.record()}`);
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  runExecutorJob().catch((e) => { console.error(e); process.exitCode = 1; });
}
