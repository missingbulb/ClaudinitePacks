// The signal collectors. Each reads a
// bounded, cheap slice of the repo's GitHub state (or local disk) for one signal
// name; `collectSignals` gathers only the union the PICKED task declared, so an
// frequent task never pays for a rarer one's signals. Every collector takes the
// shared `(gh, ctx)` and returns a plain data object a precondition reads.
//
// Pure over the injected `gh` reader and a `ctx` of already-resolved facts, so
// the whole layer tests against a fake `gh` with no live GitHub. The ctx facts a
// collector cannot fetch for itself (manifest version, local-pack presence,
// retention) are read off the checkout by the caller.

import { SHARED_SUBDIR } from '../../../../engine/pack_loader/pack-registry.mjs';
import { LOCAL_PACK_ROOT } from '../world/git.mjs';
import {
  QUEUED_LABEL, ORIGIN_AD_HOC, REQUEST_LABEL, STATUS_BLOCKED, STATUS_READY,
} from '../../public/task-constants.mjs';
import {
  workItemTitle, statusOf, statusesOn, parkKindOf, outcomeOf, parseWorkItemBody, labelNames,
} from '../../public/work-item-grammar.mjs';
import { isQueueItem } from '../items/read.mjs';
import { APPROVAL_RE } from '../contract/built-in-tasks.mjs';
import { taskFromMessage } from '../../public/work-item-grammar.mjs';
import { isSubstantiveCommit, HOUSEKEEPING } from './substantive-commit.mjs';
import { readCommit, latestRelease, readBranch, readTree, getIssue, collaboratorPermission, listIssuesByQuery } from '../world/github.mjs';

// How far back the run history reads: the longest any
// cadence term looks, a month, plus slack. A run older than this is not in the
// record — a task then reads as not having run in that long, which is the honest
// state-free answer. The scheduler's own queue read is bounded by the same figure.
export const RUN_HORIZON_DAYS = 40;

// What counts as genuine project work, and what is the machinery moving, is
// `isSubstantiveCommit`'s test - shared with the readers outside this pack that must
// classify a member's commits the same way. Here the file list is always resolved, so
// its corpus-only exclusion applies in full.

// The capture stamp a conversation log's filename leads with:
// `2026-07-19T0940Z--pr-1583--<session>.jsonl` (or `--issue-123--`) — minute precision, optionally
// `-<k>` suffixed on a same-minute collision. Anything else on the logs branch
// (its README) is not a log and has no age. The writer of that name is the
// capture step in the pack that owns the branch, which this pack deliberately does
// not import (packs stay independent); a drift guard in this pack's tests pins this
// parse to that writer, so
// changing one without the other fails loudly rather than silently retiring the
// prune trigger.
const LOG_STAMP = /^(\d{4}-\d{2}-\d{2})T(\d{2})(\d{2})Z(?:-\d+)?--(?:pr|issue)-\d+--.+\.jsonl$/;
function logStampMs(name) {
  const m = LOG_STAMP.exec(name);
  if (!m) return null;
  const ms = Date.parse(`${m[1]}T${m[2]}:${m[3]}:00Z`);
  return Number.isFinite(ms) ? ms : null;
}

async function paged(gh, path, maxPages = Infinity) {
  const out = [];
  for (let page = 1; page <= maxPages; page += 1) {
    const sep = path.includes('?') ? '&' : '?';
    const { status, json } = await gh(`${path}${sep}per_page=100&page=${page}`);
    if (status !== 200 || !Array.isArray(json) || json.length === 0) break;
    out.push(...json);
    if (json.length < 100) break;
  }
  return out;
}

// Like `paged`, but for a listing sorted `updated` DESCENDING and bounded by the
// window: it stops at the first item outside it and does not fetch the next page.
// The closed-PR listing is otherwise the repo's whole history — a window read must
// not cost proportionally to that.
async function pagedWindow(gh, path, inWindow) {
  const out = [];
  for (let page = 1; ; page += 1) {
    const sep = path.includes('?') ? '&' : '?';
    const { status, json } = await gh(`${path}${sep}per_page=100&page=${page}`);
    if (status !== 200 || !Array.isArray(json) || json.length === 0) break;
    const kept = [];
    for (const item of json) {
      if (!inWindow(item)) break;
      kept.push(item);
    }
    out.push(...kept);
    if (kept.length < json.length || json.length < 100) break;
  }
  return out;
}

// `isMinablePr`: a merged PR is mineable unless it is bot work or one of Claudinite's own
// automated writes — the same author/message exclusions `isSubstantiveCommit` and the
// `issues` collector apply, kept together on purpose. It does NOT carry the
// corpus-only exclusion: the PR listing has no file list, and resolving one per
// PR would cost a read per PR across the whole window. It does not need to —
// a corpus-only PR's merge commit is already non-substantive, so no task with a
// `commits`-gated precondition ever reaches this listing on its account. The
// housekeeping regex already covers the growth tasks' own `Claudinite growth: …` PRs
// and the scheduler's `[claudinite-task]` titles, so the self-trigger guards hold here.
//
// How far the per-open-PR file read pages before it stops (100 files a page).
const PR_FILE_PAGES = 3;

const isMinablePr = (p) => {
  if ((p.user?.login ?? '').endsWith('[bot]')) return false;
  return !HOUSEKEEPING.test((p.title ?? '').trim());
};

// A commit's changed-file list, read from the API AT MOST ONCE PER READER: the
// scheduler collects signals once per task and every commit-derived collector
// resolves the same window, so without this a forty-commit weekly window cost a
// read per commit per task — five hundred sequential calls, most of a five-minute
// run (#2013). Keyed on the reader so a test's fake `gh`, or a fleet reader over
// another repo, never sees a sha another reader resolved. Only a 200 is kept: a
// rate limit or a 5xx is the next collector's to retry, not the run's verdict.
const fileListsByReader = new WeakMap();
async function readCommitFiles(gh, repo, sha) {
  let memo = fileListsByReader.get(gh);
  if (!memo) fileListsByReader.set(gh, (memo = new Map()));
  const key = `${repo}@${sha}`;
  if (memo.has(key)) return memo.get(key);
  const d = await readCommit(gh, repo, sha);
  if (d.status !== 200) return [];
  const files = (d.json?.files ?? []).map((f) => f.filename).filter(Boolean);
  memo.set(key, files);
  return files;
}

// Commit objects in the window, with their changed-file lists resolved.
async function readWindowCommits(gh, repo, branch, sinceIso) {
  const list = await paged(gh, `/repos/${repo}/commits?sha=${encodeURIComponent(branch)}&since=${sinceIso}`);
  const detailed = [];
  for (const c of list) {
    const files = await readCommitFiles(gh, repo, c.sha);
    detailed.push({
      sha: c.sha,
      message: c.commit?.message ?? '',
      author: c.author?.login ?? null,
      // Which scheduled task wrote it, or null — the silence gate's structural
      // classification, carried through so a consumer can say WHY a commit did
      // not count rather than only that it did not.
      task: taskFromMessage(c.commit?.message ?? ''),
      substantive: isSubstantiveCommit(c, files),
      files,
    });
  }
  return detailed;
}

const COLLECTORS = {
  async commits(gh, ctx) {
    const commits = ctx.commits ?? await readWindowCommits(gh, ctx.repo, ctx.defaultBranch, ctx.sinceIso);
    return {
      list: commits,
      count: commits.length,
      substantiveChange: commits.some((c) => c.substantive),
      touchedPaths: [...new Set(commits.flatMap((c) => c.files))],
    };
  },

  async prs(gh, ctx) {
    const open = await paged(gh, `/repos/${ctx.repo}/pulls?state=open&sort=updated&direction=desc`);
    const since = new Date(ctx.sinceIso);

    // PRs MERGED during the window, in a field of their OWN. A merged PR carries
    // the review discussion and the "what changed and why" — usually the richest
    // lesson material in a window. It is deliberately NOT folded into `open` or
    // `touched`: those two are other tasks' target sets, and widening them here
    // would silently widen what those tasks do.
    // The same exclusions the `commits` and `issues` collectors apply hold here, so
    // a growth task still cannot see its own merged output and re-trigger on it.
    const closed = await pagedWindow(
      gh,
      `/repos/${ctx.repo}/pulls?state=closed&sort=updated&direction=desc`,
      (p) => new Date(p.updated_at) >= since,
    );
    const mergedCandidates = closed.filter((p) => p.merged_at && new Date(p.merged_at) >= since && isMinablePr(p));

    // WHICH OF THE WINDOW'S PRs A SCHEDULED TASK WROTE, read structurally rather
    // than off its title: one commit read per PR that moved in the window, for its
    // head's `Claudinite-Task:` trailer. This is what makes the
    // silence gate hold for a task added tomorrow — a title regex has to learn
    // each new task's name, and only ever learns it after that task re-armed a
    // neighbour with its own output.
    //
    // Scoped to the window's PRs, never the whole open set: `open` is other tasks'
    // TARGET set (the pending-round conditions read its paths), and only MOVEMENT is
    // what the trailer reclassifies.
    const inWindow = open.filter((p) => new Date(p.updated_at) >= since);
    const taskAuthored = new Map();
    for (const p of [...inWindow, ...mergedCandidates]) {
      if (taskAuthored.has(p.number)) continue;
      const sha = p.head?.sha;
      if (!sha) { taskAuthored.set(p.number, false); continue; }
      const head = await readCommit(gh, ctx.repo, sha);
      // An unreadable head is UNKNOWN, and unknown is not task-authored: a PR a
      // person opened must never be classified as machinery over a failed read.
      taskAuthored.set(p.number, head.status === 200 && taskFromMessage(head.json?.commit?.message ?? '') !== null);
    }

    const merged = mergedCandidates
      .filter((p) => !taskAuthored.get(p.number))
      .map((p) => ({ number: p.number, title: p.title, mergedAt: p.merged_at }));

    // Each open PR's changed paths — the pending work itself, so a precondition
    // can rule on WHAT is waiting for review rather than on a marker somebody has
    // to remember to apply (wiki-growth declines while a `product-wiki/` change is
    // pending). One read per open PR: the open set is a handful, and no PR listing
    // carries files.
    //
    // `null` is UNKNOWN, and it is a third state, not an empty list: every PR
    // changes at least one file, so an empty read is a read that failed, and a
    // precondition gating on a path must decline on "I could not look" rather than
    // read it as "nothing pending".
    const withPaths = [];
    for (const p of open) {
      // Capped at PR_FILE_PAGES: past it a PR is a mass refactor, whose paths no
      // consumer of this signal rules on, and paying 30 reads for one would be the
      // window's whole budget.
      const files = await paged(gh, `/repos/${ctx.repo}/pulls/${p.number}/files`, PR_FILE_PAGES);
      const changedPaths = files.map((f) => f.filename).filter(Boolean);
      withPaths.push({
        number: p.number, title: p.title, updatedAt: p.updated_at,
        changedPaths: changedPaths.length ? changedPaths : null,
      });
    }

    return {
      open: withPaths,
      touched: inWindow.filter((p) => !taskAuthored.get(p.number)).map((p) => p.number),
      merged,
    };
  },

  async issues(gh, ctx) {
    const open = await paged(gh, `/repos/${ctx.repo}/issues?state=open&sort=updated&direction=desc`);
    const since = new Date(ctx.sinceIso);
    // Exclude PRs (the issues endpoint returns both) and the scheduler's own
    // work items, its schedule board, and standing trackers — invisible to
    // signals. The board especially: every rewrite would land in
    // `issues.touched` and wake an issue-gated task on the queue's own churn (F8).
    const real = open.filter((i) => !i.pull_request
      && !/^\[claudinite-(task|work|schedule)\]/.test(i.title ?? '')
      && !/^(claudinite tracker:|\[claudinite\] ci performance$|auto-improvements tracker\b|repo tidy tracker$)/i.test((i.title ?? '').trim()));
    return {
      open: real.map((i) => ({ number: i.number, title: i.title, updatedAt: i.updated_at, labels: (i.labels ?? []).map((l) => l.name ?? l) })),
      touched: real.filter((i) => new Date(i.updated_at) >= since).map((i) => i.number),
    };
  },

  // Every open branch, each with the date of its tip commit — so a precondition
  // can tell a branch that MOVED in the window from the standing pile that did
  // not. `touched` is the same field name, with the same meaning, the `prs` and
  // `issues` collectors carry; without it every gate over the branch dimension
  // degenerates to "a branch exists".
  //
  // The tip date costs one commit read per DISTINCT tip sha (branches sharing a
  // tip share the read) because the branch listing carries no date of its own —
  // no REST listing does. That is the price of the only newness this dimension
  // can observe, and it is paid on a weekly clock over a handful of branches.
  // A tip read that fails leaves `updatedAt: null`, which is NOT touched: no
  // proof of movement never wakes an agent.
  async branches(gh, ctx) {
    const list = await paged(gh, `/repos/${ctx.repo}/branches`);
    const since = new Date(ctx.sinceIso);

    const dateBySha = new Map();
    for (const sha of new Set(list.map((b) => b.commit?.sha).filter(Boolean))) {
      const { status, json } = await readCommit(gh, ctx.repo, sha);
      const c = status === 200 ? json?.commit : null;
      dateBySha.set(sha, c?.committer?.date ?? c?.author?.date ?? null);
    }

    const entries = list.map((b) => ({ name: b.name, updatedAt: dateBySha.get(b.commit?.sha) ?? null }));
    return {
      names: entries.map((e) => e.name),
      list: entries,
      touched: entries.filter((e) => e.updatedAt && new Date(e.updatedAt) >= since).map((e) => e.name),
    };
  },

  async release(gh, ctx) {
    const { status, json } = await latestRelease(gh, ctx.repo);
    const latestTag = status === 200 ? (json?.tag_name ?? null) : null; // 404 → no release yet
    return { latestTag, manifestVersion: ctx.manifestVersion ?? null, shipsPipeline: ctx.shipsReleasePipeline ?? null };
  },

  // Whether a window commit touched the repo's local packs.
  // Whether the repo HAS local packs is not a question: adoption seeds
  // `.claudinite/local/packs/<repo>/` and the nightly deliberately never re-seeds
  // or removes it, so movement is the only thing left to report.
  async localPacks(gh, ctx) {
    const commits = ctx.commits ?? await readWindowCommits(gh, ctx.repo, ctx.defaultBranch, ctx.sinceIso);
    const touches = (f) => f.startsWith(LOCAL_PACK_ROOT);
    return { changedInWindow: commits.some((c) => c.files.some(touches)) };
  },

  // Which DECLARED packs' vendored files changed in the window — the local echo
  // of "canon changed".
  async sharedMount(gh, ctx) {
    const commits = ctx.commits ?? await readWindowCommits(gh, ctx.repo, ctx.defaultBranch, ctx.sinceIso);
    const declared = new Set(ctx.activePacks ?? []);
    const changed = new Set();
    for (const c of commits) {
      for (const f of c.files) {
        const m = /^\.claudinite\/shared\/packs\/([^/]+)\//.exec(f);
        if (m && declared.has(m[1])) changed.add(m[1]);
      }
    }
    return { changedPacks: [...changed] };
  },

  // The conversation-logs orphan branch: present, and the age of its oldest JSONL
  // vs the configured retention (the age-based prune's trigger on quiet repos).
  //
  // Age comes from the FILENAME stamp, not from git/commit metadata. Commit dates
  // are the authoritative record of when a blob landed, but they are the wrong
  // authority here and cost more: (a) AGREEMENT — the consuming task's prune rule
  // is itself stated over the filename stamp ("each log whose filename stamp is
  // older than retention"), so a commit-date trigger would dispatch an agent over
  // logs the worker then declines to prune, and stay silent on ones it would
  // prune; (b) COST — one tree
  // read covers the whole branch, against one commit-history read per file, and
  // the branch accumulates one log per merged session. The name is machine-written
  // by the pack's capture step, never user input, so "trusting the name" is
  // trusting our own writer — and a drift guard pins the two formats together.
  async conversationLogs(gh, ctx) {
    const retentionDays = ctx.retentionDays ?? null;
    const branch = await readBranch(gh, ctx.repo, 'conversation-logs');
    if (branch.status !== 200) {
      return { present: false, retentionDays, oldestLogAgeDays: null, newestLogAgeDays: null, logCount: 0 };
    }

    // Logs sit flat at the branch root beside its README; a non-200 tree read (or
    // anything unparsable on it) is "no age to judge", never a failed collection.
    const { status, json } = await readTree(gh, ctx.repo, 'conversation-logs');
    const stamps = (status === 200 && Array.isArray(json?.tree) ? json.tree : [])
      .map((e) => logStampMs(e?.path ?? ''))
      .filter((ms) => ms !== null);
    const now = new Date(ctx.now).getTime();
    const age = (ms) => (stamps.length && Number.isFinite(now) ? (now - ms) / 86400000 : null);
    // Both ends, because they answer opposite questions. The OLDEST drives the
    // age-based prune (is anything past retention). The NEWEST is the only NEWNESS
    // this dimension has: "did a session capture in the window", which is what a
    // precondition gated on repo movement needs and which a total count — true
    // forever once true — cannot say.
    return {
      present: true,
      retentionDays,
      oldestLogAgeDays: stamps.length ? age(Math.min(...stamps)) : null,
      newestLogAgeDays: stamps.length ? age(Math.max(...stamps)) : null,
      logCount: stamps.length,
    };
  },

  // WHAT THE MOUNT HOLDS, and whether it moved in this window: the installed engine
  // version, the installed pack versions, and whether any `.claudinite/shared/**`
  // file was touched by a commit in the window.
  //
  // `convergedInWindow`, not the stamp's age (#1252): the stamp's datetime records
  // the last FULL re-vendor rather than the last converge, so it reads months stale
  // on a member converging nightly - and newness taken from the
  // objects' OWN movement in the window is where every other precondition here gets
  // it. `present` is the mount's existence, which the versions answer directly: an
  // engine that stamps always stamps.
  async stamp(gh, ctx) {
    const commits = ctx.commits ?? await readWindowCommits(gh, ctx.repo, ctx.defaultBranch, ctx.sinceIso);
    const convergedInWindow = commits.some((c) => c.files.some((f) => f.startsWith(`${SHARED_SUBDIR}/`)));
    return {
      present: (ctx.config?.engineVersion ?? null) !== null || Object.keys(ctx.config?.packVersions ?? {}).length > 0,
      engineVersion: ctx.config?.engineVersion ?? null,
      packVersions: ctx.config?.packVersions ?? {},
      convergedInWindow,
      canonHead: ctx.canonHead ?? null,
    };
  },

  // THE REQUEST READ. Unlike every collector beside
  // it, this one reads a single named object rather than a window: the issue THIS
  // item was created for, off `ctx.item.request`. That is what the precondition's
  // third argument buys — a verdict about one issue, which no window of repo
  // activity can single out.
  //
  // It reads facts and forms no judgment: who asked, who blessed it with the
  // approval phrase, and what PERMISSION each of them holds — never whether that is
  // enough. The rule lives in the task's precondition, where every other verdict is.
  //
  // Three shapes of answer, and the difference between the last two is the whole of
  // F27: `gone` (the API says it does not exist) is a fact a precondition can
  // decline on, while `unreadable` (a rate limit, a 500) is one it must NOT — a
  // decline's write-back cannot reach an issue it cannot read.
  async request(gh, ctx) {
    const number = ctx.item?.request ?? null;
    if (!number) return null;
    const { status, json } = await getIssue(gh, ctx.repo, number);
    if (status === 404 || status === 410) return { number, gone: true };
    if (status !== 200 || !json) return { number, unreadable: true, error: `the issues API answered ${status}` };

    // The permission API is the authority, never the payload's `author_association`:
    // `MEMBER` is any org member whatever their repo permission, and `COLLABORATOR`
    // includes read-only collaborators — both broader than push (F30). A read that
    // fails is unreadable, not "no permission": guessing downward here would refuse
    // a legitimate request over a rate limit.
    const permissions = new Map();
    let failed = null;
    const permissionOf = async (login) => {
      if (!login) return 'none';
      if (permissions.has(login)) return permissions.get(login);
      const res = await collaboratorPermission(gh, ctx.repo, login);
      // A 403/404 here is a real answer: the caller may not read collaborators, or
      // this login is not one. The first is a repo-configuration fault and the
      // second is the ordinary "a stranger opened it" case, and only the API can
      // tell them apart — so a 404 is `none` and anything else stops the read.
      let value;
      if (res.status === 200) value = res.json?.role_name ?? res.json?.permission ?? 'none';
      else if (res.status === 404) value = 'none';
      else { failed = `the permission API answered ${res.status} for @${login}`; value = 'none'; }
      permissions.set(login, value);
      return value;
    };

    const author = json.user?.login ?? null;
    const authorPermission = await permissionOf(author);
    // The approval phrase is only worth a permission read on the comments that
    // carry it, so an issue with a long thread costs one read per distinct blesser.
    const comments = await paged(gh, `/repos/${ctx.repo}/issues/${number}/comments`);
    const approvals = [];
    for (const c of comments) {
      const login = c.user?.login ?? null;
      if (!login || !APPROVAL_RE.test(c.body ?? '')) continue;
      approvals.push({ login, permission: await permissionOf(login) });
    }
    if (failed) return { number, unreadable: true, error: failed };

    return {
      number,
      state: json.state,
      labels: (json.labels ?? []).map((l) => l.name ?? l),
      // STILL MARKED, in any spelling this repo's issues may carry: the origin the
      // one-issue model applies, and the two retired `claude-*` labels a shadow item's
      // issue wears. Withdrawing is removing what marked it, whichever that was.
      queued: (json.labels ?? []).map((l) => l.name ?? l)
        .some((l) => [ORIGIN_AD_HOC, QUEUED_LABEL, REQUEST_LABEL].includes(l)),
      author,
      authorPermission,
      approvals,
    };
  },

  // THE RUN HISTORY: this task's own unqualified work
  // items over the horizon, newest first, the item under evaluation excluded — what
  // the cadence terms and the since-last-run window read. Off `ctx.items` where the
  // caller already holds the queue (the scheduler run fetched it, so the whole
  // repo's tasks cost no read); off the ISSUES list API otherwise (the executor at
  // pick) — never the search index (S6/F11), and `since` bounded to the horizon so
  // a long-lived repo's closed history is not paged.
  //
  // A qualified item (a fan-out target, a request naming its issue) is not a run of
  // the task's standing occurrence and is not evidence of one; it is invisible here.
  async runs(gh, ctx) {
    if (!ctx.task?.pack || !ctx.task?.id) throw new Error('the runs collector needs the task whose history it reads');
    const title = workItemTitle({ pack: ctx.task.pack, task: ctx.task.id });
    const horizonIso = new Date(new Date(ctx.now).getTime() - RUN_HORIZON_DAYS * 86400e3).toISOString();
    const items = ctx.items ?? await readWorkItems(gh, ctx.repo, `state=all&since=${encodeURIComponent(horizonIso)}`);
    // A run begins at the pick. An item nobody has picked yet, or that was closed
    // before anyone picked it, still wears the status it waited in — open, or
    // beside the terminal label the scheduler's dedupe, orphan and supersede
    // writes add (a person's close adds nothing; the executor's own close always
    // swaps it out). It never ran and never declined, so it is not a run:
    // counted, two twins decline each other at pick and a deduped one spends the
    // period on the survivor (SCENARIOS F32), and a hand-closed item stands
    // between `last-run-not-failed` and the failure park behind it.
    const unpicked = (i) => statusesOn(i).some((s) => s === STATUS_BLOCKED || s === STATUS_READY);
    const list = items
      .filter((i) => String(i.title ?? '').trim() === title && i.number !== ctx.item?.number && !unpicked(i))
      .map((i) => ({
        number: i.number,
        createdAt: i.created_at,
        closedAt: i.closed_at ?? null,
        state: i.state,
        status: statusOf(i),
        park: parkKindOf(i),
        outcome: outcomeOf(i),
        woken: parseWorkItemBody(i.body ?? '').woken !== null,
      }))
      .sort((a, b) => b.number - a.number);
    return { list, horizonDays: RUN_HORIZON_DAYS };
  },

  // THE OPEN QUEUE - every open work item in the repo, whichever task it belongs
  // to, in the shape the janitor's rules read. Deliberately the one dimension
  // `issues` hides: that collector drops work items so the queue's own churn
  // cannot wake an issue-gated task (F8), which leaves the queue itself
  // unobservable - and a task whose subject IS the queue then has nothing to gate
  // on. Only a term naming `queue` sees it, so the exclusion above stands for
  // everyone else.
  //
  // Served off `ctx.items` where the caller already holds the queue - the
  // scheduler run listed it before asking anybody, so this costs no read at the
  // tick, which is what makes it affordable on a daily task's gate. The executor
  // at pick holds none and reads the open list.
  async queue(gh, ctx) {
    if (ctx.items) return { open: ctx.items.filter((i) => i.state === 'open') };
    const raw = await readWorkItems(gh, ctx.repo, 'state=open');
    return {
      open: raw.map((i) => ({
        number: i.number, title: i.title, body: i.body ?? '', state: i.state,
        labels: labelNames(i), created_at: i.created_at, closed_at: i.closed_at ?? null,
        updated_at: i.updated_at,
      })),
    };
  },

  // Fleet aggregate - canon-only, over the fleet PAT. A consumer cannot declare
  // it; the collector returns null unless the caller supplied a fleet reader.
  async fleet(gh, ctx) {
    return ctx.fleet ?? null;
  },
};

// Every work item matching `scope`, off the issues list. A page that
// could not be read THROWS — the collector then records `{ error }` and every
// term over it fails loud — because a truncated history reads as a shorter one,
// and "no run in this period" on that evidence is a double run. The open queue
// reads the same way for the same reason: a page that never arrived is a repair
// nobody is asked to make.
async function readWorkItems(gh, repo, scope) {
  const out = [];
  for (let page = 1; ; page += 1) {
    const q = `${scope}&sort=created&direction=desc&per_page=100&page=${page}`;
    const { status, json } = await listIssuesByQuery(gh, repo, q);
    if (status !== 200 || !Array.isArray(json)) throw new Error(`the work-item list could not be read at page ${page} (${status})`);
    for (const i of json) {
      if (i.pull_request || !isQueueItem(i)) continue;
      out.push(i);
    }
    if (json.length < 100) break;
  }
  return out;
}

export const SIGNAL_COLLECTORS = Object.keys(COLLECTORS);

// Collect exactly the requested signal names into one object. An unknown name is
// ignored (the task-declaration-shape check rejects those at author time); a
// collector that throws records `{ error }` under its key rather than sinking the
// whole collection (per-signal isolation).
export async function collectSignals(gh, ctx, names) {
  const out = {};
  // Commit-derived collectors share one window read.
  if (names.some((n) => ['commits', 'localPacks', 'sharedMount', 'stamp'].includes(n)) && !ctx.commits) {
    try { ctx = { ...ctx, commits: await readWindowCommits(gh, ctx.repo, ctx.defaultBranch, ctx.sinceIso) }; } catch { /* collectors re-read on demand */ }
  }
  for (const name of names) {
    const collect = COLLECTORS[name];
    if (!collect) continue;
    try { out[name] = await collect(gh, ctx); }
    catch (e) { out[name] = { error: e.message }; }
  }
  return out;
}
