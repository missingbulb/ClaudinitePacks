// The `ctx` every signal collector reads (docs/PRINCIPLES.md) —
// the already-resolved facts a collector may not go and fetch for itself, built
// once per collection and handed to `collectSignals`.
//
// Its own module so the construction is testable on its own: the collectors'
// `ctx.X ?? null` seam makes them unit-testable with a hand-built ctx, which is
// exactly why a key nothing here populates can read as "collector works" forever.
// Assert against THIS, not a hand-built shape.
//
// `root` is the Action-side checkout: the manifest version and the configured
// retention are read from it, because a scheduled run already
// has the tree on disk and an API round-trip would buy nothing.

import { localSignalContext } from '../world/git.mjs';

// `item` is the OCCURRENCE the signals are being collected for, where the caller
// has one — the executor always does — as `itemFacts` reads it. Almost every
// collector reads a window of repo activity and ignores it; the `request`
// collector reads the single issue this item names, which is a fact no window can
// single out, and the `runs` collector excludes it from the task's history.
//
// `task` is `{ pack, id }`, the task whose run history is being read, and `items`
// the queue where the caller already fetched it (the scheduler run) — null where
// the collector reads it for itself (the executor at pick).
//
// `local` is the checkout half of the ctx where the caller already
// has it: a collector that builds several contexts over one `root` probes the disk
// once instead of once per context. Absent, it is read here.
export function buildSignalContext({
  root, repo, defaultBranch, now, sinceIso, config, fleet = null, item = null, task = null, items = null, packConfigFor = () => ({}), local = null,
}) {
  local ??= localSignalContext(root, { packIds: config.packs ?? [], packConfigFor });
  return {
    repo, defaultBranch, now, sinceIso, config, item, task, items,
    activePacks: config.packs, fleet,
    manifestVersion: local.manifestVersion,
    shipsReleasePipeline: local.shipsReleasePipeline,
    retentionDays: local.retentionDays,
  };
}
