// The `fleet` signal reader - the members
// aggregate the CANON repo's fleet-scoped tasks (growth-promote,
// growth-discover-packs) decide from. A consumer cannot
// declare `fleet`; only the canon repo's scheduler builds it, over the fleet PAT
// (`FLEET_GITHUB_TOKEN` — the census's existing credential, the one token that
// can enumerate every repo the owner owns; the Action's default GITHUB_TOKEN sees
// only this repo). The collector invokes this ONLY when the picked task declares
// `fleet`, so an ordinary night pays nothing for the fleet enumeration.
//
// Pure over an injected `fleetGh` (the same `gh(path) -> { status, json }` shape
// the other collectors take), so the whole reader tests against a fake `gh` with
// no live GitHub. The one place the real
// FLEET_GITHUB_TOKEN is read is `makeFleetGh`, at the I/O edge.
//
// Each member carries its provenance stamp so the retire guard can read per-repo
// apply evidence.

import { makeGh } from '../world/github.mjs';
import { packEntryId } from '../../../../engine/pack_loader/pack-registry.mjs';
// A window commit touching the local-pack root is a local-pack change (promote's
// trigger). One definition, shared with the per-repo probes.
import { LOCAL_PACK_ROOT } from '../world/git.mjs';
import { SETTINGS_FILE } from '../../../../engine/settings-file.mjs';
// The one definition of dormancy, shared with every other fleet reader: a second
// notion of it would sweep exactly the members that had already opted out. It is the
// scheduler's own parameter, so it is read from the pack that owns the scheduler.
import { isDormant } from '../contract/dormancy.mjs';
import { actionsEnv } from '../world/actions.mjs';
import { readCommit } from '../world/github.mjs';

async function paged(gh, path) {
  const out = [];
  for (let page = 1; ; page += 1) {
    const sep = path.includes('?') ? '&' : '?';
    const { status, json } = await gh(`${path}${sep}per_page=100&page=${page}`);
    if (status !== 200 || !Array.isArray(json) || json.length === 0) break;
    out.push(...json);
    if (json.length < 100) break;
  }
  return out;
}

// A repo mounts Claudinite iff it carries the tracked declaration file — the one
// membership signal every member has whatever its mount shape (the same test the
// census's isCovered uses: activePacks are read from it, so a mount marker with
// no declaration is a half-adoption that must classify as uncovered).
function parseChecks(contentB64) {
  try { return JSON.parse(Buffer.from(contentB64, 'base64').toString('utf8')); }
  catch { return null; }
}

// The member's declared packs (BARE ids, either declaration form), each entry's
// config (id -> config, so home-only gates honor per-pack settings like the
// growth promote opt-out), the per-repo scheduling cutover marker, and the
// vendored-mount provenance stamp (retire's per-repo apply evidence).
function readDeclaration(checks) {
  const entries = Array.isArray(checks?.packs) ? checks.packs : [];
  const activePacks = entries.map((e) => packEntryId(e)).filter((id) => typeof id === 'string');
  const packConfigs = {};
  for (const e of entries) {
    if (e && typeof e === 'object' && typeof e.id === 'string' && e.config !== undefined) {
      packConfigs[packEntryId(e)] = e.config;
    }
  }
  const schedulesItself = checks?.taskScheduler !== undefined && checks?.taskScheduler !== null;
  const stamp = checks?.claudinite ?? null;
  return {
    dormant: isDormant(checks),
    activePacks,
    packConfigs,
    schedulesItself,
    stamp: stamp ? { updated: stamp.updated ?? null, ref: stamp.ref ?? null } : null,
  };
}

// Did a default-branch commit in the window touch this member's local packs (the
// real promote trigger — a member that changed product code but not its local
// packs has nothing to lift up)? Scans only the window's commits (a handful) and
// stops at the first hit; a commit whose files can't be read contributes nothing.
async function localPacksChangedInWindow(gh, fullName, defaultBranch, sinceIso) {
  const list = await paged(gh, `/repos/${fullName}/commits?sha=${encodeURIComponent(defaultBranch)}&since=${sinceIso}`);
  for (const c of list) {
    if (!c?.sha) continue;
    const detail = await readCommit(gh, fullName, c.sha);
    const files = detail.status === 200 ? (detail.json?.files ?? []) : [];
    if (files.some((f) => typeof f.filename === 'string' && f.filename.startsWith(LOCAL_PACK_ROOT))) return true;
  }
  return false;
}

// Build one member's record from its declaration plus the local-pack window scan.
// `sinceIso` bounds the window. Whether the member HAS local packs is not probed:
// adoption seeds `.claudinite/local/packs/<repo>/` and the nightly deliberately
// never re-seeds or removes it, so the answer is yes for every member and the
// probe would cost one contents read per member per collection. An undeclared repo is
// still skipped — it is not a member anything plans for.
async function buildMember(gh, repo, sinceIso) {
  const fullName = repo.full_name;
  const defaultBranch = repo.default_branch || 'main';
  const decl = readDeclaration(repo.checks);
  const localChanged = decl.activePacks.length
    ? await localPacksChangedInWindow(gh, fullName, defaultBranch, sinceIso)
    : false;
  return {
    repo: fullName,
    defaultBranch,
    activePacks: decl.activePacks,
    packConfigs: decl.packConfigs,
    localPacksChanged: localChanged,
    schedulesItself: decl.schedulesItself,
    stamp: decl.stamp,
  };
}

// Read the fleet aggregate: every COVERED member the owner owns (excluding the
// canon repo itself, forks, archived repos, and members declaring themselves
// dormant), each with its declaration +
// local-pack window probe. Pure over `fleetGh`. Returns `{ owner, members, error }`;
// `error` is set (and `members` empty) when enumeration itself failed or returned
// nothing — a fleet task's precondition treats an errored/empty fleet as "no work
// I can prove", never as "the fleet is empty" (the census's own refuse-on-empty
// rule: an empty enumeration is a wrong-token/scope symptom, not consent).
export async function readFleet(fleetGh, { owner, canonRepo, sinceIso }) {
  const ownerLc = String(owner).toLowerCase();
  const mine = await paged(fleetGh, '/user/repos?affiliation=owner');
  const owned = mine.filter((r) => r?.owner?.login?.toLowerCase() === ownerLc);
  if (owned.length === 0) {
    return { owner: ownerLc, members: [], error: `enumeration returned no repos owned by ${ownerLc} — wrong token user or scope` };
  }
  const members = [];
  for (const r of owned.sort((a, b) => a.name.localeCompare(b.name))) {
    const fullName = r.full_name;
    if (fullName.toLowerCase() === String(canonRepo).toLowerCase()) continue; // the canon doesn't mount itself
    if (r.archived || r.fork) continue;
    const res = await fleetGh(`/repos/${fullName}/contents/${SETTINGS_FILE}`);
    if (res.status !== 200 || !res.json?.content) continue; // uncovered - no tracked declaration
    const checks = parseChecks(res.json.content);
    if (!checks) continue; // unparsable declaration → not a member we can plan for
    // Declared dormant → out of the recurring work, which is the only thing this
    // signal feeds. Skipped HERE rather than in each consuming precondition, so a
    // dormant member costs neither an opus sweep nor the per-member probes below.
    if (isDormant(checks)) continue;
    members.push(await buildMember(fleetGh, { full_name: fullName, default_branch: r.default_branch, checks }, sinceIso));
  }
  return { owner: ownerLc, members };
}

// The I/O edge: build a fleet `gh` from FLEET_GITHUB_TOKEN, or null when the
// secret isn't set (a consumer, or the canon before the secret is provisioned) —
// the collector then leaves ctx.fleet null and returns null, so the
// fleet tasks' preconditions skip rather than crash.
export function makeFleetGh(env = actionsEnv()) {
  const token = env.FLEET_GITHUB_TOKEN;
  if (!token) return null;
  return makeGh({ token });
}
