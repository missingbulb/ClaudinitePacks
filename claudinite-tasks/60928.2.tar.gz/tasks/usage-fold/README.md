# Usage fold — the repo's own past-data plane

**This task runs no agent.** It declares `code_worker_mjs: worker.mjs` and no agent, so the whole pass is the deterministic [`worker.mjs`](worker.mjs) the executor runs as code-work. It folds two rolling files, each past its own watermarks, and delivers them on one pull request:

- **the session half** - `.claudinite/usage/sessions-and-elements.json`, what this repo's sessions did, counted by [`fold-usage.mjs`](fold-usage.mjs);
- **the machinery half** - `.claudinite/usage/task-runs-and-costs.json`, what the scheduler and executor cost, counted by [`fold-tasks-usage.mjs`](fold-tasks-usage.mjs) behind [`machinery-half.mjs`](machinery-half.mjs); see [The machinery half](#the-machinery-half).

A half that fails costs only its own file: the other still lands, and the run then fails, naming the half that broke. This file is the human-facing record of what the worker does; there is no agent phase.

## What it does

Daily, when the repo moved: fetch this repo's orphan `conversation-logs` branch and count each capture file still inside the retention window; list the scheduler's and the executor's completed workflow runs since the last fold; list the work items that closed since the last fold, and the parks each of them collected; list the pull requests merged since the last fold, with what each took from opening, from its issue and from the session that did the work; deepen and read the local git history and the releases listing; and regenerate `.claudinite/usage/sessions-and-elements.json` on a PR that lands itself where this repo's delivery settings allow (the shared landing helper, `packs/claudinite-tasks/src/deliver/land-pr.mjs`, owns those nuances — a `review` repo's PR waits for the owner). A recompute that differs only in its `generated` stamp opens nothing, and a repo with no logs branch yet still folds every other source.

### Why daily, and what stops it being daily noise

This file is the **past-data plane the dashboard renders from** ([claudinite-dashboard](../../../claudinite-dashboard/README.md)): every panel reaching further back than one page of live reads comes from here, so the file's freshness *is* the page's. The cadence is affordable because the sources are — the capture files are local git, and the REST side is a handful of listings, all watermarked, plus one narrow read per item this fold is seeing settle for the first time.

What keeps a quiet repo quiet is the **precondition**, which runs the fold only when something moved since the last fold: a commit on the default branch, a conversation log stamped inside the window, or machinery that ran and is not yet folded - the machinery file's own `runsFoldedThrough` still standing before the day's anchor ([`preconditions.mjs`](preconditions.mjs)'s `runs-since-fold`). That last term reads the mark's own movement rather than standing state: it goes false the moment a fold catches up, and costs no API call. Declining loses nothing - the run and queue reads sit past their watermarks until the next fold that does have something to do, and the dashboard tops up the freshest hours from the live run listing it already fetches.

What it counts, per bucket:

- **`skillLoads`**, per skill name — `Skill` tool-use entries, plus user-typed `/command`s naming a skill this repo mounts (built-in CLI commands never match). Subagent streams included: a subagent loading a skill is a load.
- **`skillLoadsBy`**, per skill - the same loads split by **what made them happen**: a guard's block on an edit or a call, an injected trigger context, a typed command, a `Read` of the SKILL.md, or `voluntary`, which is the session reaching for it. The cause is the nearest earlier mark naming that skill since its last load, so the split is read from one ordered pass rather than guessed.
- **`skillSessions`**, per skill - distinct sessions with a load, per day. A session spanning midnight counts in both, so a window figure summed from these is a ceiling on distinct sessions rather than a count.
- **`skillBlocks`**, per skill - PreToolUse blocks naming it. **`triggerFires`**, per skill - a declared result or prompt trigger that fired, and whether a load followed it in the same session.
- **`moments`**, per skill - the occasions a skill's own force-load declarations named, counted with the resolver the hooks match with. Every occasion, whether or not the skill was already loaded: the hook loads once per session, so deduping to that would compare a number to itself. **No key at all** where the engine running the fold does not export the predicates - *not recorded*, which is not zero moments.
- **`toolCalls`**, per tool - every `tool_use` block, sidechains included. **`guardFires`**, per rule - an action guard's firings, split by what the call was told.
- **`skillCaught`**, per skill - sessions that loaded it and were caught blocking anyway by a check it owns. No key where the engine does not stamp which skill owns a check.
- **`checkTiming`**, per `<scope>` and `<scope>/<rule>` - what the Stop hook's sweep cost, from the timing record the runner prints. `maxMs` folds as a peak rather than a sum, because a week's slowest run is the slowest of its days' and never their total.
- **`captures`** — capture events folded. **`merges`** — the subset with an issue behind them (issue `0` means none).
- **`sessions`** — distinct session ids; one session can capture more than once.
- **`userMessages`** — genuine human turns. **`userCommands`** — every typed `/command`.
- **`tokensIn`** / **`tokensOut`** / **`tokenSessions`** — what the sessions spent, from the usage records the transcript's own assistant entries carry. **Probed, never assumed**: a transcript shape that records no usage leaves the day with no token keys at all, which is what makes "this shape does not record it" distinguishable from "it was free". Cache reads and writes count as input, because that is what the turn was billed for.
- **`commits`** / **`linesAdded`** / **`linesRemoved`** — what landed on the base branch, from local git. A shallow checkout is the normal case in Actions, so days before the history starts carry **no key** rather than a zero.
- **`tokensByModel`**, per model id — the same spend, split by the model billed for it, with `input` / `cacheRead` / `cacheCreate` / `output` kept apart so a reader can price a day per counter. `tokensIn` stays the sum of the first three, so nothing that already read the totals changes meaning. A spend whose entry names no model keys as `(unknown)`.
- **`humanSeconds`** / **`agentSeconds`** — how the sessions' wall clock divided, from the entry timestamps: each turn is billed the gap that produced it. The human side is capped per turn (the cap is declared in the file's own `caps` header), because a session left open overnight is not a night of someone's attention — so the figure is a floor. Subagent streams are excluded from both: their span is already inside the main-stream turn around them.
- **`prs`**, per PR number — `leadHours`, `issueLeadHours` and `sessionToMergeHours` for each pull request merged that day. **Durations, never percentiles**: a week's p50 is not derivable from its days' p50s, so the file carries the sample and the reader takes the quantile over whatever window it draws. A slot whose far end is unknown — a PR closing no issue, one whose session never captured — is absent, which is not a zero lead time.
- **`taskCost`**, per `pack/task` — `sessions`, `tokensIn`, `tokensOut` and `userMessages`, joined to the task through the same `claudinite-task-exec` record `taskExec` is counted from. `(none)` is a session a person started, which is the human-driven share; `(unresolved)` is one filed under an issue that attests no record, which is a hole in the record and never quietly counted as a person.
- **`parks`**, per `pack/task` — how often each task needed a human, by kind (`failure`, `action`, `decision`, `approval`), read off each closed item's own label *events*: an item's final labels say only where it ended, never where it stopped on the way. Counted once per item per kind.
- **`releases`** — releases published, from one listing read.
- **`checks`**, per scope (`work` / `world`) — `runs` (observed activations), `failures` (runs that reported a blocking finding), `errors` (the runner could not launch), the `blocking`/`advisory` finding volume, and `ciRuns`/`ciFailures` (the CI subset of the first two). **`checkFindings`**, per rule id — which rule caught what.

- **`queue`**, per `pack/task` — what each occurrence came to: closed work items counted under their outcome word (`done`, `delivered`, `obsolete`, `none`). The queue-era successor to the `tasks` rows below (#994) — see "What each occurrence came to".
- **`tasks`**, per `pack/task` — **historical only.** These rows counted what the retired slot scheduler did with each due task (`agent`, `code_work`, `skipped`, `failed`, `deferred`). Nothing writes that record any more, so these rows stop growing as the last slot-era logs age out of Actions retention. The reader stays because the logs inside that window are still real; see "The task invocations are a census" below for what replaces it and what does not.
- **`taskExec`**, per `pack/task` — what the **agent session** did with the item it was handed, distilled from the captured conversation logs: `success`, `failed`, `task-gone` (the item named a task the repo no longer carries), `invalid`. Counted off the machine-readable `claudinite-task-exec` records the session prints (`src/session/record-exec.mjs`; format owned by `packs/claudinite-tasks/src/items/run-record.mjs`), deduped on the full record tuple per capture file — never scraped from the agent's prose. A sample, of the sessions that captured.

The denominators are the point. A raw load count cannot tell healthy-rare from broken — a version-bump skill loading rarely is fine — so the question is loads *against the sessions where that skill's own declared trigger plausibly applied.*

## The check failures are the win

A skill load is evidence that guidance was *reached for*. A **check failure is evidence that it worked**: the finding goes back into the session through the Stop hook and the agent corrects before the work leaves the branch. So the failure counts are not a defect metric to drive down — they are the closest thing this pipeline has to a measure of what the corpus is worth, and `checkFindings` says which rule earned it.

Neither runner writes a metrics file, so both are counted off the marks they already leave in the transcript, each read by one tested function against a fixture copied from a real capture:

- **the Stop hook's `hooklog` line** (`… Stop: done exit=<n> <reason>`), which reaches the transcript via hook stderr — the only mark a *passing* run leaves, and therefore the only reason work-scope **runs** are countable and not just failures. Its reason also carries the two outcomes nothing else reveals: a `loop-guard-relent` (blocking findings that survived two fix attempts, printed as a message rather than a findings block) and a `runner-error` (the checks did not run at all — enforcement silently off, which is why it gets its own counter instead of hiding inside a clean day);
- **`report-findings`' summary line** (`N blocking, M advisory (<scope> scope: …)`), which names its own scope and survives the `| tail` an agent usually pipes a run through — printed only when there *were* findings, so it counts failures, never runs;
- **the runner's invocation in a Bash command** (`node …/check_the_world.mjs`), which is how the world scope runs at all — it is wired into the test/CI flow, not the Stop hook.

Runs come only from the marks a passing run also leaves; where a runner ran without its command naming it (a `make test` wrapping it), the summary lines are the floor, so the count is the **max** of the two signals rather than their sum. Only Bash and CI-log tool results are read, paired back to the tool that produced them — in the corpus that owns the runners, reading a file that merely *mentions* this vocabulary is the ordinary case.

### CI counts when the agent was in the loop on it

Write, commit, let CI run, fix what it caught is the same correction loop as the Stop hook's, one turn wider — so a CI check failure the session acted on is the same kind of win. It counts exactly when the session **pulled the job log in**, which is what "the agent was in the loop" means operationally. A nightly or post-merge run nobody looked at stays uncounted, correctly: nothing was corrected.

Two consequences, both mechanism rather than policy. Actions stamps every log line with its own timestamp before the command's output, so each mark tolerates that prefix — without it a fetched CI log reads as having printed nothing at all. And a job log gets fetched repeatedly while iterating on the failure, with nothing in a fetch saying *which run* it was, so CI texts dedupe on the check output itself: two fetches of one job collapse, two real runs differ by their timestamps.

**Every check number is a floor.** A run whose CI log nobody fetched left no mark in any session transcript; neither did a hook killed before it logged; and a green CI sweep prints nothing to be seen by, which is why the CI share is carried separately as `ciRuns`/`ciFailures` instead of quietly skewing a rate. The under-count is one-directional by construction, which is what keeps "the checks caught N things this week" a claim worth making.

## What each occurrence came to

Everything counted off the capture files is read out of *sessions*, so it sees only what was captured. A whole half of what this repo does opens no session at all — a precondition that finds nothing to do, an agentless task whose whole work is its code-work, an item that yielded to another. None of that leaves a transcript, and the first of them is the most common thing scheduling does.

The `tasks` rows used to answer that from the other side: the slot scheduler printed one line per due task into its own Actions log (`claudinite-task-run v1 <pack>/<task> [<slot>] <outcome>`). **That writer retired with the slot scheduler** (#974), so those rows are history — exact within the window they covered, ending where the slot scheduler did, not comparable to a period after it. The reader that fetched them retired with them too, rather than spending two API calls per run to find records nothing writes; the day rows now only age out, and the week rows that froze them keep them.

What replaced it is the **`queue`** rows (#994), and they are a better record: every occurrence *is* a work item, and a converged one closes wearing an `outcome:*` label. That survives Actions retention, it is clickable, and it names its own task. [`read-queue.mjs`](read-queue.mjs) reads the items that closed since the last fold and counts them per task per outcome.

Three families here are **appended once rather than recomputed**, each past its own watermark:

- the **hour rows'** run counts, past `runsFoldedThrough` ([`read-runs.mjs`](read-runs.mjs));
- the **`queue`** and **`parks`** rows, past `queueFoldedThrough` ([`read-queue.mjs`](read-queue.mjs));
- the **`prs`** rows, past `prsFoldedThrough` ([`read-prs.mjs`](read-prs.mjs)).

The reason is the source, not taste: the capture files are a local git branch this fold re-reads for free, while all three are rate-limited REST listings, and re-reading a month of them every run would cost orders of magnitude more calls for the same answer. Appending is safe because each is settled once seen - a completed run's conclusion does not change, a closed item's outcome label is written at convergence and never moved, and a merge date never moves at all. The merged-PR read is bounded on `merged_at` for the same reason. The queue read is bounded on `closed_at` rather than `updated_at` for exactly that reason: the listing is asked for everything *touched* since the mark (a comment counts as a touch), and only items that closed past it are counted, so nothing is ever counted twice.

The price is stated rather than hidden: a counting bug fixed later applies from the fix forward and does not heal these rows.

## Three tiers, three different mechanisms

- **Hours** cover the last three days, and are the tier the dashboard's live panels read. Their run counts are appended past the run watermark; their session counts are recomputed from the capture files every fold. The two are kept in separate *fields* rather than merged, because merging them would make the recompute silently double the appended total.
- **Days** are recomputed **from scratch, every run**, from the live capture files. No ingest ledger, no double-count risk, and a counting-bug fix self-heals the whole visible window on its next run. A day row drops out when its raw files age past retention — its content lives on in its week row.
- **Weeks** are appended **once**, past a single `foldedThrough` watermark: every day that has closed since the mark is added to its ISO week and the mark advances. Days close strictly in order, so a monotone mark is the entire exactly-once mechanism.

Week rows are frozen by that trade: a counting bug found later heals the day window automatically, but weeks folded under the old counting keep it — re-freezing would need raw data the retention TTL deliberately destroyed. Git history records which commit folded what. A *new* counter meets the same trade from the other end: weeks folded before the check counts existed carry no `checks` key, and the fold grows them from the day they close forward rather than refusing to advance the watermark past them — a partial series beats a wedged one.

## The file is GENERATED

`.claudinite/usage/sessions-and-elements.json` is machine-written and never hand-edited. It lives under `.claudinite/usage/`, beside the repo's other rolling records, where the vendoring refresh never reaches. It is rolling rather than regenerated: each fold starts from the last, so a lost copy is lost history. That is why its name carries no `GENERATED` and no `merge=ours` resolves a conflict by dropping one side; the fold rebuilds its branch from the base on every run instead. A member whose file still sits at `.claudinite/local/usage.GENERATED.json` has it moved by the next fold, in a rename commit that carries its bytes unchanged.

## Failure is visible, never silent

A fold outage longer than about `retention_days - 1` days loses the raw backing for the unfolded days. That loss is **declared**: each week row records how many days it absorbed, so a week reading `days: 5` states its own hole rather than quietly reporting a smaller number as if it were complete.

Every source is **independently** fail-soft, and each says so in the run log: one that cannot be read costs its own rows this fold and leaves its own watermark where it was, so the next fold retries exactly what it missed. None of them can take the capture-derived counts down with it.

And the same rule runs through every field: **an absent source leaves no key, never a zero.** A day before a shallow checkout's history starts has no commit or line counts; a day whose transcripts carried no usage records has no token counts; a week that absorbed days of both kinds reports only the days that knew. A reader meeting a missing key is meant to say *not recorded* — which is information — rather than draw a zero, which is a claim.

## The freshness stamp

The file carries `generated`, the time of the fold that last confirmed its numbers. That is **not** the same as when the file last landed: a quiet repo recomputes to the same numbers and opens no PR, so the commit date can be days older. The unchanged-compare deliberately ignores that one line - a stamp that forced a PR every run would be a stamp nobody could afford.

## The machinery half

The session file's numbers come out of capture files re-read for free off a local branch; every source behind the machinery file is a rate-limited REST listing read past a watermark. That difference is why they are two files with separate watermarks: one source's outage must not degrade the other's rows, and one watermark cannot stand for two clocks. They share their discipline - the tiers, the per-source fail-soft, **an absent source leaves no key, never a zero** - and their readers: the run listings are [`read-runs.mjs`](read-runs.mjs)'s, the task-and-park decoding [`read-queue.mjs`](read-queue.mjs)'s.

### What the file carries

`.claudinite/usage/task-runs-and-costs.json`, per hour, per day and per week:

- **Per workflow** (`scheduler`, `executor`) - `runs`, `jobs`, `minutesBilled`, and `spend`. Actions bills per **job**, not per run, so a run's minutes are the sum over its jobs of each job's wall time rounded up to a whole minute, and the two counts are kept apart. `spend` exists only where this pack's config carries `actionsMinuteRate`: unset leaves **no key at all**, because a public repo bills nothing and a private one bills something, and a zero would be a claim nobody made. The rate every figure was priced at is written into the file beside them, so a rate changed later cannot silently re-price rows frozen under the old one.
- **Per run** - `apiCalls` and the wall milliseconds of each phase (`list`, `ask`, `drain` for a tick; `pick`, `claim`, `code-work`, `hand-off`, `converge` for an executor run), from the `claudinite-run-cost` record every run prints. The format is [`run-record.mjs`](../../src/items/run-record.mjs)'s; the API calls are counted at the GitHub port itself, which is the only place every call passes through.
- **Per task** - what its occurrences came to (`done`, `delivered`, `obsolete`, `none`), the parks they collected by kind, and four **latency samples** off each closed item's own label events: tick→item, item→pick, pick→hand-off, hand-off→converge. Samples, never quantiles. A slot whose far end never happened - an agentless item has no hand-off - is absent, which is not a latency of zero.

### Where a run's cost record is read from

A **scheduler tick owns no work item**, so the record it printed exists nowhere but its job log, and the fold reads it there: at most two of its runs have their log read per fold, and at most two jobs are opened per run, so the log reads are bounded at four whatever else happened.

An **executor run has items**, so it writes its record onto every item it settles, in the same fenced block as the execution record. One run therefore leaves several snapshots of one record, each a reading of counters that only ever grow, and the fold keys them by run id and keeps the **largest** - the run's total as of its last item.

### The API budget

Per fold: two run listings, flat; one jobs listing per run this fold has not seen; at most four job-log reads; one issues listing page, plus one **timeline** read per item closing for the first time - the timeline carries the labelings, the comments and the close together, which is exactly the three things wanted off an item. On a cadence of two ticks a day and a quiet queue the run half of that is under ten calls a day, which a test asserts by counting the fetches a representative day makes. `MAX_RUN_READS` is the runaway guard rather than the budget: a day that somehow produced hundreds of runs stops at the cap, leaves the watermark at the last run measured, and says so.

### Every tier is appended once

This is where the machinery half differs from the session half: **nothing is recomputed.** Every source is a watermarked listing, a run or an item is folded on the one pass that first sees it, and a counting fix applies from the fix forward. That is safe because each fact is settled once seen - a completed run's start and conclusion do not move, a closed item's outcome label is written at convergence - and both watermarks are monotone over those facts.

Two maps do not reach the week tier on the same terms as the rest. `runCosts`, keyed by run id, is dropped there and its numbers survive as the week's own scalars; `latency` is kept, because the samples *are* the week-level answer.

## Why the declaration reads as it does

usage-fold - the per-repo usage aggregate. `code_worker_mjs: 'worker.mjs'` and no
agent: the whole pass is deterministic code the executor runs as code-work - no
agent phase, seconds of runtime.

WHY: a skill is MOUNTED per repo, but mounting only puts a name and a one-line
description into the session prompt — actually LOADING it is model discretion, and
nothing recorded whether it ever happened. The only evidence is the session
transcript, which is ephemeral and dies at retention on the logs branch. So the
promotion ladder's skill-vs-prose call had no empirical feedback: a skill whose
trigger never fires looked exactly like one that fires daily. This task counts
loads — and the DENOMINATORS that make a count mean something — out of the logs
this repo already captures, into a small tracked aggregate.

It also counts what the MACHINERY did: how often the scheduler and the executor
ran, how many of those hours a session actually opened, what each closed work item
came to, and what landed in git. That half exists in a repo whose sessions are all
unattended and captured nothing at all.

WHY DAILY. The file is the whole past-data plane the dashboard renders from
(claudinite-dashboard) — every panel that reaches further back than one page of live reads
comes from here. A cadence finer than the scheduler's cron cannot be honoured, since the
anchor is only ever seen when a tick comes. Hour rows are recomputed from source across a
three-day window, so only the newest rows' freshness depends on the cadence, and the
dashboard tops up the freshest hours from the live run listing it fetches anyway. The precondition is what keeps a quiet repo quiet.

`any-commit`, not `substantive-change`: this task measures the MACHINERY, so a
task's own output is exactly what the aggregate folds rather than something to
be blind to. `runs-since-fold` beside it: a repo whose only activity is its own
queue commits nothing and captures nothing, yet its scheduler ticked, and the
machinery half has those runs to fold.
The regenerated aggregate is the whole delivery — scoped to the tree it
lands in, so a GENERATED file elsewhere in the repo is some other task's.
One tree read plus one blob read per capture file in the ~10-day window, all
local git, then four REST reads and one PR. A busy repo captures a few files a
day, so this is seconds; 600s is ~100x that, generous enough that a huge backlog
on a first fold still completes while a hung run is killed well inside the daily
cadence.
