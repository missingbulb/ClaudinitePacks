// The usage-fold work step - the module the runner calls `worker` on
// (cwd = this task dir, bounded by code_work_timeout).
// The whole task: no agent phase.
//
// Two halves, each folding its own rolling file past its own watermarks, delivered on
// one pull request: the SESSION half below, and the MACHINERY half - what the
// scheduler and executor cost - in `machinery-half.mjs`. They stay two files because
// their sources differ: this half re-reads capture files for free off a local branch,
// that one reads only rate-limited REST listings, and one source's outage must not
// cost the other's rows.
//
// It holds NO counting logic: the counting and folding live in sibling modules,
// and this is the session half's I/O shell:
//
//   1. fetch the orphan `conversation-logs` branch (plain local git — the branch is
//      in this repo, so one tree read plus one blob read per file beats any REST
//      round-trip, and there is no rate budget to spend);
//   2. count each capture file still in the raw retention window;
//   3. list the scheduler's and executor's completed workflow runs past the
//      `runsFoldedThrough` watermark - how often the machinery ran,
//      including the runs that opened no session at all;
//   4. list the work items that CLOSED past the `queueFoldedThrough` watermark
//      - what each occurrence came to, and the parks each collected;
//   4b. list the pull requests MERGED past the `prsFoldedThrough` watermark
//      - what each one took from opening, from its issue and from the
//      session that did the work;
//   5. read the local git history and the releases listing for the day series neither
//      of the above can answer — commits, lines and releases;
//   6. fold: hour rows over the last three days, day rows recomputed from scratch,
//      appended rows past their watermarks, week rows advanced past `foldedThrough`;
//   7. deliver the folded `.claudinite/usage/sessions-and-elements.json`, beside the
//      machinery half's file, on a PR that lands itself where this repo's delivery
//      settings allow - leaving out a file whose recompute is byte-identical apart
//      from its stamp, and opening NOTHING when both are.
//
// The aggregate lives under `.claudinite/usage/`, beside the repo's other rolling
// records, where the vendoring refresh never reaches; the mount root itself is
// read-only canon.

import { execFileSync } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { baseTip, readAt, readRollingAt, remoteUrl } from '../../public/delivery.mjs';
import { AUTOMERGE_TRAILER } from '../../src/contract/merge-policy.mjs';

import {
  countEntries, foldUsage, encodeUsage, decodeUsage, mountedCorpus, DAY_WINDOW_DAYS,
} from './fold-usage.mjs';
import { renderUsageFile, withoutStamp } from '../../src/items/usage-format.mjs';
import { makeReader, readRuns } from './read-runs.mjs';
import { makeReader as makeQueueReader, readQueueOutcomes } from './read-queue.mjs';
import { readMergedPrs, prRecordsFrom } from './read-prs.mjs';
import { settingsPath } from '../../../../engine/settings-file.mjs';
import { TASKS_USAGE_PATH } from '../../src/items/tasks-usage-format.mjs';
import { foldMachinery } from './machinery-half.mjs';

const BRANCH = 'conversation-logs';
// A rolling file, not a regenerated one: every fold starts from the last, so it carries
// no GENERATED in its name.
export const USAGE_PATH = '.claudinite/usage/sessions-and-elements.json';
// Where it lived before `.claudinite/usage/`. Read as the prior state until the file has
// moved, and moved by the delivery rather than dropped.
// @legacy-tolerance advisory:legacy-shape-in-use retire:#2323
export const LEGACY_USAGE_PATH = '.claudinite/local/usage.GENERATED.json';

// The run's own logger, under the task's name and its item. Module-level because the
// helpers below log too; `worker` takes the one the runner built.
let log = console.log;

const git = (root, args) => execFileSync('git', ['-C', root, ...args], {
  encoding: 'utf8',
  // A capture blob easily tops the default 1 MiB buffer — a long session's log then
  // dies mid-read and the day it lands in silently under-counts.
  maxBuffer: 256 * 1024 * 1024,
  stdio: ['ignore', 'pipe', 'pipe'],
});

// --- the raw window -----------------------------------------------------------

// The capture filename standard: keyed to the
// pull request a merge landed (`pr-<n>`) or to an issue (`issue-<n>`), where `0`
// means "no associated issue" — a SessionEnd capture. The other key is `null`.
// Exported for the tests.
//
// The `stamp` is the same name read to the minute, which is what files the session
// into an HOUR row. The name is machine-written by the capture step, so reading the
// clock off it costs nothing and agrees with the retention rules that read it too.
export function parseLogName(name) {
  const m = /^(\d{4}-\d{2}-\d{2})T(\d{2})(\d{2})Z(?:-\d+)?--(pr|issue)-(\d+)--(.+)\.jsonl$/.exec(name);
  if (!m) return null;
  const n = Number(m[5]);
  return {
    date: m[1], stamp: `${m[1]}T${m[2]}:${m[3]}:00Z`,
    issue: m[4] === 'issue' ? n : null, pr: m[4] === 'pr' ? n : null, sessionId: m[6],
  };
}

export function parseEntries(text) {
  const out = [];
  for (const line of (text || '').split('\n')) {
    if (!line.trim()) continue;
    try { out.push(JSON.parse(line)); } catch { /* a partial trailing write — skip the line */ }
  }
  return out;
}

// Fetch the logs branch and return its capture files. Returns null when the branch
// does not exist — a repo that has never captured has nothing to fold, which is a
// clean no-op rather than a failure.
function logFiles(root, remote) {
  if (!git(root, ['ls-remote', '--heads', remote, BRANCH]).trim()) return null;
  git(root, ['fetch', '--quiet', remote, BRANCH]);
  const tip = git(root, ['rev-parse', 'FETCH_HEAD']).trim();
  const names = git(root, ['ls-tree', '--name-only', tip]).split('\n').filter(Boolean);
  return { tip, names: names.filter((n) => parseLogName(n) !== null).sort() };
}

// --- the day series the sessions cannot answer --------------------------------

// What landed, per day: commits on the base branch and the lines they moved. Local
// git, so it is free and recomputed every run — a counting fix heals the whole window
// the way the capture-derived rows do.
//
// A SHALLOW CHECKOUT IS THE NORMAL CASE in Actions, and it is why this returns a
// covered-from date rather than a map with zeroes in it: the history simply stops
// somewhere, and every day before that is UNKNOWN. Writing 0 for those days would
// draw a busy fortnight as an idle one, and the fold's own rule is that an absent
// source leaves no key at all.
//
// `COMMIT_MARK` opens each commit's block so the numstat lines that follow can be
// attributed to it. A control character rather than any printable prefix, because the
// only thing that can never appear at the start of a numstat line is something git
// cannot produce there. A merge commit shows no numstat and contributes a commit but
// no lines, which is right — its content arrived with the commits it merged.
const COMMIT_MARK = '\u0001';

export function parseCommitLog(text) {
  const days = {};
  let date = null;
  for (const line of String(text ?? '').split('\n')) {
    if (line.startsWith(COMMIT_MARK)) {
      date = line.slice(1, 11) || null;
      if (date) (days[date] ??= { commits: 0, linesAdded: 0, linesRemoved: 0 }).commits += 1;
      continue;
    }
    if (!date || !line.trim()) continue;
    const m = /^(\d+|-)\t(\d+|-)\t/.exec(line);
    if (!m) continue;
    // `-` is a binary file: it has no line count, and counting it as 0 is the honest
    // reading — no LINES moved, whatever the bytes did.
    if (m[1] !== '-') days[date].linesAdded += Number(m[1]);
    if (m[2] !== '-') days[date].linesRemoved += Number(m[2]);
  }
  return days;
}

// DEEPEN BEFORE READING. An Actions checkout is shallow — usually one commit — so the
// history the series below reads stops immediately and every day but today is unknown.
// One `git fetch --shallow-since` over the window fixes that for the price of a single
// git operation and no REST at all; the alternative, the commits API, costs one read
// per commit for its stats and is unbounded on a busy day.
//
// Guarded on the repo actually BEING shallow, because on a complete clone the same
// flag is not a deepen — it would truncate the history to the window.
//
// Returns which path ran, so the log says whether the deepen engaged: a fetch that
// silently did nothing and a checkout that never needed one produce the same series
// and must not read the same in the log.
export function deepenHistory(git, root, remote, base, sinceIso) {
  try {
    if (git(root, ['rev-parse', '--is-shallow-repository']).trim() !== 'true') return 'complete';
    git(root, ['fetch', '--quiet', `--shallow-since=${sinceIso}`, remote, base]);
    return 'deepened';
  } catch {
    // A server that will not deepen, or a window with no commits in it: the series is
    // read from whatever history is here, and `coveredFrom` still states where it starts.
    return 'unchanged';
  }
}

export function commitSeries(git, root, sha, sinceIso) {
  let text = '';
  try {
    text = git(root, ['log', sha, `--since=${sinceIso}`, '--date=iso-strict', '--pretty=format:%x01%cI', '--numstat']);
  } catch {
    return null;                            // no readable history — the series is unknown, not empty
  }
  const days = parseCommitLog(text);
  // Where the available history actually starts. On a full clone that is the window;
  // on a shallow one it is wherever the fetch stopped, and days before it carry no key.
  let coveredFrom = sinceIso.slice(0, 10);
  try {
    if (git(root, ['rev-parse', '--is-shallow-repository']).trim() === 'true') {
      const oldest = git(root, ['log', sha, '--reverse', '--pretty=format:%cI']).split('\n')[0]?.slice(0, 10);
      if (oldest && oldest > coveredFrom) coveredFrom = oldest;
    }
  } catch { /* an older git without the flag — the window stands */ }
  return { days, coveredFrom };
}

// Releases published per day. One REST read, recomputed every run like the git series.
// Absent (unreadable) leaves every day without the key rather than claiming a month
// with no releases in it.
export async function releaseSeries(reader, repo) {
  const list = await reader.json(`/repos/${repo}/releases?per_page=100`);
  if (!Array.isArray(list)) return null;
  const days = {};
  for (const r of list) {
    const at = r?.published_at ?? r?.created_at;
    if (!at) continue;
    const date = String(at).slice(0, 10);
    days[date] = (days[date] ?? 0) + 1;
  }
  // Newest-first and capped at one page: a repo publishing more than 100 releases
  // inside the window would under-report the far end. Stated rather than silently
  // truncated — the caller logs it.
  return { days, truncated: list.length >= 100 };
}

// The two series above, merged into the per-day field map `foldUsage` takes: a day
// gets a key only from a source that could speak for it.
export function dayFieldsFrom({ commits = null, releases = null, ladder = [] }) {
  const out = {};
  for (const date of ladder) {
    const fields = {};
    if (commits && date >= commits.coveredFrom) {
      const row = commits.days[date] ?? { commits: 0, linesAdded: 0, linesRemoved: 0 };
      Object.assign(fields, row);
    }
    if (releases) fields.releases = releases.days[date] ?? 0;
    if (Object.keys(fields).length) out[date] = fields;
  }
  return out;
}

// The window's UTC days, oldest first.
export function dayLadder(nowIso, days = DAY_WINDOW_DAYS) {
  const end = new Date(`${nowIso.slice(0, 10)}T00:00:00Z`).getTime();
  return Array.from({ length: days }, (_, i) => new Date(end - (days - 1 - i) * 86400000).toISOString().slice(0, 10));
}

// --- main ---------------------------------------------------------------------

// The session half: capture files, run listings, closed items, merged PRs and the git
// history, folded into `USAGE_PATH`. Hands back the file, or nothing when the
// recompute is byte-identical apart from its stamp.
async function foldSessions({ root, repo, token, base, remote, baseSha, now, log }) {
  // No logs branch is not "nothing to do": the capture-derived half of the
  // aggregate is empty, but every other source — the run listings, the queue's own
  // closed items, the git history — exists as soon as the repo has a scheduler, and a
  // repo whose sessions are all unattended is exactly the one worth counting.
  const found = logFiles(root, remote);
  if (found === null) log(`no ${BRANCH} branch — nothing captured yet; folding the run, queue and git sources only`);

  let config = {};
  try { config = JSON.parse(readFileSync(settingsPath(root), 'utf8')); } catch { /* no declaration */ }
  const corpus = await mountedCorpus(root, config);

  const files = (found?.names ?? []).map((name) => ({
    ...parseLogName(name),
    counts: countEntries(parseEntries(git(root, ['show', `${found.tip}:${name}`])), corpus),
  }));

  // Prior state comes from the BASE TIP, never the working tree: the checkout may be
  // sitting on another task's branch, and the base is the only authority on what has
  // already been folded. A fold PR still open when the next run fires is rebuilt from
  // the base — days recompute statelessly and the watermark advances from the same
  // place, so nothing is ever counted twice.
  // Decoded on the way in: the prior file may have been written by any version of this
  // format, and the fold works in named counters throughout.
  const rolling = readRollingAt(root, baseSha, USAGE_PATH, LEGACY_USAGE_PATH);
  let prior = {};
  try { prior = decodeUsage(JSON.parse(rolling.text ?? '{}')); } catch { /* unparsable → refold */ }

  const reader = makeReader({ token });

  // The outside sources. Each is INDEPENDENTLY fail-soft: one that cannot be read
  // costs its own rows this run and leaves its own watermark where it was, because
  // the capture-derived counts do not depend on any of them and must not be lost with
  // one of them.
  const runs = await readRuns({ reader, repo, since: prior.runsFoldedThrough ?? null, now });
  if (runs.error) log(`${runs.error} — the hour rows' run counts are unchanged this run`);

  const queue = await readQueueOutcomes({
    reader: makeQueueReader({ token }), repo, since: prior.queueFoldedThrough ?? null, now,
  });
  if (queue.error) log(`${queue.error} — the queue outcome rows are unchanged this run`);

  const prs = await readMergedPrs({ reader, repo, since: prior.prsFoldedThrough ?? null, now });
  if (prs.error) log(`${prs.error} — the merged-PR rows are unchanged this run`);

  const ladder = dayLadder(now);
  const windowStart = `${ladder[0]}T00:00:00Z`;
  log(`git history: ${deepenHistory(git, root, remote, base, windowStart)} for the window from ${ladder[0]}`);
  const commits = commitSeries(git, root, baseSha, windowStart);
  if (commits === null) log('the local git history could not be read — the commit and line rows are absent this run');
  else if (commits.coveredFrom > ladder[0]) {
    log(`this checkout's history starts at ${commits.coveredFrom} — days before it carry no commit or line counts`);
  }
  const releases = await releaseSeries(reader, repo);
  if (releases === null) log('the releases listing could not be read — the release rows are absent this run');
  else if (releases.truncated) log('more than 100 releases exist — the far end of the release series may be under-counted');

  const text = renderUsageFile(encodeUsage(foldUsage({
    files,
    prior,
    today: now.slice(0, 10),
    now,
    generated: now,
    runs: runs.runs,
    runsFoldedThrough: runs.watermark,
    queueRecords: queue.records,
    queueFoldedThrough: queue.watermark,
    prRecords: prRecordsFrom({ prs: prs.prs, files }),
    prsFoldedThrough: prs.watermark,
    dayFields: dayFieldsFrom({ commits, releases, ladder }),
  })));

  const summary = `${files.length} capture file(s), ${runs.runs.length} run(s), ${queue.records.length} closed item(s) `
    + `and ${prs.prs.length} merged PR(s)`;
  // Compared WITHOUT the freshness stamp, which moves every run by construction: a
  // repo where nothing happened must still open nothing, and the stamp is the one line
  // that would otherwise make every fold a PR.
  const landed = readAt(root, baseSha, USAGE_PATH);
  if (landed !== null && withoutStamp(landed) === withoutStamp(text)) {
    return { files: {}, moves: {}, summary: `${summary} - byte-identical` };
  }
  return { files: { [USAGE_PATH]: text }, moves: rolling.moves, summary };
}

// Runs every half, then lands whatever changed on ONE pull request. A half that
// throws costs only its own file: the others still deliver, and the run then fails
// with every half's error, so a broken half is never mistaken for a quiet one.
export async function deliverFolds({ halves, deliver, automerge, log }) {
  const files = {};
  const moves = {};
  const failures = [];
  const summaries = [];
  for (const [name, fold] of Object.entries(halves)) {
    try {
      const out = await fold();
      Object.assign(files, out.files);
      Object.assign(moves, out.moves);
      summaries.push(`${name}: ${out.summary}`);
    } catch (err) {
      log(`the ${name} half failed - its file is unchanged this run: ${err?.stack ?? err}`);
      failures.push(`${name}: ${err?.message ?? err}`);
    }
  }
  for (const line of summaries) log(line);

  if (Object.keys(files).length) {
    const pr = await deliver({
      files,
      moves,
      // The arming trailer carries the task's own automerge, so the
      // automerge-policy-scope check re-measures this delivery's diff wherever the
      // PR's CI runs check_the_work - the code lane's equivalent of the agent
      // lane's stamp-before-merge.
      message: `Claudinite: fold usage\n\n${AUTOMERGE_TRAILER}: ${automerge}`,
      title: 'Claudinite: usage fold',
      body: [
        'Regenerated the repo\'s rolling usage records:',
        '',
        ...Object.keys(files).map((path) => `- \`${path}\``),
        '',
        `\`${USAGE_PATH}\` folds what the repo's sessions did - its captured conversation`,
        "logs, its workflow run listings, the queue's closed work items, its merged pull",
        'requests and its git history. Hour rows cover the last three days; day rows are',
        'recomputed from scratch every run; the run, queue and merged-PR rows and the week',
        'rows are appended once, past their own watermarks.',
        '',
        `\`${TASKS_USAGE_PATH}\` folds what the machinery itself cost - per workflow the runs,`,
        "jobs, billed minutes and, only where this pack's config carries `actionsMinuteRate`,",
        'the spend they imply; per run its API calls and wall time per phase; per task its',
        'outcomes, parks and latency samples. Every tier is appended once past its own watermark.',
        '',
        'A file whose recompute differs only in its `generated` stamp is left out, and a fold',
        'where neither moved opens no PR at all. Machine-written - never hand-edit either;',
        'each fold starts from the last, so a lost copy is lost history.',
      ].join('\n'),
    });
    log(`${pr.reused ? 'updated' : 'opened'} PR ${pr.number !== null ? `#${pr.number}` : `on ${pr.branch}`}`
      + `${pr.merged ? ' (landed)' : pr.delivery === 'review' ? ' (left for review)' : ''}`);
  } else if (!failures.length) {
    log('every recompute is byte-identical - nothing to deliver');
  }

  if (failures.length) throw new Error(`usage fold: ${failures.join('; ')}`);
}

export async function worker({ root, repo, token, defaultBranch, automerge, deliver, log: runLog }) {
  log = runLog;
  const base = defaultBranch ?? 'main';
  const remote = remoteUrl(repo, token);
  const baseSha = baseTip(root, remote, base);
  const now = new Date().toISOString();
  await deliverFolds({
    halves: {
      sessions: () => foldSessions({ root, repo, token, base, remote, baseSha, now, log }),
      machinery: () => foldMachinery({ root, repo, token, baseSha, now, log }),
    },
    deliver, automerge, log,
  });
}
