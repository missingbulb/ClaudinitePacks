# macos

Native macOS app development: assembling the app bundle, the TCC / Hardened Runtime pair, the
Developer ID → notarization → DMG lane, and the process-lifecycle facts a Mac app cannot get wrong.

Sibling packs on the same axis: `ios` (iPhone targets) and `git-github` (workflow YAML mechanics
for the CI that runs the lane). The Mac App Store lane is outside this pack's Developer ID track.

## Rules (`RULES.md`)

| Rule | Severity | Reason | Enforcement |
|---|---|---|---|
| SwiftPM builds a binary, not a .app | high | correctness | prose: <50 words |
| Commit an icon master, generate .icns | low | complexity | prose: <50 words |
| Notarization requires the Hardened Runtime | critical | legal | prose: <100 words |
| SFSpeechRecognizer streams to Apple by default | critical | legal | prose: <100 words |
| On-device opt-in needs the locale's model | high | correctness | prose: <100 words |
| The unsigned path stays a working path | medium | complexity | prose: <100 words |
| An ad-hoc signature cannot be notarized. | high | legal | prose: <50 words |
| Notarize the distributed container, then staple it | high | legal | prose: <50 words + check (`notarize-then-staple`) |
| A CI identity joins the searchable keychain | medium | correctness | prose: <100 words |
| Annotate which signing lane ran | medium | complexity | prose: <50 words |
| A drag-install DMG is a staged folder | medium | complexity | prose: <100 words |
| Write the Gatekeeper bypass users actually have | medium | correctness | prose: <100 words |
| Diagnostics belong inside the shipped app | medium | complexity | prose: <50 words |
| NSApplication installs no signal handlers | high | correctness | prose: <100 words + check (`signal-teardown-routing`) |
| An uncaught Objective-C exception is an exit | high | correctness | prose: <100 words |
| There is no wake notification | high | correctness | prose: <100 words |
| Coalesce with an id, not a boolean. | high | correctness | prose: <100 words |
| asyncAfter fires immediately on wake | high | correctness | prose: <100 words |
| Measure a span across sleep with Date() | high | correctness | prose: <50 words |
| Release the device on every capture path | critical | correctness | prose: <100 words |
| Never build an engine to probe devices | high | correctness | prose: <200 words |
| Presence is not usability, at either layer. | high | correctness | prose: <200 words |
| A duration claims a span you observed | high | correctness | prose: <200 words |
| "Started" is not "working". | high | correctness | prose: <100 words |
| Compile-green is no gate for device code | high | correctness | prose: <100 words |

The bundle keys and the TCC/entitlement pair are skills the guard forces for the files they
govern (`Info.plist`, `Package.swift`, `*.entitlements`): [`macos-app-bundle`](skills/macos-app-bundle/SKILL.md)
and [`macos-entitlements-and-tcc`](skills/macos-entitlements-and-tcc/SKILL.md). A notarized build
should need no Gatekeeper bypass at all — a README whose manual-bypass section is the one users
actually follow is the sign the signing lane isn't running.

## Skills

| Skill | Trigger |
|---|---|
| [`macos-app-bundle`](skills/macos-app-bundle/SKILL.md) | any edit of `Info.plist` or `Package.swift` — held by the guard until loaded |
| [`macos-entitlements-and-tcc`](skills/macos-entitlements-and-tcc/SKILL.md) | any edit of an `.entitlements` file or `Info.plist` — held by the guard until loaded |

## Checks

| Check | Severity | Reason | Enforcement |
|---|---|---|---|
| `sudden-termination-vs-teardown` | high | correctness | check: blocking |
| `signal-teardown-routing` | high | correctness | check: blocking |
| `minimum-system-version-agrees` | high | correctness | check: blocking |
| `swift-toolchain-gate` | high | correctness | check: blocking |
| `notarize-then-staple` | high | legal | check: blocking |

The `Package.swift` fingerprint only **suspects** the pack: a Swift package can be a library
or an iOS-only target, so declaring it stays the project's call.
