# ios pack

Active when the repo has `ios/Runner/Info.plist`. Durable, project-agnostic iOS app-development
practices in `RULES.md`: Xcode project mechanics, Info.plist usage-description strings,
entitlements, code signing and provisioning, and simulator/device workflows. Prose-only: the pack
carries no checks and no skills.

## Rules (`RULES.md`)

| Rule | Severity | Reason | Enforcement |
|---|---|---|---|
| Verifying a Swift/iOS change from a sandbox | high | correctness | prose: <100 words |
| Apple Developer Documentation pages are JS-rendered | medium | complexity | prose: <50 words |
