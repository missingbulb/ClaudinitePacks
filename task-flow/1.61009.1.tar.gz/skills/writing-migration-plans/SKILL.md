---
name: writing-migration-plans
description: How a plan's phases are ordered so nothing stalls mid-run. Use before writing any DESIGN.md, migration, rollout or phased plan, or when working through a plan's tracking issue.
metadata:
  body: workflow
  usage:
    expect: triggered
  force-load-on-file-edits-paths:
    - 'docs/**/DESIGN.md'
---

# Writing migration and implementation plans

A plan's phases are not a narrative of the work; they are a **schedule of who has to be present
when**. Ordering them by topic — "phase 1: the store, phase 2: the workers, phase 3: cutover" —
scatters the moments that need a human across the whole run, and every one of them stops it. Order
them by *what blocks*, and the run ends with a stretch nobody has to attend.

The shape this produces, in one line: **setup, then one approval of everything, then a chain that
runs itself.** All the code is written before the owner is asked for anything — the cleanup and
the destructive tail included — so their attention is spent once; and every step after that
approval is a queued continuation armed on the step before it, so the migration advances without
anyone remembering it exists.

Everything below assumes the change is already agreed: the problem, and that this migration is the
right way to solve it (basics' *Starting any requested change*). The end-state's **shape** —
converging in one forced pass, accepting legacy input at the door, a standing mechanism for
stragglers — is [RULES.md](../../RULES.md)' *Planning a migration*; this skill is the ordering.

## Two deliverables, two homes — and only two

An initiative produces at most one document and one issue, and neither may do the
other's job:

- **The design doc** (`docs/<initiative>/DESIGN.md`, where the project keeps one)
  describes the **end state and its rationale** — what the mechanism is once the
  work is done, and why that shape over the alternatives, with each alternative's
  drawbacks stated. It never carries the previous state as narrative, the requests
  or conversation that led here, owner attributions or opinions, progress, or a
  phase list. The test: a reader who arrives after the migration finishes must
  find nothing to delete. Legacy shapes appear only where the end state itself
  keeps handling them (a decode map, an accepted input) — as mechanism, not as
  history.
- **The migration is work, not a document.** Its plan lives in the tracking issue
  and nowhere else — never a plan or migration document committed to the repo. A
  plan document goes stale the moment work starts and cannot be checked off; the
  issue is checkable, append-only, and dies with the work.

## The three blocks, and where each belongs

Sort every step of the plan into one of three kinds, and let that sort — not the subject matter —
decide the phase it lands in.

**1. Out-of-band setup — before any code changes.** Anything performed outside the repo that a
later step will need: provisioning an environment, creating a session or runner, setting a secret
or variable, granting a permission, flipping a platform setting, registering a webhook. Nearly all
of it is **non-destructive** — it adds a capability that nothing yet consumes, so doing it early
costs nothing and changes no behaviour. Doing it *late* costs the whole run: the plan reaches the
step that reads the secret and stops until someone is available.

Front-load all of it into phase zero, before the first line of code. Write it as its own issue
with a checkbox per step (basics' *Handing over a human-only step*), stating for each what stays
broken while it is off, and written per
[writing-handover-issues](../../../basics/skills/writing-handover-issues/SKILL.md). And before writing it down, confirm you genuinely cannot do it yourself —
a step handed to a human that you could have taken is the most expensive kind of block there is.

The exception is the genuinely destructive step — deleting the old store, revoking the old
credential, removing the compatibility shim. Those are not setup; they are the migration's tail,
and they belong after the cutover has been observed working — which is **not** a later phase. A
cleanup phase falls due long after the run that would have done it ended, and nothing brings it
back.

**Write its code anyway, now, in the stack** (the next sort), so the owner approves it with
everything else — and make its *merge* a link in the chain below, armed on the cutover being
observed. What must never be deferred is the writing and the approving; what must always be
deferred is the merging.

**2. Review and authorization gates — collapsed into one pass.** Every phase that ships code is a
gate: the owner must read it and approve it before the next phase can start. A plan with four
coding phases has four such waits, and each one is dead time whose length nobody controls.

Write **all** the code first — every phase of it, including the cleanup and the destructive tail —
as a stack of PRs each based on the previous, and put the whole stack in front of the owner
together. The stack keeps the reviewable units small and independent — one concern per PR, as ever
— while costing one arrival of attention rather than four.

*Write* is not *merge*. A PR whose merge must wait on something being observed still gets written,
reviewed and approved in this pass; what waits is its merge, and the thing that performs that
merge is a link in the chain (below), not a person's memory. Say so in that PR's body: what gates
it, and which queued step will merge it.

Approval of the stack is approval of the stack: it does not extend to a fix authored afterwards
(basics' *Acting on an approval to merge, ship or proceed*).

**3. Execution steps — a chain, not a checklist.** Once phase zero has landed the setup and the
approved stack has begun merging, the remaining steps run the migration: force the update,
backfill the members, watch the cutover, merge the gated PR, retire the shim. If the first two
sorts were done properly there is no *approval* gate among them — but there is almost always a
**wait**, because each step's precondition is the previous step's effect becoming observable
somewhere the repo cannot see yet.

A wait is not a reason to write "then, later, do X". Every one of these steps is filed, at plan
time, as a queued continuation armed on the step before it. See **The chain** below.

That is the test of the plan. **Read the phases in order and mark every point where the run would
have to stop and wait for a person.** Each mark that falls after phase zero and the review pass is
a step that was sorted wrong — or a step that should have been a link in the chain and was written
as a note instead. Move it, chain it, or say in the plan why it genuinely cannot be either.

## The legacy tolerance is scaffolding

Almost every migration ships one: a dual read, an accepted old spelling, a decode map, a shim at
the path something was renamed from. It is what lets the two halves of the migration land in
either order, and it is the single most reliable way for a migration to never finish — because
once it works, nothing in the world complains about it. A tolerance is not part of the end state.
It is the ladder, and the plan says when the ladder comes down.

Three things ship *with* it, in the same stack, never afterwards:

- **The advisory.** Whoever still holds the old shape must be told, at the point they hold it —
  the check that reads their file, the warning the loader emits, the finding their own run
  reports. A tolerance with no advisory asks people to migrate off something they have no way of
  knowing they are on, and then measures how few of them did. Where the tolerance is in code the
  holders cannot see, the advisory is the one that fires in *their* repo, not a note in yours.
- **The removal, written now.** It is code, so it goes in the approved stack with everything else
  (above); what waits is its merge, and the thing that performs that merge is a link in the chain.
- **The window that releases it** — how long a correctly-behaving holder needs to pick the
  advisory up and act on it, written as the date the removal link waits on. The tempting
  alternative is a census — "when no holder still carries the old shape" — and it is usually
  unanswerable: a project cannot see which of the things consuming it are live, which are
  dormant and which stopped updating months ago, so the removal waits on an answer that never
  arrives and the tolerance becomes permanent while looking scheduled. Read a count only where
  you own both sides of it and it really does come back ("the oldest row in the retention window
  postdates the rename"). Everywhere else, pick the window, say in the link what it assumes, and
  let a holder that ignored the advisory for that long take the break.

Say at the tolerance site which link removes it, so the next reader of that code is looking at a
scheduled removal rather than a permanent-looking feature with an optimistic comment beside it.

Getting a gate wrong is rarely symmetric, and the plan states which way. Where a premature
removal only degrades — a decoder that starts writing nulls, a check that stops asserting — the
removal link takes a narrow predicted-folder policy like any other. Where it *wedges* a holder
past what a later PR can undo — the mount that no longer resolves, the credential that no longer
validates — the link is `nothing`, whatever its diff turns out to look like.

## The approval that turns the plan into issues

*Agreed* is an event with a date, and everything below happens after it. Draft the plan, put it to
the owner whole, and file nothing — not the tracking issue's plan body, not a chain link, not a
`Blocked-by:` edge — until they have said yes. A plan filed first and asked about second hands the
owner a structure to react to instead of a decision to make, and every change they then want is a
sweep across issues that already point at each other.

One submission, carrying three things and stopping there:

- **A line per step.** What it does and what it leaves behind, in the order they run. Not the
  brief — the brief is the link's own body, written when the link is filed.
- **The dependency graph.** Which step waits on which, and where the graph forks or joins. This is
  what the owner reads to see how long the run is and where it can stall; a flat list hides both.
- **The automerge policy per link, beside the prediction it came from** — the folders and kinds
  the PR is expected to touch, then the policy that prediction becomes, then the count of `nothing`
  links. That count is the owner's own workload, and it is the half of the plan they cannot
  reconstruct from the steps. **Sizing the links** below is therefore answered before the
  submission, not after it.

This approves the plan's *shape*, and only the shape: the code stack still comes back for its own
review pass (**2. Review and authorization gates** above), and a step added after the approval is a
new ask, not a detail of an approved one (basics' *Acting on an approval to merge, ship or
proceed*). Where the plan changes before implementation starts because the owner says it misreads
what they asked for, that is a correction to the draft, handled as **Working through the plan**
below sets out.

## The chain

Everything after the approval is a run that arms the next run. The mechanism is the queue's own
ad-hoc lane — the one `/do-later` and `verify-in-production` file into — and nothing here adds
machinery beside it: an ordinary issue, marked `task:origin:ad-hoc`, carrying its own brief.

**File the whole chain once the plan is approved** (above), not as each step falls due. One issue per
execution step, each naming the previous in `Blocked-by:`, so the queue does the waiting: a
blocked item is released when its blocker closes, which is exactly "the step before it finished".
Filing the chain up front is what makes it a mechanism rather than a habit — a chain that depends
on each run remembering to file its successor breaks silently the first time a run parks.

The chain's **last link is the plan's retrospective**, filed in the same pass with its brief
written now, while the design's expectations are still in front of you, `Blocked-by:` the final
execution step — so once the migration has lived in production for a while, something comes back
to read whether the design survived contact.
[production-retrospective](../../../basics/skills/production-retrospective/SKILL.md) owns what that brief answers and
its horizon.

Each link is a **sub-issue of the tracking issue** ([RULES.md](../../RULES.md)' *Filing an issue
that belongs under another*), so the plan and its chain are one hierarchy read two ways rather
than two lists that can disagree. Where a link is a PR's merge rather than a run, that PR's body
closes **the link**, never the tracker: a phase PR carrying `Closes #<tracker>` ends the whole
migration on its first merge.

Each link's body is its whole brief, because the run that picks it up will never see the
conversation that planned it. Four things, and the first two are what make the link *chainable*:

- **What makes this step's world ready** — a thing to *read*, never a duration: a stamp, a file at
  a URL, an API answer. (`verify-in-production` spells this as `In-production-when:`, and a link
  that waits on a release rather than on the previous issue closing rides `Not-before:` +
  `Retry-every:` instead of `Blocked-by:`.)
- **What counts as this step having worked** — the assertion its own successor is waiting on.
  This is the load-bearing half: the chain advances on *validation*, not on the step having run.
- **The playbook**, exact enough to execute without judgment: what to do, and what to do when the
  check fails (comment what was read, leave the issue open — a failed step must not close, because
  closing is what releases the next link).
- **How it ends**: comment the evidence on the tracking issue, then close as completed. That close
  is the trigger for the next link, so it happens last and only on success.

Three hazards worth stating once:

- **Closing is the trigger, and nothing distinguishes a `completed` close from a `not planned`
  one.** Abandoning the migration means closing the *rest* of the chain first, tail-first; closing
  a link to tidy it away releases its successor into a world that is not ready.
- **A link that cannot make its reads must park, not guess.** A rate-limited or scope-blocked
  sweep answers "all clear" in exactly the way a healthy fleet does.
- **A chain is only as visible as its tracking issue.** Every link comments its result there, so
  the plan's checkboxes and the chain's state never have to be reconciled by hand.

## Sizing the links: predict each PR before you file it

A link that ships code is a **prediction**, filed before the work: which folders and kinds of
file the request should touch, roughly how large, and the automerge policy that prediction
becomes. The prediction is what a person reads afterwards — which folders moved says whether
the change made sense — so the plan states it and the link's brief repeats it. Answer these
per link, at plan time, and record the answers in the tracking issue:

- **How many PRs.** Sort the coding steps into *phases* and *divisions*. A phase has an exit its
  successor waits on — a fold field that must accumulate through the nightly update before a
  page can read it, a stub a member must carry. A division is only labour, and could ship in any
  order. One PR per phase; group divisions that share a pack, and split them where one's failing
  test would hold the other hostage. One PR for everything spends one approval but stalls on any
  red; a PR per division buys exit conditions at the cost of a rebase each. The count is what
  remains after both are refused.
- **What each split has to buy.** A link exists to be **validated on its own** — its own
  automerge policy, its own exit condition, its own production check. Two links landing in the
  same files, under the same policy, proven by the same test have none of that: they are one link
  written twice, and the second one's issue, brief, rebase and converge are pure toil. Split where
  the halves sit in different parts of the system and can be judged apart; keep them together
  where the only difference between them is how much work each is.
- **What the diff will touch.** Name the folders and kinds, and the size. Then the policy is
  that prediction, written narrow (basics' *Choosing an automerge policy*): `under:<folder>`
  intersected with the kind where the kind is known, the same folder's `test-changes` and
  `doc-changes` beside it. Two things earn `nothing` whatever their diff class: a link that
  changes what leaves the repo irreversibly (a fold every member writes, a deletion, a
  production write), and the first render of a design — nothing checkable stands in for a
  person's eyes on it. A later same-folder diff *is* checkable once that first render has
  landed and a test pins its fold line.
- **How many human gates the chain expects.** Count the `nothing` links and add the parks you
  expect from widening. That count is the plan's honest prediction of the owner's workload, and
  it is what the owner is approving when they approve the plan.

## When automerge fails: how the chain survives

Each link waits on the previous one *closing*. The failures below are the ways a link's PR does
not land as predicted; write each link's brief so the chain holds through all of them.

- **The policy parks the PR for approval.** The issue stays open, so the successor stays
  blocked; the owner's one action is to merge. This is the intended gate, not a failure — never
  re-shape the diff to fit the classifier, and never widen the policy on the next link because
  this one parked.
- **The diff widens past its folder.** The same park, but the wrap-up names the file that broke
  the policy and the abstraction that would have kept it inside, so the owner reviews the
  widening rather than the whole PR.
- **CI goes red.** The run fixes and re-pushes within its budget; a park on failure holds the
  lane, and nothing downstream moves — correct, since the next link builds on this one.
- **The PR is closed unmerged.** The dangerous case: the issue closes, and the queue releases
  the successor on *close*, not on merge. So every link's brief **opens with a read of the
  previous link's artifact on `main`** — the field in the format module, the export, the
  rendered section — and, when it is absent, converges as `action` naming the unmerged link
  instead of building on air. The chain advances on validation, never on closure.
- **Two links edit the same file.** `Blocked-by:` serializes them, so there is no parallelism
  and no conflict to resolve; each brief ends with a rebase onto `main`.
- **The tail.** The chain's last links are the change's production verification and the plan's
  retrospective, filed with the rest; a chain that ends on its last coding link never learns
  whether it worked.

## Writing it down

- **The plan is a tracking issue**, and the phases are its checkboxes. Status and remaining work
  live there; a design document, where the project keeps one, carries the mechanism and not the
  progress.
- **Each phase names its exit condition**, observable and stated as a thing that reads back true
  from where the phase runs — not "cutover done" but "the new field is in the rendered output on
  `main`". A condition only somebody else's repo could answer is not observable from here. A phase whose end is a judgment
  call is a phase that stays open.
- **Nothing closes on a human's memory.** A step you cannot verify now gets a mechanism that comes
  to you — a link in the chain, a scheduled task, an issue something converges (this pack's *When
  verifying now is genuinely impossible*). A phase whose closing condition is "check next week" is
  not a phase.
- **Every execution phase names its link.** The checkbox says which issue runs it, so the plan and
  the queue are one thing read two ways rather than two lists that can disagree.
- **Size each step to what it is**, and don't restate in the plan what the design document or the
  linked issue already carries.

## Working through the plan

Once the plan is agreed, the issue body's plan is **append-only**. While implementing, scheduler run its
checkboxes and add below it — a comment, or a new section for what the work turned up — and never
edit, reword, condense or re-order what was already there.

The body is the record of what was agreed, and it is the only copy: an edit overwrites it in place
with nothing left to diff against, so a plan silently rewritten to match what was built reads
afterwards as a plan that was followed. Keeping it fixed is what makes the divergence visible —
and a divergence is the interesting part, not an embarrassment to tidy away.

So when the work shows a phase was wrong, say so **underneath**: what the plan assumed, what turned
out to be true, and what you did instead. If that changes the plan going forward, the new steps are
an addition, appended and dated; the superseded ones stay where they are, marked superseded rather
than deleted.

The exception is a **correction to the plan itself before implementation of it starts** — the owner
saying the plan misreads what they asked for. That is a correction (basics' *Acting on a
correction*): repair the body, since there is no work yet for it to have diverged from.

## Reviewing someone else's plan

Run the same sort over it. The findings worth raising, in order of what they cost:

1. A secret, permission, environment or account created **after** code that depends on it.
2. More than one review gate — two or more phases that each end in "open a PR and wait".
3. Code left unwritten because its phase is "later" — the cleanup and the destructive tail
   above all. Everything the migration will need is written and approved in the one pass; only
   merges and effects are deferred.
4. An execution step written as a note rather than filed as a link — anything phrased "then,
   once X, do Y" with no issue that comes back when X.
5. A legacy tolerance with no advisory reaching its holders, or with no link that removes it.
6. A chain whose links advance on a step having *run* rather than on its result being *read*.
7. A destructive step scheduled before the replacement has been observed working.
8. A phase with no stated exit condition, or one only a person can judge.
9. A step handed to a human that the agent could have performed itself.
10. Links split with no checkpoint between them — same files, same policy, same test — buying
    the plan an issue, a brief and a rebase and nothing else.
